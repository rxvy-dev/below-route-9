// The Quik-Stop's front glass and the night outside it: the lot, the gas canopy, Route 9,
// passing cars, and Ray's van pulling in. You can look; you can't leave.
#include <cmath>

#include "audio.h"
#include "game.h"
#include "texgen.h"

namespace {
constexpr float kFrontZ = 4.0f;          // the store's front wall line (tile row 2, north edge)
constexpr float kInZ = kFrontZ + 0.08f;  // inside face
constexpr float kOutZ = kFrontZ - 0.08f; // outside face
constexpr float kParapet = 4.6f;

mat4 frameM(vec3 r, vec3 u, vec3 n, vec3 p) {
  mat4 m = mat4::identity();
  m.m[0] = r.x; m.m[1] = r.y; m.m[2] = r.z;
  m.m[4] = u.x; m.m[5] = u.y; m.m[6] = u.z;
  m.m[8] = n.x; m.m[9] = n.y; m.m[10] = n.z;
  m.m[12] = p.x; m.m[13] = p.y; m.m[14] = p.z;
  return m;
}

// Openings in the front wall, by tile column 2..11: 0 none, 1 window, 2 door.
int openingAt(int t) { return t == 2 ? 0 : (t == 6 ? 2 : 1); }

// Light falling on the lot (matches the pools baked into the asphalt texture).
vec3 lotLight(float x, float z, bool storeLights) {
  struct Pool { float x, z, r; vec3 c; };
  static const Pool pools[] = {{16, -13, 9, {0.9f, 0.9f, 0.85f}}, {-4, -24, 9, {1.0f, 0.55f, 0.18f}}, {32, -24, 9, {1.0f, 0.55f, 0.18f}},
                               {14, 1, 6, {0.85f, 0.88f, 0.95f}}, {2, 1, 5, {0.85f, 0.88f, 0.95f}}, {26, 1, 5, {0.85f, 0.88f, 0.95f}}};
  vec3 l{0.05f, 0.055f, 0.07f};
  for (int i = 0; i < 6; ++i) {
    if (i >= 3 && !storeLights) continue;
    const Pool& p = pools[i];
    float d2 = (x - p.x) * (x - p.x) + (z - p.z) * (z - p.z);
    l += p.c * std::exp(-d2 / (p.r * p.r * 0.5f));
  }
  return l;
}

float smooth01(float t) { t = clampf(t, 0, 1); return t * t * (3 - 2 * t); }
vec3 bez(vec3 a, vec3 b, vec3 c, vec3 d, float t) {
  float u = 1 - t;
  return a * (u * u * u) + b * (3 * u * u * t) + c * (3 * u * t * t) + d * (t * t * t);
}
float yawOf(vec3 dir) { return std::atan2(-dir.x, -dir.z); }
}  // namespace

const vec3 Game::kVanPark{17.0f, 0.0f, -1.6f};

bool Game::storePowered() const {
  return storePhase_ == StorePhase::Shift && screen_ != Screen::Ending;
}

// Where Ray's van is right now. Returns false if it isn't here (yet).
bool Game::vanPose(vec3& p, float& yaw, float& lights) const {
  lights = 0;
  if (!inStore()) return false;
  bool waiting = storePhase_ == StorePhase::WaitRay;
  bool after = screen_ == Screen::Ending || (!waiting && storePhase_ != StorePhase::Shift && storePhase_ != StorePhase::FindLight &&
                                              storePhase_ != StorePhase::CallRay);
  if (screen_ == Screen::Ending && ambulance_) { p = kVanPark + vec3{-9.0f, 0, -1.0f}; yaw = kPi + 0.25f; return true; }
  if (after || (waiting && phaseTime_ >= 29.5f)) {
    p = kVanPark;
    yaw = kPi;
    lights = (waiting && phaseTime_ < 31.0f) ? 1.0f : 0.0f;
    return true;
  }
  if (!waiting || phaseTime_ < 19.0f) return false;
  lights = 1;
  float t = phaseTime_;
  const float laneZ = -29.4f;
  if (t < 25.0f) {  // along Route 9, slowing
    float k = (t - 19.0f) / 6.0f;
    float x = -70.0f + (6.0f + 70.0f) * (1 - (1 - k) * (1 - k));
    p = {x, 0, laneZ};
    yaw = -kPi * 0.5f;  // heading +x
    return true;
  }
  // the turn in, then creeping up to the curb
  float k = smooth01((t - 25.0f) / 4.5f);
  vec3 a{6, 0, laneZ}, b{13, 0, laneZ}, c{kVanPark.x, 0, -14}, d = kVanPark;
  p = bez(a, b, c, d, k);
  vec3 q = bez(a, b, c, d, std::min(1.0f, k + 0.01f)), q0 = bez(a, b, c, d, std::max(0.0f, k - 0.01f));
  yaw = yawOf(q - q0);
  return true;
}

void Game::buildStoreOutside() {
  if (!texLotOn_) {
    texLotOn_ = makeTexture(texgen::parkingLot(1536, 1024, 96, true), true, false);
    texLotOff_ = makeTexture(texgen::parkingLot(1536, 1024, 96, false), true, false);
    texSky_ = makeTexture(texgen::nightSky(2048, 512, 9), true, true);
    texSignQ_ = makeTexture(texgen::signText("QUIK-STOP", 1024, 160, 0.98f, 0.95f, 0.9f, 0.75f, 0.06f, 0.05f), true, false);
    texSignGas_ = makeTexture(texgen::signText("GAS 1.19", 512, 160, 1.0f, 0.75f, 0.2f, 0.04f, 0.04f, 0.05f), true, false);
    texSignVan_ = makeTexture(texgen::signText("RAY'S REPAIR", 1024, 128, 0.12f, 0.22f, 0.5f, 0.86f, 0.86f, 0.82f), true, false);
    texSignHours_ = makeTexture(texgen::signText("OPEN 24 HOURS", 512, 96, 0.8f, 0.08f, 0.06f, 0.92f, 0.9f, 0.86f), true, false);
    texSignIce_ = makeTexture(texgen::signText("ICE", 256, 128, 0.2f, 0.45f, 0.9f, 0.95f, 0.97f, 1.0f), true, false);
    texBrickOut_ = makeTexture(texgen::brick(256, 41), true, true);
    texGround_ = makeTexture(texgen::solid(14, 18, 14), false, false);
    // glass: mostly clear, a few smudges and handprints near the door
    Image g;
    g.w = g.h = 256;
    g.px.resize(256 * 256 * 4);
    for (int y = 0; y < 256; ++y)
      for (int x = 0; x < 256; ++x) {
        float n = 0.5f + 0.18f * std::sin(x * 0.05f + std::sin(y * 0.031f) * 3) + 0.12f * std::sin(y * 0.07f + x * 0.013f) + 0.08f * (hashf(x / 4, y / 4, 515) - 0.5f);
        float a = 18 + 40 * std::max(0.0f, n - 0.45f) + 10 * (1 - y / 255.0f);
        size_t i = ((size_t)y * 256 + x) * 4;
        g.px[i] = g.px[i + 1] = g.px[i + 2] = 255;
        g.px[i + 3] = (uint8_t)clampf(a, 0, 255);
      }
    texStoreGlass_ = makeTexture(g, true, false);
    // soft round glow for lamps and headlights
    Image r;
    r.w = r.h = 128;
    r.px.resize(128 * 128 * 4);
    for (int y = 0; y < 128; ++y)
      for (int x = 0; x < 128; ++x) {
        float dx = (x + 0.5f) / 64 - 1, dy = (y + 0.5f) / 64 - 1;
        float d = std::sqrt(dx * dx + dy * dy);
        float v = std::exp(-d * d * 6.0f) * 0.85f + std::exp(-d * d * 40.0f) * 0.15f;
        if (d > 1) v = 0;
        size_t i = ((size_t)y * 128 + x) * 4;
        r.px[i] = r.px[i + 1] = r.px[i + 2] = 255;
        r.px[i + 3] = (uint8_t)clampf(v * 255, 0, 255);
      }
    texGlow_ = makeTexture(r, true, false);
  }
  frontIn_.destroy();
  frontOut_.destroy();
  Mesh in, out;
  // Inside face uses the store's wall texture (world-metre UVs, like the chunk walls).
  auto rectIn = [&](float x0, float x1, float y0, float y1) {
    in.quad({x0, y0, kInZ}, {x1, y0, kInZ}, {x1, y1, kInZ}, {x0, y1, kInZ}, {0, 0, 1}, {x0, y0}, {x1, y0}, {x1, y1}, {x0, y1}, 1, 1, 1, 1);
  };
  auto rectOut = [&](float x0, float x1, float y0, float y1) {
    const float s = 1.0f;  // brick repeats every metre
    out.quad({x1, y0, kOutZ}, {x0, y0, kOutZ}, {x0, y1, kOutZ}, {x1, y1, kOutZ}, {0, 0, -1}, {x1 * s, y0 * s}, {x0 * s, y0 * s}, {x0 * s, y1 * s},
             {x1 * s, y1 * s}, 1, 1, 1, 1);
  };
  // reveals (the wall's thickness inside each opening) go with the inside mesh
  auto reveal = [&](vec3 a, vec3 b, vec3 n) {
    vec3 a2{a.x, a.y, kOutZ}, b2{b.x, b.y, kOutZ};
    vec3 a1{a.x, a.y, kInZ}, b1{b.x, b.y, kInZ};
    in.quad(a1, b1, b2, a2, n, {a.x + a.y, 0}, {b.x + b.y, 0}, {b.x + b.y, 0.16f}, {a.x + a.y, 0.16f}, 0.8f, 0.8f, 0.8f, 0.8f);
  };
  const float H = 3.2f;
  for (int t = 2; t <= 11; ++t) {
    float x0 = t * 2.0f, x1 = x0 + 2.0f, xc = x0 + 1.0f;
    int o = openingAt(t);
    if (o == 0) {
      rectIn(x0, x1, 0, H);
      rectOut(x0, x1, 0, kParapet);
      continue;
    }
    float hw = o == 2 ? 0.85f : 0.9f, ylo = o == 2 ? 0.0f : 0.75f, yhi = o == 2 ? 2.3f : 2.35f;
    rectIn(x0, xc - hw, 0, H);
    rectIn(xc + hw, x1, 0, H);
    rectIn(xc - hw, xc + hw, yhi, H);
    if (ylo > 0) rectIn(xc - hw, xc + hw, 0, ylo);
    rectOut(x0, xc - hw, 0, kParapet);
    rectOut(xc + hw, x1, 0, kParapet);
    rectOut(xc - hw, xc + hw, yhi, kParapet);
    if (ylo > 0) rectOut(xc - hw, xc + hw, 0, ylo);
    reveal({xc - hw, yhi, 0}, {xc + hw, yhi, 0}, {0, -1, 0});
    if (ylo > 0) reveal({xc + hw, ylo, 0}, {xc - hw, ylo, 0}, {0, 1, 0});
    reveal({xc - hw, ylo, 0}, {xc - hw, yhi, 0}, {1, 0, 0});
    reveal({xc + hw, yhi, 0}, {xc + hw, ylo, 0}, {-1, 0, 0});
  }
  frontIn_.upload(in);
  frontOut_.upload(out);
}

void Game::drawGlow(Shader& S, vec3 p, vec3 cam, float size, vec3 col, float strength) {
  vec3 n = cam - p;
  float d = length(n);
  if (d < 0.01f) return;
  n = n * (1.0f / d);
  vec3 r = normalize(cross(vec3{0, 1, 0}, n));
  vec3 u = cross(n, r);
  S.set("uTint", col);
  S.set("uEmissive", strength);
  S.set("uModel", frameM(r * size, u * size, n, p + n * 0.05f));
  quad_.draw();
}

void Game::drawCar(Shader& S, vec3 p, float yaw, vec3 paint, float lights, int kind, vec3 cam) {
  // kind 0 sedan, 1 Ray's van, 2 ambulance
  mat4 base = translate(p) * rotY(yaw);
  vec3 L = lotLight(p.x, p.z, storePowered());
  auto lit = [&](vec3 c) { return vec3{c.x * L.x, c.y * L.y, c.z * L.z}; };
  float len = kind == 0 ? 4.6f : 5.4f, wid = kind == 0 ? 1.8f : 2.05f, hgt = kind == 0 ? 0.75f : 1.75f;
  // forward is -z in model space (yaw 0 looks down -z, like everything else)
  S.set("uMat", MAT_PROP);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  auto part = [&](vec3 c, vec3 s, vec3 col, float em) { drawPart(base * translate(c) * scale(s), col, em); };
  part({0, 0.35f + hgt * 0.5f, 0}, {wid, hgt, len}, lit(paint), 0.9f);
  if (kind == 0) {
    part({0, 1.1f + 0.3f, 0.3f}, {wid - 0.12f, 0.6f, 2.2f}, {0.02f, 0.025f, 0.03f}, 0.03f);  // cabin glass
  } else {
    part({0, 1.55f, -len * 0.5f + 0.03f}, {wid - 0.2f, 0.75f, 0.06f}, {0.02f, 0.03f, 0.04f}, 0.05f);  // windshield
    for (int s = -1; s <= 1; s += 2) part({s * (wid * 0.5f + 0.01f), 1.55f, -len * 0.5f + 0.7f}, {0.04f, 0.6f, 0.9f}, {0.02f, 0.03f, 0.04f}, 0.05f);
  }
  for (int sx = -1; sx <= 1; sx += 2)
    for (int sz = -1; sz <= 1; sz += 2) part({sx * (wid * 0.5f - 0.05f), 0.34f, sz * (len * 0.5f - 0.85f)}, {0.25f, 0.68f, 0.68f}, {0.02f, 0.02f, 0.02f}, 0.0f);
  part({0, 0.45f, -len * 0.5f - 0.02f}, {wid - 0.1f, 0.18f, 0.08f}, {0.5f, 0.5f, 0.52f}, 0.08f);  // bumper
  // lamps
  for (int s = -1; s <= 1; s += 2) {
    part({s * (wid * 0.5f - 0.28f), 0.75f, -len * 0.5f - 0.02f}, {0.32f, 0.16f, 0.05f}, {1.0f, 0.95f, 0.85f}, 0.2f + lights * 9.0f);
    part({s * (wid * 0.5f - 0.2f), 0.85f, len * 0.5f + 0.02f}, {0.2f, 0.2f, 0.05f}, {1.0f, 0.06f, 0.04f}, 0.2f + lights * 3.0f);
  }
  if (kind == 2) {  // ambulance: red stripe, light bar
    part({0, 1.05f, 0}, {wid + 0.02f, 0.18f, len + 0.02f}, {0.85f, 0.05f, 0.04f}, 0.15f);
    bool red = std::fmod(time_, 0.6f) < 0.3f;
    for (int s = -1; s <= 1; s += 2) {
      bool on = (s < 0) == red;
      part({s * 0.45f, 2.18f, -len * 0.5f + 0.4f}, {0.6f, 0.14f, 0.25f}, s < 0 ? vec3{1, 0.05f, 0.04f} : vec3{0.1f, 0.25f, 1.0f}, on ? 14.0f : 0.3f);
    }
  }
  // signs on the van's flanks
  if (kind == 1) {
    S.set("uMat", MAT_SCREEN);
    S.set("uUVScale", 1.0f);
    glBindTexture(GL_TEXTURE_2D, texSignVan_);
    S.set("uEmissive", 0.08f + 0.5f * (L.x + L.y + L.z) / 3);
    for (int s = -1; s <= 1; s += 2) {
      vec3 n{(float)s, 0, 0};
      vec3 r = cross(vec3{0, 1, 0}, n);
      S.set("uModel", base * frameM(r * 3.2f, vec3{0, 0.5f, 0}, n, {s * (wid * 0.5f + 0.015f), 1.25f, 0.5f}));
      quad_.draw();
    }
  }
  // glows and the light thrown ahead
  if (lights > 0.01f || kind == 2) {
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glDepthMask(GL_FALSE);
    S.set("uMat", MAT_DECAL);
    S.set("uFlipU", 0);
    glBindTexture(GL_TEXTURE_2D, texGlow_);
    float c = std::cos(yaw), s = std::sin(yaw);
    auto W = [&](vec3 v) { return p + vec3{v.x * c + v.z * s, v.y, -v.x * s + v.z * c}; };
    if (lights > 0.01f) {
      for (int k = -1; k <= 1; k += 2) {
        drawGlow(S, W({k * (wid * 0.5f - 0.28f), 0.75f, -len * 0.5f - 0.1f}), cam, 0.9f, {1.0f, 0.93f, 0.8f}, 2.2f * lights);
        drawGlow(S, W({k * (wid * 0.5f - 0.2f), 0.85f, len * 0.5f + 0.1f}), cam, 0.35f, {1.0f, 0.1f, 0.05f}, 1.2f * lights);
      }
      // pool of headlight on the ground ahead
      vec3 g = W({0, 0.02f, -len * 0.5f - 4.5f});
      vec3 fw{-s, 0, -c};
      vec3 rt{c, 0, -s};
      S.set("uTint", vec3{1.0f, 0.92f, 0.78f});
      S.set("uEmissive", 0.55f * lights);
      S.set("uModel", frameM(rt * 4.5f, fw * 8.0f, {0, 1, 0}, g));
      quad_.draw();
    }
    if (kind == 2) {
      bool red = std::fmod(time_, 0.6f) < 0.3f;
      drawGlow(S, W({red ? -0.45f : 0.45f, 2.2f, -len * 0.5f + 0.4f}), cam, 2.6f, red ? vec3{1, 0.08f, 0.05f} : vec3{0.15f, 0.3f, 1.0f}, 2.5f);
    }
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
  }
}

void Game::drawStoreOutside(Shader& S, vec3 cam) {
  if (!frontIn_.count) buildStoreOutside();
  bool power = storePowered();
  glDisable(GL_CULL_FACE);
  S.set("uSkinned", 0);
  S.set("uUVScale", 1.0f);
  S.set("uFlipU", 0);

  // the front wall: inside like the rest of the store, brick outside
  S.set("uMat", MAT_WALL);
  S.set("uRough", 0.85f);
  S.set("uBump", 0.3f);
  S.set("uTint", vec3{1, 1, 1});
  S.set("uEmissive", 0.0f);
  S.set("uModel", mat4::identity());
  glBindTexture(GL_TEXTURE_2D, texWall_);
  frontIn_.draw();
  S.set("uBump", 0.0f);

  // Outside is clearer air than in here.
  S.set("uFogDensity", 0.0065f);
  S.set("uMat", MAT_SCREEN);
  glBindTexture(GL_TEXTURE_2D, texBrickOut_);
  S.set("uEmissive", power ? 0.32f : 0.1f);
  frontOut_.draw();
  // ground, lot, sky
  auto flat = [&](GLuint tex, float x0, float x1, float z0, float z1, float y, float em) {
    glBindTexture(GL_TEXTURE_2D, tex);
    S.set("uEmissive", em);
    S.set("uModel", frameM({x1 - x0, 0, 0}, {0, 0, z1 - z0}, {0, 1, 0}, {(x0 + x1) * 0.5f, y, (z0 + z1) * 0.5f}));
    quad_.draw();
  };
  flat(texGround_, -220, 250, 140, -140, -0.03f, 0.25f);
  // the lot texture's top row is the store side: v runs from z=4 (v=0) to z=-36 (v=1)
  glBindTexture(GL_TEXTURE_2D, power ? texLotOn_ : texLotOff_);
  S.set("uEmissive", 1.7f);
  S.set("uModel", frameM({60, 0, 0}, {0, 0, -40}, {0, 1, 0}, {14, 0.0f, -16}));
  quad_.draw();
  // sky all the way round, treeline included
  if (!skyRing_.count) {
    Mesh m;
    const int N = 64;
    const float R = 125.0f, y0 = -8.0f, y1 = 150.0f;
    for (int k = 0; k < N; ++k) {
      float a0 = k * 2 * kPi / N, a1 = (k + 1) * 2 * kPi / N;
      vec3 p0{std::cos(a0) * R, 0, std::sin(a0) * R}, p1{std::cos(a1) * R, 0, std::sin(a1) * R};
      float u0 = 3.0f * k / N, u1 = 3.0f * (k + 1) / N;
      m.quad({p0.x, y0, p0.z}, {p1.x, y0, p1.z}, {p1.x, y1, p1.z}, {p0.x, y1, p0.z}, normalize(p0 * -1.0f), {u0, 0}, {u1, 0}, {u1, 1}, {u0, 1}, 1, 1, 1, 1);
    }
    skyRing_.upload(m);
  }
  glBindTexture(GL_TEXTURE_2D, texSky_);
  S.set("uEmissive", 1.0f);
  S.set("uFogDensity", 0.0045f);
  S.set("uModel", translate({14, 0, -10}));
  skyRing_.draw();
  glBindTexture(GL_TEXTURE_2D, texGround_);
  S.set("uEmissive", 0.02f);
  S.set("uModel", frameM({260, 0, 0}, {0, 0, 260}, {0, -1, 0}, {14, 150, -10}));  // the top: just dark
  quad_.draw();
  S.set("uFogDensity", 0.0065f);

  // ---- props, lit by hand
  S.set("uMat", MAT_PROP);
  S.set("uRough", 0.6f);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  auto litPart = [&](vec3 c, vec3 s, vec3 col, float extra = 0) {
    vec3 L = lotLight(c.x, c.z, power);
    drawPart(translate(c) * scale(s), {col.x * L.x, col.y * L.y, col.z * L.z}, 0.9f + extra);
  };
  // the door swings out on a hinge at its left edge
  const float hingeX = 13.0f - 0.85f;
  mat4 leaf = translate({hingeX, 0, kFrontZ}) * rotY(doorOpen_ * 1.35f) * translate({0.85f, 0, 0});
  // window frames and mullions (dark bronze aluminium)
  vec3 bronze{0.16f, 0.14f, 0.12f};
  for (int t = 3; t <= 11; ++t) {
    float xc = t * 2.0f + 1.0f;
    bool door = openingAt(t) == 2;
    float hw = door ? 0.85f : 0.9f, ylo = door ? 0.0f : 0.75f, yhi = door ? 2.3f : 2.35f;
    litPart({xc, yhi - 0.03f, kFrontZ}, {hw * 2, 0.06f, 0.1f}, bronze);
    if (!door) litPart({xc, ylo + 0.03f, kFrontZ}, {hw * 2, 0.06f, 0.1f}, bronze);
    litPart({xc - hw + 0.03f, (ylo + yhi) * 0.5f, kFrontZ}, {0.06f, yhi - ylo, 0.1f}, bronze);
    litPart({xc + hw - 0.03f, (ylo + yhi) * 0.5f, kFrontZ}, {0.06f, yhi - ylo, 0.1f}, bronze);
    if (door) {  // push bar, kick plate and the leaf's own frame move with it
      vec3 L = lotLight(xc, kFrontZ - 1.0f, power);
      auto lp = [&](vec3 c, vec3 sz, vec3 col, float ex) { drawPart(leaf * translate(c) * scale(sz), {col.x * L.x, col.y * L.y, col.z * L.z}, 0.9f + ex); };
      lp({0, 1.05f, 0.07f}, {1.2f, 0.05f, 0.05f}, {0.7f, 0.7f, 0.72f}, 0.2f);
      lp({0, 1.05f, -0.07f}, {1.2f, 0.05f, 0.05f}, {0.7f, 0.7f, 0.72f}, 0.2f);
      lp({0, 0.12f, 0}, {1.66f, 0.22f, 0.07f}, bronze, 0);
      lp({0, 2.24f, 0}, {1.66f, 0.06f, 0.07f}, bronze, 0);
      lp({-0.8f, 1.15f, 0}, {0.06f, 2.3f, 0.07f}, bronze, 0);
      lp({0.8f, 1.15f, 0}, {0.06f, 2.3f, 0.07f}, bronze, 0);
    }
  }
  // sidewalk awning over the front
  litPart({14, 3.3f, 2.95f}, {20.4f, 0.22f, 2.1f}, {0.55f, 0.52f, 0.48f});
  litPart({14, 3.18f, 1.92f}, {20.4f, 0.4f, 0.06f}, {0.62f, 0.12f, 0.1f});
  for (float x : {6.0f, 12.0f, 16.0f, 22.0f}) {  // downlights
    drawPart(translate({x, 3.185f, 2.9f}) * scale({0.35f, 0.02f, 0.35f}), {1.0f, 0.97f, 0.9f}, power ? 6.0f : 0.05f);
  }
  litPart({4.1f, 1.6f, 2.0f}, {0.12f, 3.2f, 0.12f}, {0.5f, 0.5f, 0.5f});
  litPart({23.9f, 1.6f, 2.0f}, {0.12f, 3.2f, 0.12f}, {0.5f, 0.5f, 0.5f});
  // curb
  litPart({14, 0.06f, 1.92f}, {60.0f, 0.12f, 0.15f}, {0.5f, 0.5f, 0.48f});
  // sidewalk things: ice chest, trash can, newspaper box
  litPart({20.0f, 0.55f, 3.25f}, {1.6f, 1.1f, 0.8f}, {0.9f, 0.92f, 0.95f});
  litPart({10.6f, 0.45f, 3.3f}, {0.55f, 0.9f, 0.55f}, {0.25f, 0.28f, 0.22f});
  litPart({16.0f, 0.55f, 3.4f}, {0.5f, 1.1f, 0.45f}, {0.15f, 0.25f, 0.55f});

  // gas canopy and pumps
  vec3 cc{16, 0, -13};
  drawPart(translate(cc + vec3{0, 5.2f, 0}) * scale({13.0f, 0.06f, 8.0f}), {0.85f, 0.85f, 0.82f}, 0.9f);  // underside
  drawPart(translate(cc + vec3{0, 5.6f, 0}) * scale({13.2f, 0.75f, 8.2f}), {0.9f, 0.9f, 0.88f}, 0.35f);   // fascia
  for (int s = -1; s <= 1; s += 2) {
    drawPart(translate(cc + vec3{0, 5.42f, s * 4.11f}) * scale({13.22f, 0.18f, 0.02f}), {0.8f, 0.08f, 0.06f}, 1.0f);
    drawPart(translate(cc + vec3{s * 6.61f, 5.42f, 0}) * scale({0.02f, 0.18f, 8.22f}), {0.8f, 0.08f, 0.06f}, 1.0f);
  }
  for (int i = 0; i < 6; ++i) {
    float x = cc.x - 4.5f + (i % 3) * 4.5f, z = cc.z + (i < 3 ? -2.0f : 2.0f);
    drawPart(translate({x, 5.16f, z}) * scale({1.1f, 0.04f, 0.6f}), {1.0f, 1.0f, 0.95f}, 9.0f);
  }
  for (int s = -1; s <= 1; s += 2) {
    vec3 ip = cc + vec3{s * 3.5f, 0, 0};
    litPart(ip + vec3{0, 0.12f, 0}, {1.2f, 0.24f, 3.8f}, {0.55f, 0.55f, 0.52f});              // island
    litPart(ip + vec3{0, 2.7f, 0}, {0.35f, 5.0f, 0.35f}, {0.9f, 0.9f, 0.88f});                 // column
    for (int k = -1; k <= 1; k += 2) {
      vec3 pp = ip + vec3{0, 0, k * 1.1f};
      litPart(pp + vec3{0, 0.95f, 0}, {0.6f, 1.45f, 0.9f}, {0.85f, 0.12f, 0.1f});
      litPart(pp + vec3{0, 1.75f, 0}, {0.62f, 0.25f, 0.92f}, {0.92f, 0.92f, 0.9f});
      drawPart(translate(pp + vec3{0.31f, 1.25f, 0}) * scale({0.02f, 0.18f, 0.3f}), {0.4f, 0.9f, 0.5f}, 1.4f);
      drawPart(translate(pp + vec3{-0.31f, 1.25f, 0}) * scale({0.02f, 0.18f, 0.3f}), {0.4f, 0.9f, 0.5f}, 1.4f);
    }
  }
  // streetlights along Route 9
  for (float x : {-4.0f, 32.0f, 68.0f, -40.0f}) {
    vec3 b{x, 0, -26.5f};
    litPart(b + vec3{0, 4.0f, 0}, {0.18f, 8.0f, 0.18f}, {0.4f, 0.4f, 0.42f});
    litPart(b + vec3{0, 7.9f, -1.0f}, {0.1f, 0.1f, 2.0f}, {0.4f, 0.4f, 0.42f});
    drawPart(translate(b + vec3{0, 7.82f, -1.9f}) * scale({0.45f, 0.08f, 0.7f}), {1.0f, 0.6f, 0.25f}, 12.0f);
  }
  // the sign out by the road
  vec3 sp{36, 0, -21};
  for (int s = -1; s <= 1; s += 2) litPart(sp + vec3{s * 1.2f, 3.4f, 0}, {0.25f, 6.8f, 0.25f}, {0.5f, 0.5f, 0.5f});
  litPart(sp + vec3{0, 6.6f, 0}, {3.6f, 1.6f, 0.4f}, {0.3f, 0.3f, 0.3f});
  litPart(sp + vec3{0, 4.9f, 0}, {2.4f, 0.9f, 0.3f}, {0.3f, 0.3f, 0.3f});
  S.set("uMat", MAT_SCREEN);
  auto board = [&](GLuint tex, vec3 c, float w, float h, float em) {
    glBindTexture(GL_TEXTURE_2D, tex);
    S.set("uEmissive", em);
    S.set("uModel", frameM({w, 0, 0}, {0, h, 0}, {0, 0, 1}, c));
    quad_.draw();
  };
  board(texSignQ_, sp + vec3{0, 6.6f, 0.21f}, 3.5f, 1.5f, power ? 1.3f : 0.06f);
  board(texSignGas_, sp + vec3{0, 4.9f, 0.16f}, 2.3f, 0.8f, power ? 1.1f : 0.05f);
  // the store's own sign over the awning, seen from the lot (and its glow from inside)
  {
    glBindTexture(GL_TEXTURE_2D, texSignQ_);
    S.set("uEmissive", power ? 1.2f : 0.05f);
    S.set("uModel", frameM({-9.0f, 0, 0}, {0, 1.1f, 0}, {0, 0, -1}, {14, 3.95f, kOutZ - 0.02f}));
    quad_.draw();
    glBindTexture(GL_TEXTURE_2D, texSignIce_);
    S.set("uEmissive", 0.45f);
    S.set("uModel", frameM({-1.0f, 0, 0}, {0, 0.45f, 0}, {0, 0, -1}, {20.0f, 0.62f, 2.84f}));
    quad_.draw();
    // OPEN 24 HOURS sticker on the door glass, facing out (backwards from in here)
    glBindTexture(GL_TEXTURE_2D, texSignHours_);
    S.set("uEmissive", 0.35f);
    S.set("uModel", leaf * frameM({-0.55f, 0, 0}, {0, 0.1f, 0}, {0, 0, -1}, {0.0f, 1.5f, -0.04f}));
    quad_.draw();
  }

  // ---- cars on Route 9 (only while the world is still normal)
  if (storePhase_ == StorePhase::Shift || storePhase_ == StorePhase::WaitRay || storePhase_ == StorePhase::CallRay || storePhase_ == StorePhase::FindLight) {
    const float period = 17.0f;
    float tt = time_ + 5.0f;
    int slot = (int)std::floor(tt / period);
    for (int k = slot - 1; k <= slot; ++k) {
      if (hashf(k, 701) > 0.7f) continue;
      float lt = tt - k * period;
      bool east = hashf(k, 703) < 0.5f;
      float speed = 16.0f + 6.0f * hashf(k, 705);
      float x = east ? -90.0f + speed * lt : 120.0f - speed * lt;
      if (x < -95 || x > 125) continue;
      vec3 paint{hashf(k, 707) * 0.5f + 0.1f, hashf(k, 709) * 0.4f + 0.1f, hashf(k, 711) * 0.5f + 0.1f};
      drawCar(S, {x, 0, east ? -29.4f : -32.6f}, east ? -kPi * 0.5f : kPi * 0.5f, paint, 1.0f, 0, cam);
      if (A_ && k != lastCarSlot_ && std::fabs(x - 14.0f) < 6.0f) {
        lastCarSlot_ = k;
        A_->play(Sfx::Whoosh, 0.22f, east ? 0.4f : -0.4f);
      }
    }
  }
  // ---- Ray's van, and later the ambulance
  vec3 vp;
  float vy, vl;
  if (vanPose(vp, vy, vl)) drawCar(S, vp, vy, {0.82f, 0.82f, 0.78f}, vl, 1, cam);
  if (screen_ == Screen::Ending && ambulance_) drawCar(S, {12.0f, 0, -2.0f}, -kPi * 0.5f, {0.92f, 0.92f, 0.9f}, 1.0f, 2, cam);

  // ---- glows (additive) and the glass (alpha)
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE);
  glDepthMask(GL_FALSE);
  // a fine drizzle, only visible where the lights catch it
  S.set("uMat", MAT_DECAL);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  for (int i = 0; i < 420; ++i) {
    float hx = hashf(i, 31), hz = hashf(i, 37), ht = hashf(i, 41);
    float x = 2.0f + hx * 26.0f, z = 1.7f - hz * hz * 22.0f;
    float y = 9.0f - std::fmod(time_ * 8.5f + ht * 9.0f, 9.0f);
    vec3 L = lotLight(x, z, power);
    float b = (L.x + L.y + L.z) * 0.33f;
    if (z > -12.0f && z < -9.0f && x > 9.5f && x < 22.5f && y > 5.0f) continue;  // under the canopy roof
    vec3 c{x, y, z};
    vec3 n = normalize(vec3{cam.x - x, 0, cam.z - z});
    vec3 r = cross(vec3{0, 1, 0}, n);
    S.set("uTint", vec3{0.8f * L.x, 0.85f * L.y, 0.95f * L.z});
    S.set("uEmissive", 0.35f * b);
    S.set("uModel", frameM(r * 0.012f, vec3{0.05f, 0.55f, 0}, n, c));
    quad_.draw();
  }
  S.set("uFlipU", 0);
  glBindTexture(GL_TEXTURE_2D, texGlow_);
  for (float x : {-4.0f, 32.0f, 68.0f, -40.0f}) drawGlow(S, {x, 7.7f, -28.4f}, cam, 2.6f, {1.0f, 0.55f, 0.2f}, 1.3f);
  for (int i = 0; i < 6; ++i) {
    float x = cc.x - 4.5f + (i % 3) * 4.5f, z = cc.z + (i < 3 ? -2.0f : 2.0f);
    drawGlow(S, {x, 5.05f, z}, cam, 1.6f, {1.0f, 1.0f, 0.95f}, 0.6f);
  }
  if (power) {
    for (float x : {6.0f, 12.0f, 16.0f, 22.0f}) drawGlow(S, {x, 3.1f, 2.9f}, cam, 0.9f, {1.0f, 0.95f, 0.88f}, 0.8f);
    drawGlow(S, sp + vec3{0, 6.6f, 0.4f}, cam, 4.0f, {1.0f, 0.2f, 0.15f}, 0.35f);
  }
  // Ray's headlights pouring in through the glass as he pulls up
  if (vl > 0.01f && vp.z > -16.0f) {
    float k = vl * smooth01((vp.z + 16.0f) / 14.0f);
    S.set("uTint", vec3{1.0f, 0.93f, 0.8f});
    S.set("uEmissive", 0.45f * k);
    S.set("uModel", frameM({5.0f, 0, 0}, {0, 0, 9.0f}, {0, 1, 0}, {vp.x - 3.0f, 0.015f, 8.5f}));
    quad_.draw();
    S.set("uModel", frameM({5.0f, 0, 0}, {0, 0, 9.0f}, {0, 1, 0}, {vp.x - 1.0f, 0.016f, 8.0f}));
    quad_.draw();
  }
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glBindTexture(GL_TEXTURE_2D, texStoreGlass_);
  S.set("uTint", vec3{0.75f, 0.85f, 0.9f});
  S.set("uEmissive", power ? 0.07f : 0.03f);
  for (int t = 3; t <= 11; ++t) {
    float xc = t * 2.0f + 1.0f;
    bool door = openingAt(t) == 2;
    float hw = door ? 0.85f : 0.9f, ylo = door ? 0.0f : 0.75f, yhi = door ? 2.3f : 2.35f;
    if (door) S.set("uModel", leaf * frameM({1.6f, 0, 0}, {0, 2.12f, 0}, {0, 0, 1}, {0, 1.15f, 0}));
    else S.set("uModel", frameM({hw * 2, 0, 0}, {0, yhi - ylo, 0}, {0, 0, 1}, {xc, (ylo + yhi) * 0.5f, kFrontZ}));
    quad_.draw();
  }
  glDepthMask(GL_TRUE);
  glDisable(GL_BLEND);
  glEnable(GL_CULL_FACE);
  S.set("uFogDensity", level_.theme.fogDensity);
  S.set("uTint", vec3{1, 1, 1});
  S.set("uEmissive", 0.0f);
  S.set("uModel", mat4::identity());
}

// The door opens for whoever walks up to it; the lot has things you can't walk through;
// and past the road, you can't bring yourself to go.
void Game::outsideUpdate(float dt) {
  const vec3 doorPt{13.0f, 0, kFrontZ};
  bool someone = false;
  auto nearDoor = [&](vec3 p) { vec3 d = p - doorPt; d.y = 0; return length(d) < 1.6f; };
  if (nearDoor(pos_)) someone = true;
  for (const Npc& n : customers_) if (n.active && nearDoor(n.pos)) someone = true;
  if (ray_.active && nearDoor(ray_.pos)) someone = true;
  float before = doorOpen_;
  doorOpen_ += ((someone ? 1.0f : 0.0f) - doorOpen_) * std::min(1.0f, dt * (someone ? 4.0f : 2.5f));
  if (A_ && before < 0.15f && doorOpen_ >= 0.15f && nearDoor(pos_)) A_->play(Sfx::Chime, 0.45f, 0.0f);
  if (before > 0.2f && doorOpen_ <= 0.2f && A_) A_->play(Sfx::Slam, 0.08f);

  // solid things out in the lot
  bool outside = pos_.z < kFrontZ - 0.2f && pos_.z > -40.0f;
  if (outside) {
    auto pushBox = [&](vec3 c, float yaw, float hx, float hz) {
      float co = std::cos(yaw), si = std::sin(yaw);
      vec3 d = pos_ - c;
      float lx = d.x * co - d.z * si, lz = d.x * si + d.z * co;  // into the box's frame
      const float r = 0.3f;
      float px = clampf(lx, -hx, hx), pz = clampf(lz, -hz, hz);
      float ex = lx - px, ez = lz - pz;
      float dd = std::sqrt(ex * ex + ez * ez);
      if (dd >= r) return;
      if (dd < 1e-4f) {  // inside: out the nearest side
        float ox = hx - std::fabs(lx), oz = hz - std::fabs(lz);
        if (ox < oz) lx = (lx < 0 ? -1 : 1) * (hx + r); else lz = (lz < 0 ? -1 : 1) * (hz + r);
      } else {
        lx = px + ex / dd * r;
        lz = pz + ez / dd * r;
      }
      pos_.x = c.x + lx * co + lz * si;
      pos_.z = c.z - lx * si + lz * co;
    };
    vec3 vp;
    float vy, vl;
    if (vanPose(vp, vy, vl)) pushBox(vp, vy, 1.05f, 2.75f);
    if (screen_ == Screen::Ending && ambulance_) pushBox({12.0f, 0, -2.0f}, -kPi * 0.5f, 1.05f, 2.75f);
    for (int sd = -1; sd <= 1; sd += 2) pushBox({16.0f + sd * 3.5f, 0, -13.0f}, 0, 0.6f, 1.9f);  // pump islands
    pushBox({20.0f, 0, 3.25f}, 0, 0.8f, 0.4f);   // ice chest
    pushBox({10.6f, 0, 3.3f}, 0, 0.28f, 0.28f);  // trash can
    pushBox({16.0f, 0, 3.4f}, 0, 0.25f, 0.23f);  // newspaper box
    pushBox({4.1f, 0, 2.0f}, 0, 0.08f, 0.08f);   // awning posts
    pushBox({23.9f, 0, 2.0f}, 0, 0.08f, 0.08f);
    for (int sd = -1; sd <= 1; sd += 2) pushBox({36.0f + sd * 1.2f, 0, -21.0f}, 0, 0.13f, 0.13f);  // sign poles
    for (float x : {-4.0f, 32.0f}) pushBox({x, 0, -26.5f}, 0, 0.1f, 0.1f);  // streetlights
    // the edge of what you can make yourself walk to
    leaveMsgT_ -= dt;
    if ((pos_.z < -34.5f || pos_.x < -14.5f || pos_.x > 42.5f) && leaveMsgT_ <= 0) {
      leaveMsgT_ = 25.0f;
      static const char* kStay[] = {"(I can't just leave. Not in the middle of a shift.)", "(Route 9 goes on forever in the dark. I'm not walking it.)",
                                    "(If I go, nobody's watching the store.)"};
      say("DANA", kStay[rng_.next() % 3], 3.0f);
    }
  }
  if (outside && !wasOutside_ && storePhase_ == StorePhase::Shift) {
    bool waiting = false;
    for (const Npc& n : customers_) if (n.active && n.state == 4) waiting = true;
    if (waiting) say("CUSTOMER", "Hey! HEY! Where are you going?!", 2.4f);
  }
  wasOutside_ = outside;
}
