// The start: Saturday afternoon at Route 9 Park. You're nine. Mom and Dad are at the
// tables by the front, other kids are bouncing, the music's loud. One of the beds against the back
// wall has a pad that's come away from the wall, and there's a dark gap down the side of it that goes
// a lot further down than it should. Get close enough and you slip in (the level's "exit" is that gap).
#include <algorithm>
#include <cmath>
#include <cstdlib>

#include "audio.h"
#include "game.h"
#include "texgen.h"
#include "voices_data.h"

namespace {
const float kBedY = 0.042f;  // the bed's resting height
// skin, hair, top, legs
const vec4 kDadLook[4] = {{0.62f, 0.46f, 0.36f, 0}, {0.16f, 0.11f, 0.07f, 0}, {0.18f, 0.3f, 0.22f, 0}, {0.16f, 0.17f, 0.22f, 0}};
const vec4 kMomLook[4] = {{0.66f, 0.5f, 0.4f, 0}, {0.32f, 0.2f, 0.1f, 0}, {0.62f, 0.2f, 0.26f, 0}, {0.08f, 0.09f, 0.14f, 0}};
const vec4 kKidLooks[6][4] = {
    {{0.62f, 0.45f, 0.35f, 0}, {0.3f, 0.2f, 0.1f, 0}, {0.85f, 0.2f, 0.12f, 0}, {0.12f, 0.15f, 0.3f, 0}},
    {{0.42f, 0.28f, 0.2f, 0}, {0.05f, 0.04f, 0.03f, 0}, {0.12f, 0.45f, 0.8f, 0}, {0.2f, 0.2f, 0.22f, 0}},
    {{0.7f, 0.55f, 0.45f, 0}, {0.75f, 0.6f, 0.3f, 0}, {0.95f, 0.8f, 0.15f, 0}, {0.3f, 0.12f, 0.35f, 0}},
    {{0.55f, 0.38f, 0.28f, 0}, {0.1f, 0.07f, 0.05f, 0}, {0.2f, 0.65f, 0.3f, 0}, {0.1f, 0.1f, 0.12f, 0}},
    {{0.66f, 0.5f, 0.4f, 0}, {0.45f, 0.25f, 0.1f, 0}, {0.9f, 0.45f, 0.65f, 0}, {0.15f, 0.2f, 0.4f, 0}},
    {{0.35f, 0.24f, 0.17f, 0}, {0.04f, 0.03f, 0.03f, 0}, {0.95f, 0.95f, 0.92f, 0}, {0.6f, 0.15f, 0.12f, 0}},
};
}  // namespace

namespace {
uint32_t fnv1a(const std::string& s) {
  uint32_t h = 2166136261u;
  for (unsigned char c : s) { h ^= c; h *= 16777619u; }
  return h;
}
const int kAdpcmSteps[89] = {7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118,
    130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166,
    1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845,
    8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767};
const int kAdpcmIdx[8] = {-1, -1, -1, -1, 2, 4, 6, 8};
int findClip(uint32_t key) {
  for (int i = 0; i < kVoiceClipCount; ++i) if (kVoiceClips[i].key == key) return i;
  return -1;
}
}  // namespace

// Every spoken line has a recorded voice (tools/make_voices.py), packed as IMA ADPCM; unpack them once.
void Game::loadVoices() {
  voicePcm_.assign(kVoiceClipCount, {});
  for (int c = 0; c < kVoiceClipCount; ++c) {
    const VoiceClipData& v = kVoiceClips[c];
    std::vector<int16_t>& out = voicePcm_[c];
    out.resize(v.samples);
    int pred = 0, idx = 0;
    for (uint32_t i = 0; i < v.samples; ++i) {
      int code = (v.adpcm[i >> 1] >> ((i & 1) * 4)) & 15;
      int step = kAdpcmSteps[idx];
      int d = step >> 3;
      if (code & 4) d += step;
      if (code & 2) d += step >> 1;
      if (code & 1) d += step >> 2;
      pred = std::clamp(code & 8 ? pred - d : pred + d, -32768, 32767);
      idx = std::clamp(idx + kAdpcmIdx[code & 7], 0, 88);
      out[i] = (int16_t)pred;
    }
  }
}

float Game::speak(const std::string& who, const std::string& text) {
  if (!A_ || voicePcm_.empty()) return 0.0f;
  int c = findClip(fnv1a(text));
  if (c < 0) return 0.0f;
  // how it sounds depends on where it's coming from
  int fx = 0;
  float gain = 0.9f, pan = 0.0f;
  if (who.find("PHONE") != std::string::npos || who == "PA" || who == "NEWS") fx = 1;  // through a speaker
  else if (!text.empty() && text[0] == '(') { fx = 2; gain = 0.65f; }
  else if (who == "???" || who == "RAY?") fx = 3;
  else if (who.find("FAR") != std::string::npos) { fx = 4; gain = 0.6f; }
  if (who.find("TO THE LEFT") != std::string::npos) pan = -0.6f;
  else if (who.find("TO THE RIGHT") != std::string::npos) pan = 0.6f;
  return A_->playClip(voicePcm_[c].data(), (int)voicePcm_[c].size(), (int)kVoiceClips[c].rate, gain, pan, fx);
}

void Game::say(const std::string& who, const std::string& text, float dur) {
  if (dur <= 0) dur = 1.6f + text.size() * 0.055f;
  lines_.push_back({who, text, dur});
}

void Game::parkBegin() {
  parkT_ = 0;
  parkCue_ = 0;
  parkBounces_ = 0;
  scarAmt_ = 0;  // a clean tape
  lines_.clear();
  lineTime_ = 0;
  hintTimer_ = 0;
  flashOn_ = false;
  hasFlashlight_ = false;
  parkFamily_ = parkKids_ = true;
  toast_ = "ROUTE 9 PARK - SATURDAY";
  if (A_) A_->play(Sfx::RecClick, 0.8f);  // REC
  toastTime_ = 4.0f;
}

void Game::parkUpdate(float dt) {
  parkT_ += dt;
  auto cue = [&](int i, float at) {
    if (parkT_ >= at && !(parkCue_ & (1 << i))) { parkCue_ |= 1 << i; return true; }
    return false;
  };
  if (cue(0, 0.6f)) say("DAD", "Go on, bud. Shoes in the cubbies. We'll be right here.", 3.6f);
  if (cue(1, 4.6f)) say("MOM", "Stay where we can see you, okay? Ten minutes!", 3.4f);
  if (cue(2, 9.0f)) { toast_ = "GO BOUNCE. (SPACE TO BOUNCE, SPACE AT THE BOTTOM FOR A BIG ONE)"; toastTime_ = 5.0f; }
  // after a while: something about that back wall
  vec3 gap = level_.exitFaceCenter();
  vec3 d = level_.delta(pos_, gap);
  float dist = std::sqrt(d.x * d.x + d.z * d.z);
  if (cue(3, 26.0f)) {
    say("YOU", "(There's a gap behind that pad by the back wall. It's really dark down there.)", 4.2f);
    toast_ = "THE BACK WALL. BEHIND THE PADS.";
    toastTime_ = 5.0f;
  }
  if (dist < 6.0f && cue(4, 0.0f)) say("YOU", "(It's cold coming out of it. Like a fridge. And humming.)", 3.6f);
  if (dist < 3.0f && cue(5, 0.0f)) say("MOM", "...hon? Don't go too far!", 2.6f);
  if (cue(6, 75.0f)) say("DAD", "Five more minutes, then pizza!", 3.0f);
  // the crowd: kids shouting on the court, a parent calling out, from wherever they are
  crowdT_ -= dt;
  if (crowdT_ <= 0.0f && A_ && parkKids_ && !voicePcm_.empty()) {
    crowdT_ = rng_.range(2.5f, 6.5f);
    static const char* kKid[] = {"Mom! Mom, look!", "Watch this!", "Again! Again!", "Do a flip!", "No fair!", "You're it!",
        "I can go higher than you!", "Look how high!", "Wait for me!", "Can we stay longer?", "Ow! You bumped me!", "My turn!",
        "Whoa!", "Ha! Got you!", "Dad! Watch!", "One more time!"};
    static const char* kAdult[] = {"Careful, buddy!", "Five more minutes!", "Only one on a trampoline!", "Where are your socks?",
        "Jessica, slow down!", "Good job!", "Not so high, okay?", "Who wants pizza after?"};
    const Level::ParkSpots& pk = level_.park;
    bool adult = rng_.f01() < 0.3f && !pk.adults.empty();
    vec3 from = adult ? pk.adults[rng_.next() % pk.adults.size()] : (pk.kids.empty() ? pos_ : pk.kids[rng_.next() % pk.kids.size()]);
    std::string t = adult ? kAdult[rng_.next() % 8] : kKid[rng_.next() % 16];
    int c = findClip(fnv1a("@crowd:" + t));
    if (c >= 0) {
      vec3 d = level_.delta(pos_, from);
      float dist = std::sqrt(d.x * d.x + d.z * d.z);
      vec3 rt = normalize(cross(forward(), vec3{0, 1, 0}));
      float pan = clampf((d.x * rt.x + d.z * rt.z) / std::max(dist, 0.5f), -1.0f, 1.0f);
      A_->playClip(voicePcm_[c].data(), (int)voicePcm_[c].size(), (int)kVoiceClips[c].rate, clampf(1.6f / (1.0f + dist * 0.25f), 0.08f, 0.7f), pan, dist > 9.0f ? 4 : 0);
    }
  }
}

void Game::parkDraw(Shader& S, vec3 cam) {
  const Level::ParkSpots& pk = level_.park;
  S.set("uMat", MAT_MODEL);
  S.set("uSkinned", 0);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  // Mom and Dad at the tables, watching you
  if (parkFamily_) {
    AnimInput in;
    in.time = time_;
    vec3 to = level_.delta(pk.dad, pos_);
    float look = std::atan2(-to.x, -to.z) - pk.dadYaw;
    in.look = clampf(std::remainder(look, 2.0f * kPi), -0.8f, 0.8f);
    in.cross = std::fmod(time_, 24.0f) < 13.0f ? 1.0f : 0.0f;  // arms folded a while, then down
    drawCreature(S, CR_HUMAN, pk.dad, pk.dadYaw, in, 0, kDadLook);
    AnimInput im;
    im.time = time_ + 3.0f;
    vec3 tm = level_.delta(pk.mom, pos_);
    im.look = clampf(std::remainder(std::atan2(-tm.x, -tm.z) - pk.momYaw, 2.0f * kPi), -0.9f, 0.9f);
    im.cross = 1.0f;
    drawCreatureAt(S, CR_HUMAN, translate(near(pk.mom, cam)) * rotY(pk.momYaw) * scale({0.96f, 0.95f, 0.96f}), im, 0, kMomLook);
  }
  // other parents round the court: arms folded, hands in pockets, watching their own kids
  for (size_t k = 0; k < pk.adults.size() && parkFamily_; ++k) {
    uint32_t h = (uint32_t)k * 2654435761u + 77u;
    auto pick = [&](int sh) { return (float)((h >> sh) & 255) / 255.0f; };
    vec4 look[4];
    const vec4 skins[4] = {{0.68f, 0.52f, 0.42f, 0}, {0.5f, 0.35f, 0.26f, 0}, {0.36f, 0.24f, 0.17f, 0}, {0.72f, 0.58f, 0.48f, 0}};
    const vec4 hairs[4] = {{0.12f, 0.08f, 0.05f, 0}, {0.35f, 0.24f, 0.12f, 0}, {0.04f, 0.035f, 0.03f, 0}, {0.55f, 0.5f, 0.45f, 0}};
    const vec4 tops[6] = {{0.75f, 0.74f, 0.7f, 0}, {0.14f, 0.2f, 0.36f, 0}, {0.5f, 0.12f, 0.12f, 0}, {0.3f, 0.36f, 0.24f, 0}, {0.85f, 0.6f, 0.2f, 0}, {0.1f, 0.1f, 0.11f, 0}};
    const vec4 legs[4] = {{0.18f, 0.22f, 0.34f, 0}, {0.42f, 0.36f, 0.26f, 0}, {0.1f, 0.1f, 0.12f, 0}, {0.55f, 0.5f, 0.42f, 0}};
    look[0] = skins[(h >> 3) % 4]; look[1] = hairs[(h >> 7) % 4]; look[2] = tops[(h >> 11) % 6]; look[3] = legs[(h >> 15) % 4];
    AnimInput in;
    in.time = time_ + k * 2.3f;
    int pose = (int)((h >> 19) % 3);
    if (pose == 1) in.cross = 1.0f;    // arms folded (the rest stand with their hands down)
    in.look = 0.5f * std::sin(time_ * 0.23f + k * 1.9f);  // following a kid round the court
    float sc = 0.92f + 0.12f * pick(23);
    float yaw = kPi + pk.adultYaw[k];  // facing the court (north)
    drawCreatureAt(S, CR_HUMAN, translate(near(pk.adults[k], cam)) * rotY(yaw) * scale({sc, sc, sc}), in, 0, look);
  }
  // The other kids. Each one rides the bed like a spring: a short contact where the bed sinks under
  // them and their knees fold, then a long arc through the air, arms going up; heavier/higher kids
  // sink deeper. Real children's bodies (CR_KID, CR_KIDLONG), five to nine years old.
  bedDents_.clear();
  for (size_t k = 0; k < pk.kids.size() && parkKids_; ++k) {
    uint32_t hh = (uint32_t)k * 2246822519u + 3u;
    auto rnd = [&](int sh) { return (float)((hh >> sh) % 1000) / 1000.0f; };
    bool standing = (hh >> 12) % 7 == 0;
    float H = 0.3f + 0.55f * rnd(9);               // apex height
    const float c = 0.3f;                          // fraction of the cycle on the bed
    float P = 2.0f * std::sqrt(2.0f * H / 9.8f) / (1.0f - c);
    float u = std::fmod(time_ / P + rnd(4), 1.0f);
    static const bool sinkAll = std::getenv("BR9_KIDSINK") != nullptr;  // screenshots: everyone at the bottom of a bounce
    if (sinkAll) u = c * 0.5f;
    float sc = 0.84f + 0.24f * rnd(16);              // 1.05 to 1.35 m
    float D = (0.12f + 0.08f * H) * (sc / 0.95f);  // how far the bed gives under them
    float y, sink = 0.0f;
    AnimInput in;
    in.time = time_ + k;
    if (standing) { y = -0.035f; sink = 0.035f; }
    else if (u < c) { float w = std::sin(kPi * u / c); y = -D * w; sink = D * w; in.squat = w * clampf(D / 0.2f, 0.45f, 1.0f); }
    else { float v = (u - c) / (1.0f - c); y = H * 4.0f * v * (1.0f - v); in.air = v; }
    vec3 wp = pk.kids[k];
    if (sink > 0.0f) bedDents_.push_back({wp, sink});
    vec3 p = near(wp, cam) + vec3{0, kBedY + y, 0};
    float yaw = standing ? kPi * 0.5f * (float)(k % 4) : time_ * (k % 2 ? 0.4f : -0.3f) + k;
    CreatureId body = ((hh >> 26) & 1) ? CR_KIDLONG : CR_KID;
    static const char* kidFace = std::getenv("BR9_KIDFACE");  // screenshots: "0"/"1" picks the body; everyone stands and looks at you
    if (kidFace) {
      body = kidFace[0] == '1' ? CR_KIDLONG : CR_KID;
      in = AnimInput();
      in.time = time_ + k;
      p = near(wp, cam) + vec3{0, kBedY - 0.035f, 0};
      vec3 d = cam - p;
      yaw = std::atan2(-d.x, -d.z) + (std::getenv("BR9_KIDTURN") ? (float)std::atof(std::getenv("BR9_KIDTURN")) : 0.0f);
      if (std::getenv("BR9_KIDSC")) sc = (float)std::atof(std::getenv("BR9_KIDSC"));
      if (std::getenv("BR9_KIDAIR")) { in.air = (float)std::atof(std::getenv("BR9_KIDAIR")); }
      if (std::getenv("BR9_KIDSQUAT")) { in.squat = (float)std::atof(std::getenv("BR9_KIDSQUAT")); }
    }
    drawCreatureAt(S, body, translate(p) * rotY(yaw) * scale({sc, sc, sc}), in, 0, kKidLooks[(hh >> 20) % 6]);
  }
  // and you: the bed sinks under you too
  if (onBed_ && jumpY_ < 0.0f) bedDents_.push_back({pos_, -jumpY_});
  drawBeds(S, cam);
  // the gap: a black slot between the back pad and the wall, going down
  {
    vec3 c = near(level_.tileCenter(pk.crevX, pk.crevZ), cam);
    S.set("uMat", MAT_PROP);
    drawPart(translate(c + vec3{0, -0.394f, -0.76f}) * scale({2.0f, 0.8f, 0.33f}), {0.0f, 0.0f, 0.0f});  // its top just over the floor
    S.set("uMat", MAT_MODEL);
  }
  // the foam pit
  buildBallPatch();
  for (int z = pk.z0; z <= pk.z1; ++z)
    for (int x = pk.x0; x <= pk.x1; ++x) {
      if (!level_.isFoam(x, z)) continue;
      vec3 o = near(vec3{x * Level::kTile, 0, z * Level::kTile}, cam);
      drawModel(S, ballPatch_, translate(o) * scale({1.0f, 2.2f, 1.0f}));
      drawModel(S, ballPatch_, translate(o + vec3{0.04f, 0.1f, 0.05f}) * scale({1.0f, 2.2f, 1.0f}));
    }
  S.set("uModel", mat4::identity());
}

// The trampoline beds: black polypropylene stretched inside the padded frames. Flat ones are a single
// quad; any bed with somebody on it is drawn as a fine grid that sinks in a cone under them, pinned
// at the frame, so you can see it give.
void Game::drawBeds(Shader& S, vec3 cam) {
  const Level::ParkSpots& pk = level_.park;
  Mesh m;
  for (int z = pk.z0; z <= pk.z1; ++z)
    for (int x = pk.x0; x <= pk.x1; ++x) {
      if (!level_.isBed(x, z)) continue;
      vec3 wc = level_.tileCenter(x, z);
      vec3 c = near(wc, cam);
      vec3 dc = c - cam;
      if (dc.x * dc.x + dc.z * dc.z > 45.0f * 45.0f) continue;
      bool gap = x == pk.crevX && z == pk.crevZ;
      const float x0 = -0.68f, x1 = 0.68f, z0 = gap ? -0.29f : -0.68f, z1 = 0.68f;
      // dents on this bed, in its local coordinates
      vec3 dl[4]; float dd[4]; int nd = 0;
      for (const BedDent& d : bedDents_) {
        vec3 l = level_.delta(wc, d.pos);
        if (l.x > x0 - 0.1f && l.x < x1 + 0.1f && l.z > z0 - 0.1f && l.z < z1 + 0.1f && nd < 4) { dl[nd] = l; dd[nd] = d.depth; ++nd; }
      }
      auto h = [&](float lx, float lz) {
        float y = kBedY;
        float edge = smoothstepf(0.0f, 0.32f, std::min(std::min(lx - x0, x1 - lx), std::min(lz - z0, z1 - lz)));
        for (int k = 0; k < nd; ++k) {
          float r = std::sqrt((lx - dl[k].x) * (lx - dl[k].x) + (lz - dl[k].z) * (lz - dl[k].z));
          float f = std::max(0.0f, 1.0f - r / 0.95f);
          y -= dd[k] * std::pow(f, 1.4f) * edge;
        }
        return y;
      };
      int N = nd ? 18 : 1;
      for (int j = 0; j < N; ++j)
        for (int i = 0; i < N; ++i) {
          float ax = x0 + (x1 - x0) * i / N, bx = x0 + (x1 - x0) * (i + 1) / N;
          float az = z0 + (z1 - z0) * j / N, bz = z0 + (z1 - z0) * (j + 1) / N;
          vec3 p00{c.x + ax, c.y + h(ax, az), c.z + az}, p10{c.x + bx, c.y + h(bx, az), c.z + az};
          vec3 p11{c.x + bx, c.y + h(bx, bz), c.z + bz}, p01{c.x + ax, c.y + h(ax, bz), c.z + bz};
          vec3 n = normalize(cross(p01 - p00, p10 - p00));
          if (n.y < 0) n = n * -1.0f;
          m.quad(p01, p11, p10, p00, n, {ax, bz}, {bx, bz}, {bx, az}, {ax, az}, 1, 1, 1, 1);
        }
    }
  if (m.v.empty()) return;
  bedMesh_.upload(m);
  S.set("uMat", MAT_PROP);
  S.set("uModel", mat4::identity());
  S.set("uTint", vec3{0.05f, 0.05f, 0.056f});
  S.set("uEmissive", 0.0f);
  S.set("uRough", 0.3f);  // the polypropylene has a sheen that bends round the dip
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  glDisable(GL_CULL_FACE);
  bedMesh_.draw();
  glEnable(GL_CULL_FACE);
  S.set("uRough", 0.6f);
  S.set("uMat", MAT_MODEL);
}
