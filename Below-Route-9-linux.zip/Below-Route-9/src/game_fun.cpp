// FUN MODE: unlocked by seeing an ending. Straight into Level 0 with a cheat menu (TAB), a pistol for
// the things down there, and Quake-style bunny-hopping. Never touches the story save.
#include <algorithm>
#include <cmath>
#include <cstdio>

#include "creatures.h"
#include "game.h"

void Game::startFunMode() {
  endless_ = false;
  runOverShow_ = false;
  int keep = opt_.level;
  opt_.level = 0;  // skip the park: straight down to the Lobby
  startNewGame();
  opt_.level = keep;
  funMode_ = true;
  cheats_ = Cheats();
  kills_ = 0;
  toast_ = "FUN MODE   TAB: CHEATS   CLICK: SHOOT   HOLD SPACE: BHOP";
  toastTime_ = 6.0f;
}

void Game::fireGun() {
  if (gunCool_ > 0.0f || hiding_ >= 0) return;
  gunCool_ = 0.2f;
  gunKick_ = 1.0f;
  muzzle_ = 1.0f;
  jolt_ = std::max(jolt_, 0.12f);   // the tape jumps a little with every shot
  pitch_ = std::min(pitch_ + 0.03f, 1.45f);  // recoil
  noiseRadius_ = std::max(noiseRadius_, 30.0f);  // everything down here heard that
  noiseHold_ = 1.0f;
  if (A_) A_->play(Sfx::Gunshot, 1.0f, 0.0f, 0.95f + rng_.f01() * 0.1f);

  vec3 o = eye(), d = forward();
  float best = 45.0f;
  int hitS = -1, hitG = -1;
  auto test = [&](vec3 base, float radius, float height) -> float {  // ray against an upright cylinder
    vec3 c = level_.nearest(base, o);
    vec2 oc{o.x - c.x, o.z - c.z}, dd{d.x, d.z};
    float a = dd.x * dd.x + dd.y * dd.y;
    if (a < 1e-6f) return -1.0f;
    float bq = oc.x * dd.x + oc.y * dd.y, cq = oc.x * oc.x + oc.y * oc.y - radius * radius;
    float disc = bq * bq - a * cq;
    if (disc < 0.0f) return -1.0f;
    float t = (-bq - std::sqrt(disc)) / a;
    if (t < 0.0f) t = (-bq + std::sqrt(disc)) / a;
    if (t < 0.0f) return -1.0f;
    float y = o.y + d.y * t;
    if (y < c.y || y > c.y + height) return -1.0f;
    vec3 h = o + d * t;
    if (!level_.lineOfSight(o.x, o.z, h.x, h.z, true)) return -1.0f;  // a wall's in the way
    return t;
  };
  for (int i = 0; i < (int)stalkers_.size(); ++i) {
    const Stalker& s = stalkers_[i];
    if (!s.active()) continue;
    float h = s.kind == CR_HOUND ? 0.9f : 2.5f;
    vec3 base = s.pos;
    base.y = level_.floorAt(s.pos.x, s.pos.z);
    float t = test(base, s.kind == CR_HOUND ? 0.5f : 0.42f, h);
    if (t > 0.0f && t < best) { best = t; hitS = i; hitG = -1; }
  }
  for (int i = 0; i < (int)grins_.size(); ++i) {
    if (!grins_[i].active) continue;
    float t = test(grins_[i].pos, 0.45f, 2.4f);
    if (t > 0.0f && t < best) { best = t; hitG = i; hitS = -1; }
  }
  if (hitS < 0 && hitG < 0) return;
  vec3 at = hitS >= 0 ? stalkers_[hitS].pos : grins_[hitG].pos;
  vec3 to = level_.delta(pos_, at);
  vec3 rt{std::cos(yaw_), 0, -std::sin(yaw_)};
  float pan = length(to) > 0.01f ? dot(normalize(to), rt) : 0.0f;
  if (hitS >= 0) { stalkers_[hitS].state = Stalker::Dormant; stalkers_[hitS].hunt = 0; }
  if (hitG >= 0) grins_[hitG].active = false;
  ++kills_;
  hitMark_ = 0.35f;
  if (A_) { A_->play(Sfx::Grunt, 1.0f, pan, 0.55f); A_->play(Sfx::HeavyStep, 1.2f, pan, 0.6f); }
  toast_ = "DOWN";
  toastTime_ = 1.2f;
}

void Game::drawGun(Shader& S, vec3 camPos, vec3 camDir) {
  if (!funLevel() || !cheats_.gun || hiding_ >= 0) return;
  if (screen_ != Screen::Playing && screen_ != Screen::Paused) return;
  vec3 f = normalize(camDir);
  vec3 rt = normalize(cross(f, camUp_));
  vec3 up = cross(rt, f);
  float k = gunKick_;
  float sway = std::sin(stepPhase_ * kPi) * 0.006f * clampf(length(vel_) / 2.5f, 0.0f, 1.5f);
  vec3 p = camPos + f * (0.40f - 0.07f * k) + rt * (0.165f + sway) + up * (-0.15f + 0.012f * k + std::fabs(sway) * 0.6f);
  mat4 M = mat4::identity();
  M.m[0] = rt.x; M.m[1] = rt.y; M.m[2] = rt.z;
  M.m[4] = up.x; M.m[5] = up.y; M.m[6] = up.z;
  M.m[8] = -f.x; M.m[9] = -f.y; M.m[10] = -f.z;
  // aimed a hair inward, at the middle of the picture; the kick lifts the muzzle
  drawModel(S, creatures::prop(PR_GUN), translate(p) * M * rotY(-0.13f) * rotX(0.05f + 0.32f * k) * rotZ(0.1f));
}
