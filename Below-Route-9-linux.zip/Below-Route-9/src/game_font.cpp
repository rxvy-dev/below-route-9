// The VCR OSD Mono font (title cards, the camcorder overlay, the menus), drawn from an alpha
// atlas baked by tools/make_title_font.py.
#include <algorithm>
#include <cmath>

#include "game.h"
#include "title_font.h"

namespace {
const TFontGlyph* glyphFor(char c) {
  static const TFontGlyph* table[128] = {};
  static bool init = false;
  if (!init) {
    for (const TFontGlyph& g : kTFontGlyphs) if ((unsigned char)g.c < 128) table[(unsigned char)g.c] = &g;
    init = true;
  }
  unsigned char u = (unsigned char)c;
  if (u >= 128) u = '?';
  return table[u] ? table[u] : table[(unsigned char)' '];
}
}  // namespace

void Game::ensureVcrFont() {
  if (texVcr_) return;
  Image im;
  im.w = kTFontW; im.h = kTFontH;
  im.px.assign((size_t)im.w * im.h * 4, 255);
  size_t o = 0;
  for (size_t i = 0; i + 1 < sizeof(kTFontRLE); i += 2)
    for (int k = 0; k < kTFontRLE[i] && o < (size_t)im.w * im.h; ++k, ++o) im.px[o * 4 + 3] = kTFontRLE[i + 1];
  texVcr_ = makeTexture(im, true, false);
}

float Game::vcrWidth(const std::string& s, float px) const {
  float sc = px / kTFontSize, w = 0, best = 0;
  for (char c : s) {
    if (c == '\n') { best = std::max(best, w); w = 0; continue; }
    w += glyphFor(c)->adv * sc;
  }
  return std::max(best, w);
}

// Drop-in for the old 8x8 pixel font calls: same "scale" (8 px per unit of scale, 12 per line).
void Game::vt(const std::string& s, float x, float y, float scale, float r, float g, float b, float a) {
  vcrText(s, x, y - scale * 1.2f, scale * 12.0f, r, g, b, a);
}
float Game::vw(const std::string& s, float scale) const { return vcrWidth(s, scale * 12.0f); }

// px is the font size (em) in pixels; (x, y) is the top-left of the line.
void Game::vcrText(const std::string& s, float x, float y, float px, float r, float g, float b, float a, float outline, float shadow) {
  if (s.empty() || a <= 0.0f) return;
  ensureVcrFont();
  float sc = px / kTFontSize;
  float base0 = y + px * 0.8f;
  std::vector<float> v;
  auto pass = [&](float ox, float oy, float cr, float cg, float cb, float ca) {
    float cx = x + ox, base = base0;
    for (char c : s) {
      if (c == '\n') { cx = x + ox; base += px; continue; }
      const TFontGlyph* gl = glyphFor(c);
      if (c != ' ') {
        float x0 = cx + gl->ox * sc, y0 = base + oy + gl->oy * sc;
        float x1 = x0 + gl->w * sc, y1 = y0 + gl->h * sc;
        float u0 = gl->x / (float)kTFontW, v0 = gl->y / (float)kTFontH;
        float u1 = (gl->x + gl->w) / (float)kTFontW, v1 = (gl->y + gl->h) / (float)kTFontH;
        float q[6][4] = {{x0, y0, u0, v0}, {x1, y0, u1, v0}, {x1, y1, u1, v1}, {x0, y0, u0, v0}, {x1, y1, u1, v1}, {x0, y1, u0, v1}};
        for (auto& p : q) v.insert(v.end(), {p[0], p[1], p[2], p[3], cr, cg, cb, ca});
      }
      cx += gl->adv * sc;
    }
  };
  if (shadow > 0.0f) pass(shadow * 0.6f, shadow, 0, 0, 0, a * 0.55f);
  if (outline > 0.0f)
    for (int k = 0; k < 12; ++k) {
      float an = k * (6.2831853f / 12.0f);
      pass(std::cos(an) * outline, std::sin(an) * outline, 0, 0, 0, a * 0.85f);
    }
  pass(0, 0, r, g, b, a);
  R_->sprites(texVcr_, v);
}
