#include "vam.h"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>

#include "texload.h"

bool VamModel::load(const std::string& path) {
  std::ifstream f(path, std::ios::binary);
  if (!f) return false;
  std::vector<char> b((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  if (b.size() < 32 || std::memcmp(b.data(), "VAM1", 4) != 0) return false;
  size_t o = 4;
  auto rd = [&](void* dst, size_t n) { if (o + n > b.size()) return false; std::memcpy(dst, b.data() + o, n); o += n; return true; };
  uint32_t nV, nI, nF, nM;
  float hdr[3];
  if (!rd(&nV, 4) || !rd(&nI, 4) || !rd(&nF, 4) || !rd(&nM, 4) || !rd(hdr, 12)) return false;
  loopSeconds = hdr[0]; stride = hdr[1]; height = hdr[2];
  std::string dir = path.substr(0, path.find_last_of("/\\") + 1);
  for (uint32_t m = 0; m < nM; ++m) {
    char name[33] = {0};
    uint32_t fc[2];
    if (!rd(name, 32) || !rd(fc, 8)) return false;
    Mat mt;
    mt.tex = name; mt.first = fc[0]; mt.count = fc[1];
    Image im;
    if (loadImageFile(dir + mt.tex + ".jpg", im) || loadImageFile(dir + mt.tex + ".png", im)) mt.gl = makeTexture(im, true, true);
    mats.push_back(mt);
  }
  uv.resize((size_t)nV * 2);
  idx.resize(nI);
  if (!rd(uv.data(), uv.size() * 4) || !rd(idx.data(), idx.size() * 4)) return false;
  for (size_t i = 1; i < uv.size(); i += 2) uv[i] = 1.0f - uv[i];
  float sc[6];
  if (!rd(sc, 24)) return false;
  pos.resize((size_t)nF * nV * 3);
  nrm.resize(pos.size());
  for (uint32_t fr = 0; fr < nF; ++fr)
    for (uint32_t v = 0; v < nV; ++v) {
      uint16_t q[3];
      int8_t n[4];
      if (!rd(q, 6) || !rd(n, 4)) return false;
      size_t k = ((size_t)fr * nV + v) * 3;
      for (int c = 0; c < 3; ++c) {
        pos[k + c] = q[c] * sc[c] + sc[3 + c];
        nrm[k + c] = n[c] / 127.0f;
      }
    }
  nVerts = (int)nV; nFrames = (int)nF;
  cpu.stride = 10;
  cpu.v.assign((size_t)nV * 10, 0.0f);
  cpu.idx = idx;
  for (int v = 0; v < nVerts; ++v) {
    float* d = &cpu.v[(size_t)v * 10];
    d[6] = uv[v * 2]; d[7] = uv[v * 2 + 1];
    d[8] = 1.0f; d[9] = -1.0f;  // ambient occlusion, no light id
  }
  std::fprintf(stderr, "[br9] model %s: %d verts, %zu tris, %d frames\n", path.c_str(), nVerts, idx.size() / 3, nFrames);
  return true;
}

void VamModel::pose(float phase) {
  if (!ok()) return;
  float t = (phase - std::floor(phase)) * nFrames;
  int a = (int)t % nFrames, c = (a + 1) % nFrames;
  float w = t - std::floor(t);
  const float* pa = &pos[(size_t)a * nVerts * 3];
  const float* pb = &pos[(size_t)c * nVerts * 3];
  const float* na = &nrm[(size_t)a * nVerts * 3];
  const float* nb = &nrm[(size_t)c * nVerts * 3];
  for (int v = 0; v < nVerts; ++v) {
    float* d = &cpu.v[(size_t)v * 10];
    for (int k = 0; k < 3; ++k) {
      d[k] = pa[v * 3 + k] + (pb[v * 3 + k] - pa[v * 3 + k]) * w;
      d[3 + k] = na[v * 3 + k] + (nb[v * 3 + k] - na[v * 3 + k]) * w;
    }
  }
  gpu.upload(cpu);
}
