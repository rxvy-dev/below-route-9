// Drawing for the special levels (see level_special.cpp):
//   Parking   - sprinkler pipes along the ceiling, cars
//   Playplace - a real sea of plastic balls near you (a textured floor beyond), hourglass colours
//   Suburbs   - a daytime sky dome with clouds
#include <algorithm>
#include <cmath>

#include "game.h"
#include "texgen.h"

namespace {
mat4 axes(vec3 r, vec3 u, vec3 n, vec3 p) {
  mat4 m = mat4::identity();
  m.m[0] = r.x; m.m[1] = r.y; m.m[2] = r.z;
  m.m[4] = u.x; m.m[5] = u.y; m.m[6] = u.z;
  m.m[8] = n.x; m.m[9] = n.y; m.m[10] = n.z;
  m.m[12] = p.x; m.m[13] = p.y; m.m[14] = p.z;
  return m;
}
}  // namespace

namespace {
// 12-vertex icosahedron: enough for a 9 cm ball at arm's length.
const float kIcoT = 1.618034f;
const vec3 kIco[12] = {{-1, kIcoT, 0}, {1, kIcoT, 0}, {-1, -kIcoT, 0}, {1, -kIcoT, 0}, {0, -1, kIcoT}, {0, 1, kIcoT},
                       {0, -1, -kIcoT}, {0, 1, -kIcoT}, {kIcoT, 0, -1}, {kIcoT, 0, 1}, {-kIcoT, 0, -1}, {-kIcoT, 0, 1}};
const int kIcoF[20][3] = {{0, 11, 5}, {0, 5, 1}, {0, 1, 7}, {0, 7, 10}, {0, 10, 11}, {1, 5, 9}, {5, 11, 4}, {11, 10, 2}, {10, 7, 6}, {7, 1, 8},
                          {3, 9, 4}, {3, 4, 2}, {3, 2, 6}, {3, 6, 8}, {3, 8, 9}, {4, 9, 5}, {2, 4, 11}, {6, 2, 10}, {8, 6, 7}, {9, 8, 1}};
}  // namespace

// A 2 x 2 m patch of the ball pit as one mesh, drawn on every tile near you.
void Game::buildBallPatch() {
  if (ballPatch_.triangles) return;
  Mesh m;
  m.stride = 14;
  Rng rng(9911);
  const float r = 0.045f;
  int balls = 0;
  for (int layer = 0; layer < 2; ++layer)
    for (float z = 0; z < 2.0f; z += 0.082f)
      for (float x = 0; x < 2.0f; x += 0.082f) {
        if (layer == 1 && rng.next() % 100 < 45) continue;
        vec3 c{x + rng.range(-0.02f, 0.02f) + (layer ? 0.041f : 0.0f), 0.035f + layer * 0.06f + rng.range(-0.02f, 0.03f),
               z + rng.range(-0.02f, 0.02f) + (layer ? 0.041f : 0.0f)};
        float pk = rng.range(0, 1);
        float region = pk < 0.27f ? 0 : pk < 0.52f ? 1 : pk < 0.75f ? 2 : pk < 0.96f ? 3 : 4;
        uint32_t base = (uint32_t)(m.v.size() / 14);
        for (const vec3& v : kIco) {
          vec3 n = normalize(v);
          vec3 p = c + n * r;
          m.v.insert(m.v.end(), {p.x, p.y, p.z, n.x, n.y, n.z, p.x, p.z, 0.75f + 0.25f * n.y, region, 0, 0, 1, 0});
        }
        for (const auto& f : kIcoF) m.idx.insert(m.idx.end(), {base + (uint32_t)f[0], base + (uint32_t)f[2], base + (uint32_t)f[1]});
        ++balls;
      }
  ballPatch_.mesh.upload(m);
  ballPatch_.triangles = (int)(m.idx.size() / 3);
  ballPatch_.region[0] = {0.62f, 0.035f, 0.04f, 0};   // red
  ballPatch_.region[1] = {0.9f, 0.62f, 0.04f, 0};     // yellow
  ballPatch_.region[2] = {0.035f, 0.09f, 0.62f, 0};   // blue
  ballPatch_.region[3] = {0.85f, 0.85f, 0.82f, 0};    // white
  ballPatch_.region[4] = {0.025f, 0.025f, 0.03f, 0};  // black
  for (int i = 0; i < 5; ++i) ballPatch_.spec[i] = 0.9f;  // shiny plastic
}

void Game::drawParkedCar(Shader& S, vec3 at, float yaw, int variant) {
  static const vec3 paints[6] = {{0.32f, 0.03f, 0.03f}, {0.05f, 0.08f, 0.18f}, {0.5f, 0.5f, 0.48f}, {0.06f, 0.06f, 0.06f}, {0.62f, 0.6f, 0.55f}, {0.08f, 0.16f, 0.1f}};
  vec3 paint = paints[variant % 6];
  mat4 base = translate(at) * rotY(yaw);
  S.set("uMat", MAT_PROP);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  auto part = [&](vec3 c, vec3 s, vec3 col, float em = 0) { drawPart(base * translate(c) * scale(s), col, em); };
  part({0, 0.62f, 0}, {1.78f, 0.62f, 4.4f}, paint);                     // body
  part({0, 1.12f, 0.25f}, {1.58f, 0.46f, 2.2f}, paint * 0.92f);          // cabin
  part({0, 1.12f, -0.87f}, {1.5f, 0.38f, 0.02f}, {0.02f, 0.025f, 0.03f});  // windscreen
  part({0, 1.12f, 1.37f}, {1.5f, 0.36f, 0.02f}, {0.02f, 0.025f, 0.03f});   // rear window
  for (int s = -1; s <= 1; s += 2) part({s * 0.8f, 1.12f, 0.25f}, {0.02f, 0.34f, 1.9f}, {0.02f, 0.025f, 0.03f});  // side windows
  for (int sx = -1; sx <= 1; sx += 2)
    for (int sz = -1; sz <= 1; sz += 2) part({sx * 0.82f, 0.34f, sz * 1.35f}, {0.24f, 0.66f, 0.66f}, {0.02f, 0.02f, 0.02f});  // tyres
  part({0, 0.5f, -2.21f}, {1.7f, 0.18f, 0.04f}, {0.25f, 0.25f, 0.25f});    // bumpers
  part({0, 0.5f, 2.21f}, {1.7f, 0.18f, 0.04f}, {0.25f, 0.25f, 0.25f});
  for (int s = -1; s <= 1; s += 2) {
    part({s * 0.62f, 0.72f, -2.21f}, {0.32f, 0.12f, 0.03f}, {0.8f, 0.8f, 0.75f});  // headlights (off)
    part({s * 0.62f, 0.75f, 2.21f}, {0.3f, 0.1f, 0.03f}, {0.4f, 0.03f, 0.03f});    // tail lights
  }
  // dust on the roof, a flat tyre now and then
  if (variant % 3 == 0) part({-0.82f, 0.18f, 1.35f}, {0.26f, 0.2f, 0.7f}, {0.02f, 0.02f, 0.02f});
}

void Game::specialDraw(Shader& S, vec3 cam) {
  const Theme& th = level_.theme;
  switch (th.special) {
    case Special::Parking: {
      // white sprinkler mains along the ceiling, red heads every three metres, drops to the tubes
      S.set("uMat", MAT_PROP);
      glBindTexture(GL_TEXTURE_2D, texWhite_);
      float y = level_.wallH - 0.14f;
      int cx = (int)std::floor(cam.x / Level::kTile), cz = (int)std::floor(cam.z / Level::kTile);
      for (int dz = -14; dz <= 14; ++dz)
        for (int dx = -14; dx <= 14; ++dx) {
          int tx = cx + dx, tz = cz + dz;
          vec3 c{(tx + 0.5f) * Level::kTile, 0, (tz + 0.5f) * Level::kTile};
          if (((tz % 3) + 3) % 3 == 1) {  // a main along x
            drawPart(translate({c.x, y, c.z + 0.3f}) * scale({Level::kTile + 0.01f, 0.08f, 0.08f}), {0.78f, 0.78f, 0.76f});
            if (((tx % 3) + 3) % 3 == 0) {
              drawPart(translate({c.x, y - 0.1f, c.z + 0.3f}) * scale({0.025f, 0.14f, 0.025f}), {0.6f, 0.6f, 0.6f});
              drawPart(translate({c.x, y - 0.18f, c.z + 0.3f}) * scale({0.06f, 0.04f, 0.06f}), {0.62f, 0.04f, 0.03f});
            }
          }
          if (((tx % 5) + 5) % 5 == 2)  // a thinner line along z
            drawPart(translate({c.x - 0.6f, y + 0.04f, c.z}) * scale({0.05f, 0.05f, Level::kTile + 0.01f}), {0.72f, 0.72f, 0.7f});
        }
      S.set("uMat", MAT_MODEL);
    } break;
    case Special::Playplace: {
      buildBallPatch();
      int cx = (int)std::floor(cam.x / Level::kTile), cz = (int)std::floor(cam.z / Level::kTile);
      const int R = 5;
      for (int dz = -R; dz <= R; ++dz)
        for (int dx = -R; dx <= R; ++dx) {
          if (dx * dx + dz * dz > R * R + 1) continue;
          int tx = cx + dx, tz = cz + dz;
          if (level_.solid[level_.idx(tx, tz)]) continue;
          drawModel(S, ballPatch_, translate({tx * Level::kTile, 0, tz * Level::kTile}));
        }
    } break;
    case Special::Suburbs: {
      // the sky: a big dome around you, self-lit, clouds and all
      if (!skyDome_.count) {
        Mesh m;
        const int seg = 48, rings = 12;
        const float Rr = 120.0f;
        for (int j = 0; j < rings; ++j)
          for (int i = 0; i < seg; ++i) {
            float a0 = i * 6.2832f / seg, a1 = (i + 1) * 6.2832f / seg;
            float e0 = -0.15f + j * (1.72f / rings), e1 = -0.15f + (j + 1) * (1.72f / rings);
            auto P = [&](float a, float e) { return vec3{std::cos(a) * std::cos(e) * Rr, std::sin(e) * Rr, std::sin(a) * std::cos(e) * Rr}; };
            float v0 = std::max(0.0f, e0 / 1.57f), v1 = std::max(0.0f, e1 / 1.57f);
            m.quad(P(a0, e0), P(a1, e0), P(a1, e1), P(a0, e1), {0, -1, 0}, {i / (float)seg, v0}, {(i + 1) / (float)seg, v0},
                   {(i + 1) / (float)seg, v1}, {i / (float)seg, v1}, 1, 1, 1, 1);
          }
        skyDome_.upload(m);
        texDaySky_ = makeTexture(texgen::daySky(1024, 256, 909), true, true);
      }
      glDisable(GL_CULL_FACE);
      glDepthMask(GL_FALSE);
      S.set("uMat", MAT_SCREEN);
      S.set("uUVScale", 1.0f);
      S.set("uEmissive", 1.45f);
      glBindTexture(GL_TEXTURE_2D, texDaySky_);
      S.set("uModel", translate({cam.x, cam.y - 20.0f, cam.z}));
      skyDome_.draw();
      S.set("uEmissive", 0.0f);
      S.set("uModel", mat4::identity());
      glDepthMask(GL_TRUE);
      glEnable(GL_CULL_FACE);
      S.set("uMat", MAT_MODEL);
    } break;
    default: break;
  }
}

// Someone ran power to the thin place: an orange cord along the floor, door to here.
void Game::drawCord(Shader& S, vec3 cam) {
  const std::vector<vec3>& c = level_.cord;
  if (c.size() < 2) return;
  S.set("uMat", MAT_PROP);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  const vec3 col{0.78f, 0.24f, 0.03f};
  for (size_t i = 0; i + 1 < c.size(); ++i) {
    vec3 a = near(c[i], cam), b = a + level_.delta(c[i], c[i + 1]);
    b.y = c[i + 1].y;
    vec3 m = (a + b) * 0.5f;
    vec3 dm = m - cam;
    if (dm.x * dm.x + dm.z * dm.z > 40.0f * 40.0f) continue;
    vec3 d = b - a;
    float len = length(d);
    if (len < 0.001f) continue;
    vec3 dn = d * (1.0f / len);
    vec3 side = cross(dn, vec3{0, 1, 0});
    if (length(side) < 0.1f) side = {1, 0, 0};
    side = normalize(side);
    vec3 up = cross(side, dn);
    const float th = 0.022f;
    drawPart(axes(dn * (len + th), up * th, side * th, m), col);
  }
  S.set("uMat", MAT_MODEL);
}

// Dust in the air: specks that drift through the light, the way they show up on camcorder footage
// when a fluorescent tube is overhead. Anchored in the world, so they slide past as you move.
void Game::drawDust(Shader& S, vec3 cam) {
  if (level_.theme.outdoor || inStore() || level_.lights.empty()) return;
  if (!texDust_) texDust_ = makeTexture(texgen::softDot(32), true, false);
  vec3 F = forward();
  vec3 R = normalize(cross(F, vec3{0, 1, 0}));
  vec3 U = cross(R, F);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE);  // they only add light
  glDepthMask(GL_FALSE);
  S.set("uMat", MAT_DECAL);
  S.set("uSkinned", 0);
  S.set("uFlipU", 0);
  glBindTexture(GL_TEXTURE_2D, texDust_);
  const vec3 lc = level_.theme.lightColor;
  const float box = 5.0f;
  const int N = 140;
  for (int i = 0; i < N; ++i) {
    vec3 b{hashf(i, 1) * box, hashf(i, 2) * box, hashf(i, 3) * box};
    vec3 drift{std::sin(time_ * 0.07f + i) * 0.25f + time_ * 0.012f, -time_ * 0.006f + std::sin(time_ * 0.11f + i * 1.7f) * 0.15f,
               std::cos(time_ * 0.05f + i * 0.3f) * 0.25f};
    vec3 o = cam - vec3{box * 0.5f, box * 0.5f, box * 0.5f};
    vec3 q = b + drift - o;
    vec3 p{o.x + q.x - std::floor(q.x / box) * box, o.y + q.y - std::floor(q.y / box) * box, o.z + q.z - std::floor(q.z / box) * box};
    if (p.y < 0.15f || p.y > level_.wallH - 0.1f) continue;
    vec3 d = p - cam;
    float dist = length(d);
    if (dist < 0.25f || dot(d, F) < 0.0f) continue;
    float lit = level_.lightAt(p.x, p.z, lightState_);
    if (lit < 0.15f) continue;
    float a = 0.6f * lit * (0.35f + 0.65f * hashf(i, 4)) * clampf(1.6f - dist * 0.4f, 0.0f, 1.0f);  // you only see the close ones
    float sz = 0.006f + 0.006f * hashf(i, 5);
    S.set("uTint", lc * a * 0.9f);
    S.set("uEmissive", 1.0f);
    mat4 m = mat4::identity();
    vec3 r = R * sz, u = U * sz, n = (cam - p) * (1.0f / dist);
    m.m[0] = r.x; m.m[1] = r.y; m.m[2] = r.z;
    m.m[4] = u.x; m.m[5] = u.y; m.m[6] = u.z;
    m.m[8] = n.x; m.m[9] = n.y; m.m[10] = n.z;
    m.m[12] = p.x; m.m[13] = p.y; m.m[14] = p.z;
    S.set("uModel", m);
    quad_.draw();
  }
  S.set("uEmissive", 0.0f);
  S.set("uTint", vec3{1, 1, 1});
  S.set("uModel", mat4::identity());
  glDepthMask(GL_TRUE);
  glDisable(GL_BLEND);
}

// Contact shadows: the ceiling lights are overhead, so whatever stands on the floor sits in its own
// soft dark patch. Without it furniture and things in the dark look pasted on.
void Game::drawContactShadows(Shader& S, vec3 cam) {
  if (!texBlob_) texBlob_ = makeTexture(texgen::softBlob(64), true, false);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDepthMask(GL_FALSE);
  glEnable(GL_POLYGON_OFFSET_FILL);
  glPolygonOffset(-1.0f, -2.0f);
  S.set("uMat", MAT_DECAL);
  S.set("uSkinned", 0);
  S.set("uFlipU", 0);
  S.set("uEmissive", 0.0f);
  S.set("uTint", vec3{0.0f, 0.0f, 0.0f});
  glBindTexture(GL_TEXTURE_2D, texBlob_);
  auto blob = [&](vec3 p, float hx, float hz) {
    vec3 at = near(p, cam);
    vec3 d = at - cam;
    if (d.x * d.x + d.z * d.z > 30.0f * 30.0f) return;
    at.y = level_.floorAt(at.x, at.z) + 0.004f;
    mat4 m = mat4::identity();
    m.m[0] = hx * 2.6f;                    // quad x along world x
    m.m[5] = 0.0f; m.m[6] = -hz * 2.6f;    // quad y along world -z
    m.m[9] = 1.0f; m.m[10] = 0.0f;         // quad normal straight up
    m.m[12] = at.x; m.m[13] = at.y; m.m[14] = at.z;
    S.set("uModel", m);
    quad_.draw();
  };
  for (const PropInstance& p : level_.props) {
    if (p.anomaly || p.pos.y > 0.05f) continue;
    switch (p.type) {
      case PR_WALLDOOR: case PR_TUBE: case PR_DOORSIDE: case PR_DOORLEAF: case PR_ARCH: case PR_HOUSE: case PR_SPIRAL: continue;
      default: break;
    }
    float hx = p.halfX > 0 ? p.halfX : 0.22f, hz = p.halfZ > 0 ? p.halfZ : 0.22f;
    blob(p.pos, hx, hz);
  }
  for (const Stalker& st : stalkers_)
    if (st.active()) blob(st.pos, 0.32f, 0.32f);
  S.set("uTint", vec3{1, 1, 1});
  S.set("uModel", mat4::identity());
  glDisable(GL_POLYGON_OFFSET_FILL);
  glDepthMask(GL_TRUE);
  glDisable(GL_BLEND);
}

// Loose things on the floor are real objects. Walk into a chair and it rolls away; run into a box and
// it skids, turns, and bangs off the wall (loud enough for things to hear). Light things go further.
void Game::updateKickables(float dt) {
  const float kPlayerRadius = 0.3f;
  if (screen_ != Screen::Playing || level_.props.empty()) return;
  auto kind = [](int t) {  // mass-ish: how hard it is to shove, and how far it slides
    switch (t) {
      case PR_CHAIR: return 1;   // on castors
      case PR_BOX: return 2;
      case PR_CAN: case PR_BAG: return 3;
      case PR_COOLER: return 4;
      default: return 0;
    }
  };
  float spd = std::sqrt(vel_.x * vel_.x + vel_.z * vel_.z);
  for (size_t i = 0; i < level_.props.size(); ++i) {
    PropInstance& p = level_.props[i];
    int k = kind(p.type);
    if (!k || p.anomaly || p.pos.y > 0.05f || std::fabs(p.roll) > 0.1f) continue;
    vec3 d = level_.delta(pos_, p.pos);
    float dist2 = d.x * d.x + d.z * d.z;
    bool moving = p.vel.x * p.vel.x + p.vel.z * p.vel.z > 1e-4f || std::fabs(p.spin) > 0.01f;
    if (dist2 > 9.0f && !moving) continue;
    float pr = k == 3 ? 0.12f : (p.halfX > 0 ? std::max(p.halfX, p.halfZ) : 0.24f);
    // the player shoving it
    float reach = kPlayerRadius + pr + 0.04f;
    if (dist2 < reach * reach && spd > 0.3f && jumpY_ < 0.3f) {
      float dl = std::sqrt(std::max(dist2, 1e-6f));
      vec3 n{d.x / dl, 0, d.z / dl};
      float push = vel_.x * n.x + vel_.z * n.z;
      if (push > 0.1f) {
        const float give[5] = {0, 1.25f, 0.9f, 1.6f, 0.55f};
        vec3 add = n * (push * give[k]) + vec3{vel_.x, 0, vel_.z} * 0.25f;
        p.vel = p.vel + add * std::min(1.0f, dt * 12.0f);
        p.spin += (n.x * vel_.z - n.z * vel_.x) * (k == 1 ? 1.8f : 1.2f) * std::min(1.0f, dt * 10.0f);
        if (k == 1 && A_ && rng_.f01() < dt * 6.0f) A_->play(Sfx::Footstep, 0.12f, 0, 0.45f);  // castors on carpet
      }
    }
    if (!moving && p.vel.x == 0.0f) continue;
    // slide, turn, slow down (castors roll on, cardboard drags, a can skitters)
    const float drag[5] = {0, 1.6f, 4.5f, 2.2f, 5.5f};
    vec3 before = p.pos;
    p.pos = p.pos + p.vel * dt;
    p.yaw += p.spin * dt;
    p.vel = p.vel * std::exp(-dt * drag[k]);
    p.spin *= std::exp(-dt * 3.0f);
    // walls, pillars and other furniture: bounce off them
    float hx = p.halfX, hz = p.halfZ;
    p.halfX = p.halfZ = 0;  // don't collide with itself
    vec3 q = p.pos;
    level_.collide(q, pr);
    p.halfX = hx; p.halfZ = hz;
    vec3 corr = q - p.pos;
    float cl = std::sqrt(corr.x * corr.x + corr.z * corr.z);
    if (cl > 1e-5f) {
      vec3 n{corr.x / cl, 0, corr.z / cl};
      float vn = p.vel.x * n.x + p.vel.z * n.z;
      if (vn < 0) {
        float hit = -vn;
        p.vel = p.vel - n * (vn * 1.45f);  // bounces back a bit, loses the rest
        p.spin += (rng_.f01() - 0.5f) * hit * 2.0f;
        if (hit > 0.4f && A_) {
          vec3 rel = level_.delta(pos_, p.pos);
          float pan = clampf(dot(normalize(vec3{rel.x, 0, rel.z} + vec3{1e-4f, 0, 0}), normalize(cross(forward(), vec3{0, 1, 0}))), -1.0f, 1.0f);
          A_->play(k == 3 ? Sfx::Clatter : Sfx::Knock, std::min(0.9f, hit * 0.35f), pan, k == 1 ? 1.3f : 0.9f + rng_.f01() * 0.3f);
          noiseRadius_ = std::max(noiseRadius_, 6.0f + hit * 4.0f);  // they heard that
          noiseHold_ = std::max(noiseHold_, 0.6f);
        }
      }
      p.pos = q;
    }
    if (p.vel.x * p.vel.x + p.vel.z * p.vel.z < 1e-4f) p.vel = {0, 0, 0};
    // keep the tile index right as it crosses tiles
    int ax, az, bx, bz;
    level_.tileOf(before.x, before.z, ax, az);
    p.pos = level_.wrap(p.pos);
    level_.tileOf(p.pos.x, p.pos.z, bx, bz);
    if (ax != bx || az != bz) {
      auto& from = level_.propsAtTile[level_.idx(ax, az)];
      from.erase(std::remove(from.begin(), from.end(), (int)i), from.end());
      level_.propsAtTile[level_.idx(bx, bz)].push_back((int)i);
    }
  }
}
