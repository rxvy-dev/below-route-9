// Drawing for the special levels (see level_special.cpp):
//   Parking   - sprinkler pipes along the ceiling, cars
//   Playplace - a real sea of plastic balls near you (a textured floor beyond), hourglass colours
//   Suburbs   - a daytime sky dome with clouds
#include <algorithm>
#include <cmath>

#include "game.h"
#include "texgen.h"

namespace {
// 12-vertex icosahedron: enough for a 9 cm ball at arm's length.
const float kIcoT = 1.618034f;
const vec3 kIco[12] = {{-1, kIcoT, 0}, {1, kIcoT, 0}, {-1, -kIcoT, 0}, {1, -kIcoT, 0}, {0, -1, kIcoT}, {0, 1, kIcoT},
                       {0, -1, -kIcoT}, {0, 1, -kIcoT}, {kIcoT, 0, -1}, {kIcoT, 0, 1}, {-kIcoT, 0, -1}, {-kIcoT, 0, 1}};
const int kIcoF[20][3] = {{0, 11, 5}, {0, 5, 1}, {0, 1, 7}, {0, 7, 10}, {0, 10, 11}, {1, 5, 9}, {5, 11, 4}, {11, 10, 2}, {10, 7, 6}, {7, 1, 8},
                          {3, 9, 4}, {3, 4, 2}, {3, 2, 6}, {3, 6, 8}, {3, 8, 9}, {4, 9, 5}, {2, 4, 11}, {6, 2, 10}, {8, 6, 7}, {9, 8, 1}};
}  // namespace

// A 2 x 2 m patch of the ball pit as one mesh, drawn on every tile near you.
void Game::buildBallPatch() {
  if (ballPatch_.triangles) return;
  Mesh m;
  m.stride = 14;
  Rng rng(9911);
  const float r = 0.045f;
  int balls = 0;
  for (int layer = 0; layer < 2; ++layer)
    for (float z = 0; z < 2.0f; z += 0.082f)
      for (float x = 0; x < 2.0f; x += 0.082f) {
        if (layer == 1 && rng.next() % 100 < 45) continue;
        vec3 c{x + rng.range(-0.02f, 0.02f) + (layer ? 0.041f : 0.0f), 0.035f + layer * 0.06f + rng.range(-0.02f, 0.03f),
               z + rng.range(-0.02f, 0.02f) + (layer ? 0.041f : 0.0f)};
        float pk = rng.range(0, 1);
        float region = pk < 0.27f ? 0 : pk < 0.52f ? 1 : pk < 0.75f ? 2 : pk < 0.96f ? 3 : 4;
        uint32_t base = (uint32_t)(m.v.size() / 14);
        for (const vec3& v : kIco) {
          vec3 n = normalize(v);
          vec3 p = c + n * r;
          m.v.insert(m.v.end(), {p.x, p.y, p.z, n.x, n.y, n.z, p.x, p.z, 0.75f + 0.25f * n.y, region, 0, 0, 1, 0});
        }
        for (const auto& f : kIcoF) m.idx.insert(m.idx.end(), {base + (uint32_t)f[0], base + (uint32_t)f[2], base + (uint32_t)f[1]});
        ++balls;
      }
  ballPatch_.mesh.upload(m);
  ballPatch_.triangles = (int)(m.idx.size() / 3);
  ballPatch_.region[0] = {0.62f, 0.035f, 0.04f, 0};   // red
  ballPatch_.region[1] = {0.9f, 0.62f, 0.04f, 0};     // yellow
  ballPatch_.region[2] = {0.035f, 0.09f, 0.62f, 0};   // blue
  ballPatch_.region[3] = {0.85f, 0.85f, 0.82f, 0};    // white
  ballPatch_.region[4] = {0.025f, 0.025f, 0.03f, 0};  // black
  for (int i = 0; i < 5; ++i) ballPatch_.spec[i] = 0.9f;  // shiny plastic
}

void Game::drawParkedCar(Shader& S, vec3 at, float yaw, int variant) {
  static const vec3 paints[6] = {{0.32f, 0.03f, 0.03f}, {0.05f, 0.08f, 0.18f}, {0.5f, 0.5f, 0.48f}, {0.06f, 0.06f, 0.06f}, {0.62f, 0.6f, 0.55f}, {0.08f, 0.16f, 0.1f}};
  vec3 paint = paints[variant % 6];
  mat4 base = translate(at) * rotY(yaw);
  S.set("uMat", MAT_PROP);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  auto part = [&](vec3 c, vec3 s, vec3 col, float em = 0) { drawPart(base * translate(c) * scale(s), col, em); };
  part({0, 0.62f, 0}, {1.78f, 0.62f, 4.4f}, paint);                     // body
  part({0, 1.12f, 0.25f}, {1.58f, 0.46f, 2.2f}, paint * 0.92f);          // cabin
  part({0, 1.12f, -0.87f}, {1.5f, 0.38f, 0.02f}, {0.02f, 0.025f, 0.03f});  // windscreen
  part({0, 1.12f, 1.37f}, {1.5f, 0.36f, 0.02f}, {0.02f, 0.025f, 0.03f});   // rear window
  for (int s = -1; s <= 1; s += 2) part({s * 0.8f, 1.12f, 0.25f}, {0.02f, 0.34f, 1.9f}, {0.02f, 0.025f, 0.03f});  // side windows
  for (int sx = -1; sx <= 1; sx += 2)
    for (int sz = -1; sz <= 1; sz += 2) part({sx * 0.82f, 0.34f, sz * 1.35f}, {0.24f, 0.66f, 0.66f}, {0.02f, 0.02f, 0.02f});  // tyres
  part({0, 0.5f, -2.21f}, {1.7f, 0.18f, 0.04f}, {0.25f, 0.25f, 0.25f});    // bumpers
  part({0, 0.5f, 2.21f}, {1.7f, 0.18f, 0.04f}, {0.25f, 0.25f, 0.25f});
  for (int s = -1; s <= 1; s += 2) {
    part({s * 0.62f, 0.72f, -2.21f}, {0.32f, 0.12f, 0.03f}, {0.8f, 0.8f, 0.75f});  // headlights (off)
    part({s * 0.62f, 0.75f, 2.21f}, {0.3f, 0.1f, 0.03f}, {0.4f, 0.03f, 0.03f});    // tail lights
  }
  // dust on the roof, a flat tyre now and then
  if (variant % 3 == 0) part({-0.82f, 0.18f, 1.35f}, {0.26f, 0.2f, 0.7f}, {0.02f, 0.02f, 0.02f});
}

void Game::specialDraw(Shader& S, vec3 cam) {
  const Theme& th = level_.theme;
  switch (th.special) {
    case Special::Parking: {
      // white sprinkler mains along the ceiling, red heads every three metres, drops to the tubes
      S.set("uMat", MAT_PROP);
      glBindTexture(GL_TEXTURE_2D, texWhite_);
      float y = level_.wallH - 0.14f;
      int cx = (int)std::floor(cam.x / Level::kTile), cz = (int)std::floor(cam.z / Level::kTile);
      for (int dz = -14; dz <= 14; ++dz)
        for (int dx = -14; dx <= 14; ++dx) {
          int tx = cx + dx, tz = cz + dz;
          vec3 c{(tx + 0.5f) * Level::kTile, 0, (tz + 0.5f) * Level::kTile};
          if (((tz % 3) + 3) % 3 == 1) {  // a main along x
            drawPart(translate({c.x, y, c.z + 0.3f}) * scale({Level::kTile + 0.01f, 0.08f, 0.08f}), {0.78f, 0.78f, 0.76f});
            if (((tx % 3) + 3) % 3 == 0) {
              drawPart(translate({c.x, y - 0.1f, c.z + 0.3f}) * scale({0.025f, 0.14f, 0.025f}), {0.6f, 0.6f, 0.6f});
              drawPart(translate({c.x, y - 0.18f, c.z + 0.3f}) * scale({0.06f, 0.04f, 0.06f}), {0.62f, 0.04f, 0.03f});
            }
          }
          if (((tx % 5) + 5) % 5 == 2)  // a thinner line along z
            drawPart(translate({c.x - 0.6f, y + 0.04f, c.z}) * scale({0.05f, 0.05f, Level::kTile + 0.01f}), {0.72f, 0.72f, 0.7f});
        }
      S.set("uMat", MAT_MODEL);
    } break;
    case Special::Playplace: {
      buildBallPatch();
      int cx = (int)std::floor(cam.x / Level::kTile), cz = (int)std::floor(cam.z / Level::kTile);
      const int R = 5;
      for (int dz = -R; dz <= R; ++dz)
        for (int dx = -R; dx <= R; ++dx) {
          if (dx * dx + dz * dz > R * R + 1) continue;
          int tx = cx + dx, tz = cz + dz;
          if (level_.solid[level_.idx(tx, tz)]) continue;
          drawModel(S, ballPatch_, translate({tx * Level::kTile, 0, tz * Level::kTile}));
        }
    } break;
    case Special::Suburbs: {
      // the sky: a big dome around you, self-lit, clouds and all
      if (!skyDome_.count) {
        Mesh m;
        const int seg = 48, rings = 12;
        const float Rr = 120.0f;
        for (int j = 0; j < rings; ++j)
          for (int i = 0; i < seg; ++i) {
            float a0 = i * 6.2832f / seg, a1 = (i + 1) * 6.2832f / seg;
            float e0 = -0.15f + j * (1.72f / rings), e1 = -0.15f + (j + 1) * (1.72f / rings);
            auto P = [&](float a, float e) { return vec3{std::cos(a) * std::cos(e) * Rr, std::sin(e) * Rr, std::sin(a) * std::cos(e) * Rr}; };
            float v0 = std::max(0.0f, e0 / 1.57f), v1 = std::max(0.0f, e1 / 1.57f);
            m.quad(P(a0, e0), P(a1, e0), P(a1, e1), P(a0, e1), {0, -1, 0}, {i / (float)seg, v0}, {(i + 1) / (float)seg, v0},
                   {(i + 1) / (float)seg, v1}, {i / (float)seg, v1}, 1, 1, 1, 1);
          }
        skyDome_.upload(m);
        texDaySky_ = makeTexture(texgen::daySky(1024, 256, 909), true, true);
      }
      glDisable(GL_CULL_FACE);
      glDepthMask(GL_FALSE);
      S.set("uMat", MAT_SCREEN);
      S.set("uUVScale", 1.0f);
      S.set("uEmissive", 1.45f);
      glBindTexture(GL_TEXTURE_2D, texDaySky_);
      S.set("uModel", translate({cam.x, cam.y - 20.0f, cam.z}));
      skyDome_.draw();
      S.set("uEmissive", 0.0f);
      S.set("uModel", mat4::identity());
      glDepthMask(GL_TRUE);
      glEnable(GL_CULL_FACE);
      S.set("uMat", MAT_MODEL);
    } break;
    default: break;
  }
}
