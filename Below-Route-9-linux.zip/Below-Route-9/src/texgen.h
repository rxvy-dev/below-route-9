// Procedural texture generation. Every texture is RGBA8; alpha holds a height
// value used for bump mapping in the world shader.
#pragma once
#include <cstdint>
#include <vector>

struct Image {
  int w = 0, h = 0;
  std::vector<uint8_t> px;  // RGBA8
};

namespace texgen {
Image wallpaper(int size, uint32_t seed);
Image carpet(int size, uint32_t seed);
Image ceilingTiles(int size, uint32_t seed);
Image lightPanel(int size);
Image paper(int size, uint32_t seed);
Image grime(int size, uint32_t seed);  // large-scale stains, greyscale
Image solid(uint8_t r, uint8_t g, uint8_t b);
// Level surfaces
Image concreteWall(int size, uint32_t seed);
Image brick(int size, uint32_t seed);
Image tiles(int size, uint32_t seed, int perMeter);
Image poolTile(int size, uint32_t seed, int perMeter);
Image poolMosaic(int size, uint32_t seed);
Image tunnelMouth(int size);
Image concreteFloor(int size, uint32_t seed);
Image concreteCeiling(int size, uint32_t seed);
void tint(Image& im, float r, float g, float b);
Image paintedBlock(int size, uint32_t seed);   // cream-painted cinder block (1m)
Image vinyl(int size, uint32_t seed);          // store floor tiles, 2x2 per metre
Image nightWindow(int w, int h, uint32_t seed, bool door);  // parking lot at night, RGB + alpha 255
Image woodDoor(int w, int h, uint32_t seed);
Image woodFloor(int size, uint32_t seed);     // apartment floorboards
Image plaster(int size, uint32_t seed);       // apartment walls and ceiling
// Views for windows and screens (RGB, alpha 255). mode: 0 store lot at dawn with Ray's van,
// 1 store lot at dawn, 2 city at night, 3 city at sunrise.
Image viewWindow(int w, int h, uint32_t seed, int mode);
Image tvNews(int w, int h);                   // the missing-person report
Image tvHall(int w, int h);                   // a yellow hallway
// Level 188: the atrium facade (wall of square windows) and the courtyard far below.
Image facade(int w, int h, uint32_t seed, float wallMeters, float heightMeters);
Image courtyardFloor(int s, uint32_t seed);
// Outside the Quik-Stop at night.
Image bill(int w, int h, int denom);
Image blueTape(int w, int h, uint32_t seed);
Image partyCarpet(int s, uint32_t seed);
Image partyWall(int s, uint32_t seed, float r, float g, float b);
Image bunting(int w, int h, uint32_t seed);
Image parkingLot(int w, int h, uint32_t seed, bool storeLights);   // 60 x 40 m, light pools baked in
Image nightSky(int w, int h, uint32_t seed);
Image signText(const char* text, int w, int h, float r, float g, float b, float br, float bg, float bb);  // block letters on a lit panel
Image slideHole(int s, float r, float g, float b);    // looking into a plastic tube
Image slideTube(int w, int h, float r, float g, float b);  // inside the tube: plastic seams
// Spray-paint decals: white RGB, coverage in alpha.
Image paintArrow(int w, int h, uint32_t seed);
Image bloodDrag(int w, int h, uint32_t seed);   // decal masks, tinted in the shader
Image bloodSplat(int s, uint32_t seed);
Image bloodPool(int s, uint32_t seed);
Image handprint(int s, uint32_t seed);
Image footprints(int w, int h, uint32_t seed);
Image tapeFlag(int s, uint32_t seed);
Image stain(int s, uint32_t seed);
Image softDot(int s);
Image softBlob(int s);
Image faceFlash(int s, uint32_t seed);
Image exitSign(int w, int h, int arrow);
Image corrugated(int s, uint32_t seed);
Image parkingFloor(int s, uint32_t seed);
Image officeWall(int s, uint32_t seed);
Image officeCarpet(int s, uint32_t seed);
Image ballPit(int s, uint32_t seed);
Image playWall(int s, uint32_t seed);
Image grass(int s, uint32_t seed);
Image daySky(int w, int h, uint32_t seed);  // 0 straight on, 1 right, 2 left          // RGBA
Image paintText(const char* text, int w, int h, uint32_t seed);
}
