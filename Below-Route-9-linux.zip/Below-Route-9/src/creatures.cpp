#include "creatures.h"
#include "sdfmesh.h"
#include <SDL.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>

using namespace sdf;

namespace {

Model gCreatures[CR_COUNT];
Model gProps[PR_COUNT];

enum Region { SKIN = 0, EYE = 1, BONE = 2, GLOW = 3 };

inline vec3 mirror(vec3 p) { return {std::fabs(p.x), p.y, p.z}; }

// ------------------------------------------------------------------ the Tenant
// 2.65 m, emaciated, arms past the knees, skull too long for its face.

std::vector<Bone> tenantBones() {
  std::vector<Bone> b = {
      {-1, {0, 1.28f, 0}, {0, 1.42f, 0.01f}},          // 0 pelvis
      {0, {0, 1.42f, 0.01f}, {0, 1.78f, 0.03f}},       // 1 spine
      {1, {0, 1.78f, 0.03f}, {0, 2.10f, 0.01f}},       // 2 chest
      {2, {0, 2.10f, 0.01f}, {0, 2.36f, -0.04f}},      // 3 neck
      {3, {0, 2.36f, -0.04f}, {0, 2.64f, -0.06f}},     // 4 head
      {4, {0, 2.445f, -0.05f}, {0, 2.41f, -0.155f}},   // 5 jaw
  };
  for (int s = 1; s >= -1; s -= 2) {  // arms: L then R
    int base = (int)b.size();
    b.push_back({2, {0.19f * s, 2.08f, 0.01f}, {0.23f * s, 1.56f, 0.02f}});
    b.push_back({base, {0.23f * s, 1.56f, 0.02f}, {0.25f * s, 1.03f, -0.01f}});
    b.push_back({base + 1, {0.25f * s, 1.03f, -0.01f}, {0.26f * s, 0.70f, -0.03f}});
  }
  for (int s = 1; s >= -1; s -= 2) {  // legs
    int base = (int)b.size();
    b.push_back({0, {0.10f * s, 1.30f, 0}, {0.11f * s, 0.70f, 0}});
    b.push_back({base, {0.11f * s, 0.70f, 0}, {0.11f * s, 0.09f, 0.03f}});
    b.push_back({base + 1, {0.11f * s, 0.09f, 0.03f}, {0.11f * s, 0.025f, -0.20f}});
  }
  return b;
}

SdfSample tenantSdf(vec3 p) {
  SdfBuilder b;
  vec3 q = mirror(p);
  // pelvis, sunken abdomen, ribcage
  b.add(ellipsoid(p, {0, 1.33f, 0}, {0.14f, 0.10f, 0.09f}), SKIN, 0);
  b.add(cone(p, {0, 1.36f, 0.02f}, {0, 1.74f, 0.035f}, 0.072f, 0.09f), SKIN, 0.06f);
  b.add(ellipsoid(p, {0, 1.93f, 0.015f}, {0.15f, 0.2f, 0.10f}), SKIN, 0.07f);
  // hip bones jutting through skin
  b.add(ellipsoid(q, {0.12f, 1.38f, -0.02f}, {0.035f, 0.03f, 0.05f}), SKIN, 0.03f);
  // shoulder girdle and blades
  b.add(cone(q, {0.0f, 2.085f, 0.02f}, {0.2f, 2.075f, 0.02f}, 0.038f, 0.03f), SKIN, 0.05f);
  b.add(ellipsoid(q, {0.085f, 1.98f, 0.075f}, {0.065f, 0.09f, 0.03f}), SKIN, 0.035f);
  // vertebrae down the back
  for (int i = 0; i < 16; ++i) {
    float y = 1.40f + i * 0.045f;
    float z = 0.09f + 0.025f * std::sin((y - 1.4f) * 4.0f);
    b.add(sphere(p, {0, y, z}, 0.016f), SKIN, 0.02f);
  }
  // neck with tendons
  b.add(cone(p, {0, 2.08f, 0.01f}, {0, 2.38f, -0.05f}, 0.040f, 0.033f), SKIN, 0.04f);
  b.add(cone(q, {0.03f, 2.12f, -0.02f}, {0.012f, 2.36f, -0.07f}, 0.011f, 0.008f), SKIN, 0.015f);
  // skull, cheekbones, jaw, chin, nose
  b.add(ellipsoid(p, {0, 2.54f, -0.06f}, {0.088f, 0.13f, 0.108f}), SKIN, 0.04f);
  b.add(ellipsoid(q, {0.05f, 2.47f, -0.13f}, {0.03f, 0.02f, 0.034f}), SKIN, 0.02f);
  b.add(cone(p, {0, 2.445f, -0.05f}, {0, 2.41f, -0.155f}, 0.048f, 0.027f), SKIN, 0.03f);
  b.add(cone(p, {0, 2.535f, -0.162f}, {0, 2.478f, -0.178f}, 0.009f, 0.014f), SKIN, 0.012f);
  // brow ridge
  b.add(cone(q, {0.0f, 2.545f, -0.158f}, {0.06f, 2.54f, -0.14f}, 0.016f, 0.012f), SKIN, 0.015f);
  // sunken sockets and a lipless slit mouth
  b.cut(sphere(q, {0.036f, 2.508f, -0.168f}, 0.029f), 0.014f);
  b.cut(ellipsoid(p, {0, 2.432f, -0.165f}, {0.034f, 0.0065f, 0.045f}), 0.006f);
  b.add(sphere(q, {0.036f, 2.507f, -0.150f}, 0.0135f), EYE, 0);
  // arms
  b.add(cone(q, {0.19f, 2.08f, 0.01f}, {0.23f, 1.56f, 0.02f}, 0.042f, 0.030f), SKIN, 0.03f);
  b.add(sphere(q, {0.23f, 1.56f, 0.025f}, 0.033f), SKIN, 0.02f);
  b.add(cone(q, {0.23f, 1.56f, 0.02f}, {0.25f, 1.03f, -0.01f}, 0.032f, 0.023f), SKIN, 0.02f);
  b.add(ellipsoid(q, {0.255f, 0.965f, -0.015f}, {0.019f, 0.058f, 0.037f}), SKIN, 0.02f);
  const float fl[4] = {0.22f, 0.26f, 0.25f, 0.20f};
  for (int k = 0; k < 4; ++k) {
    float z = -0.041f + 0.026f * k;
    vec3 a{0.258f, 0.915f, z}, mid{0.262f, 0.915f - fl[k] * 0.5f, z - 0.004f}, tip{0.268f, 0.915f - fl[k], z - 0.014f};
    b.add(cone(q, a, mid, 0.0095f, 0.0075f), SKIN, 0.008f);
    b.add(cone(q, mid, tip, 0.0078f, 0.0048f), SKIN, 0.004f);
    b.add(sphere(q, mid, 0.0098f), SKIN, 0.004f);
    b.add(sphere(q, tip + vec3{0.002f, 0.002f, -0.004f}, 0.0055f), BONE, 0.002f);
  }
  b.add(cone(q, {0.25f, 0.975f, -0.05f}, {0.243f, 0.875f, -0.078f}, 0.011f, 0.007f), SKIN, 0.008f);
  // legs
  b.add(cone(q, {0.10f, 1.30f, 0}, {0.11f, 0.70f, 0}, 0.064f, 0.040f), SKIN, 0.05f);
  b.add(sphere(q, {0.11f, 0.70f, -0.012f}, 0.044f), SKIN, 0.03f);
  b.add(cone(q, {0.11f, 0.70f, 0}, {0.11f, 0.10f, 0.03f}, 0.042f, 0.025f), SKIN, 0.02f);
  b.add(ellipsoid(q, {0.11f, 0.52f, 0.03f}, {0.038f, 0.11f, 0.04f}), SKIN, 0.03f);
  b.add(sphere(q, {0.11f, 0.09f, 0.03f}, 0.029f), SKIN, 0.02f);
  b.add(cone(q, {0.11f, 0.06f, 0.04f}, {0.11f, 0.026f, -0.15f}, 0.034f, 0.022f), SKIN, 0.02f);
  for (int k = -1; k <= 1; ++k) {
    vec3 a{0.11f + k * 0.017f, 0.026f, -0.15f}, tip{0.11f + k * 0.024f, 0.014f, -0.245f};
    b.add(cone(q, a, tip, 0.0105f, 0.0065f), SKIN, 0.006f);
    b.add(sphere(q, tip, 0.0065f), BONE, 0.002f);
  }
  // what's left of a red work polo, stretched over the ribs and torn to strips, with a name tag
  {
    float shell = std::fabs(ellipsoid(p, {0, 1.9f, 0.015f}, {0.163f, 0.235f, 0.113f})) - 0.0045f;
    float hem = (1.66f + 0.07f * fbm(p * 9.0f, 2) + 0.04f * std::sin(p.x * 40.0f)) - p.y;
    float holes = (fbm(p * 13.0f + vec3{3, 1, 7}, 3) - 0.56f) * 0.08f;
    float rag = std::max(std::max(shell, hem), std::max(-holes, p.y - 2.1f));
    b.add(rag, GLOW, 0.004f);
    b.add(box(p, {-0.075f, 1.98f, -0.104f}, {0.026f, 0.009f, 0.003f}, 0.002f), BONE, 0.002f);
  }
  // skin: fine wrinkles everywhere, ribs pressing through the chest
  float d = b.d + 0.0018f * fbm(p * 42.0f, 3);
  if (p.y > 1.74f && p.y < 2.06f && std::fabs(p.x) > 0.025f) {
    float rib = std::pow(std::max(0.0f, std::sin(p.y * 78.0f - std::fabs(p.x) * 9.0f)), 6.0f);
    d -= 0.0045f * rib * smoothstepf(0.16f, 0.06f, std::fabs(p.x));
  }
  return {d, b.region};
}

// ------------------------------------------------------------------ the Hound
// Something that used to be a person, now on all fours. Eyeless; hunts by ear.

std::vector<Bone> houndBones() {
  std::vector<Bone> b = {
      {-1, {0, 0.82f, 0.42f}, {0, 0.84f, 0.28f}},      // 0 pelvis
      {0, {0, 0.84f, 0.28f}, {0, 0.90f, -0.12f}},      // 1 spine
      {1, {0, 0.90f, -0.12f}, {0, 0.86f, -0.42f}},     // 2 chest
      {2, {0, 0.86f, -0.42f}, {0, 0.80f, -0.60f}},     // 3 neck
      {3, {0, 0.80f, -0.60f}, {0, 0.74f, -0.82f}},     // 4 head
      {4, {0, 0.745f, -0.64f}, {0, 0.66f, -0.83f}},    // 5 jaw
  };
  for (int s = 1; s >= -1; s -= 2) {
    int base = (int)b.size();
    b.push_back({2, {0.16f * s, 0.86f, -0.36f}, {0.25f * s, 0.48f, -0.44f}});
    b.push_back({base, {0.25f * s, 0.48f, -0.44f}, {0.22f * s, 0.07f, -0.50f}});
    b.push_back({base + 1, {0.22f * s, 0.07f, -0.50f}, {0.22f * s, 0.02f, -0.70f}});
  }
  for (int s = 1; s >= -1; s -= 2) {
    int base = (int)b.size();
    b.push_back({0, {0.12f * s, 0.80f, 0.40f}, {0.22f * s, 0.42f, 0.18f}});
    b.push_back({base, {0.22f * s, 0.42f, 0.18f}, {0.19f * s, 0.06f, 0.46f}});
    b.push_back({base + 1, {0.19f * s, 0.06f, 0.46f}, {0.19f * s, 0.02f, 0.28f}});
  }
  return b;
}

SdfSample houndSdf(vec3 p) {
  SdfBuilder b;
  vec3 q = mirror(p);
  b.add(ellipsoid(p, {0, 0.82f, 0.40f}, {0.14f, 0.11f, 0.12f}), SKIN, 0);
  b.add(cone(p, {0, 0.84f, 0.30f}, {0, 0.89f, 0.0f}, 0.085f, 0.10f), SKIN, 0.06f);
  b.add(ellipsoid(p, {0, 0.88f, -0.25f}, {0.16f, 0.14f, 0.24f}), SKIN, 0.07f);
  // spine ridge
  for (int i = 0; i < 20; ++i) {
    float z = 0.42f - i * 0.046f;
    float y = 0.94f + 0.06f * std::sin((0.42f - z) * 3.3f) + (z < -0.1f ? 0.02f : 0.0f);
    b.add(sphere(p, {0, y, z}, 0.022f - i * 0.0003f), SKIN, 0.02f);
  }
  // shoulder blades sticking up
  b.add(ellipsoid(q, {0.10f, 0.98f, -0.34f}, {0.05f, 0.025f, 0.08f}), SKIN, 0.04f);
  // neck, eyeless head, hanging jaw
  b.add(cone(p, {0, 0.86f, -0.42f}, {0, 0.80f, -0.62f}, 0.055f, 0.045f), SKIN, 0.04f);
  b.add(ellipsoid(p, {0, 0.795f, -0.715f}, {0.08f, 0.075f, 0.125f}), SKIN, 0.04f);
  b.add(cone(p, {0, 0.73f, -0.64f}, {0, 0.665f, -0.83f}, 0.042f, 0.03f), SKIN, 0.025f);
  b.cut(ellipsoid(p, {0, 0.725f, -0.80f}, {0.05f, 0.022f, 0.09f}), 0.01f);       // mouth cavity
  b.cut(ellipsoid(q, {0.018f, 0.79f, -0.84f}, {0.006f, 0.012f, 0.02f}), 0.004f); // nostril slits
  b.cut(ellipsoid(q, {0.045f, 0.82f, -0.78f}, {0.025f, 0.012f, 0.03f}), 0.012f); // where eyes were
  // teeth: upper row pointing down, lower row up
  for (int i = -5; i <= 5; ++i) {
    float t = i / 5.0f;
    float x = t * 0.045f, z = -0.83f + t * t * 0.09f;
    float len = 0.022f - std::fabs(t) * 0.008f;
    b.add(cone(p, {x, 0.745f, z}, {x * 0.95f, 0.745f - len, z - 0.004f}, 0.0065f, 0.0012f), BONE, 0.002f);
    float z2 = -0.815f + t * t * 0.09f;
    b.add(cone(p, {x * 0.9f, 0.688f - (z2 + 0.83f) * 0.45f, z2}, {x * 0.85f, 0.688f - (z2 + 0.83f) * 0.45f + len * 0.8f, z2 - 0.004f}, 0.0055f, 0.001f), BONE, 0.002f);
  }
  // front limbs (arms) with claws
  b.add(cone(q, {0.16f, 0.86f, -0.36f}, {0.25f, 0.48f, -0.44f}, 0.050f, 0.036f), SKIN, 0.04f);
  b.add(sphere(q, {0.25f, 0.48f, -0.43f}, 0.036f), SKIN, 0.02f);
  b.add(cone(q, {0.25f, 0.48f, -0.44f}, {0.22f, 0.07f, -0.50f}, 0.035f, 0.024f), SKIN, 0.02f);
  b.add(ellipsoid(q, {0.22f, 0.04f, -0.56f}, {0.035f, 0.02f, 0.06f}), SKIN, 0.02f);
  for (int k = -1; k <= 1; ++k) {
    vec3 a{0.22f + k * 0.018f, 0.035f, -0.60f}, tip{0.22f + k * 0.03f, 0.008f, -0.72f};
    b.add(cone(q, a, tip, 0.0095f, 0.004f), SKIN, 0.006f);
    b.add(cone(q, tip, tip + vec3{0, -0.006f, -0.03f}, 0.005f, 0.001f), BONE, 0.002f);
  }
  // hind legs, bent the wrong way
  b.add(cone(q, {0.12f, 0.80f, 0.40f}, {0.22f, 0.42f, 0.18f}, 0.065f, 0.042f), SKIN, 0.05f);
  b.add(sphere(q, {0.22f, 0.42f, 0.18f}, 0.042f), SKIN, 0.02f);
  b.add(cone(q, {0.22f, 0.42f, 0.18f}, {0.19f, 0.06f, 0.46f}, 0.04f, 0.025f), SKIN, 0.02f);
  b.add(cone(q, {0.19f, 0.05f, 0.46f}, {0.19f, 0.02f, 0.28f}, 0.03f, 0.018f), SKIN, 0.015f);
  {
    float jeans = std::fabs(cone(q, {0.12f, 0.80f, 0.40f}, {0.22f, 0.42f, 0.18f}, 0.073f, 0.05f)) - 0.004f;
    float torn = (fbm(p * 11.0f + vec3{5, 2, 1}, 3) - 0.5f) * 0.07f;
    jeans = std::max(jeans, std::max(-torn, (0.5f + 0.05f * std::sin(p.z * 50.0f)) - p.y));
    b.add(jeans, GLOW, 0.004f);
  }
  float d = b.d + 0.0025f * fbm(p * 36.0f, 3);
  // ribs along the flank
  if (p.z < 0.0f && p.z > -0.45f && p.y < 0.98f) {
    float rib = std::pow(std::max(0.0f, std::sin(p.z * 70.0f)), 6.0f);
    d -= 0.005f * rib * smoothstepf(0.04f, 0.13f, std::fabs(p.x));
  }
  return {d, b.region};
}

// ------------------------------------------------------------------ the Grin
// A shape of soot that hangs in the dark parts. You see the teeth first.

std::vector<Bone> grinBones() {
  return {
      {-1, {0, 1.0f, 0}, {0, 1.8f, 0}},   // 0 body
      {0, {0, 1.8f, 0}, {0, 2.4f, 0}},    // 1 head
      {0, {0, 1.1f, 0}, {0, 0.3f, 0.05f}} // 2 trailing wisps
  };
}

SdfSample grinSdf(vec3 p) {
  SdfBuilder b;
  float n = fbm(p * 3.5f, 4);
  b.add(ellipsoid(p, {0, 1.5f, 0.02f}, {0.32f, 0.62f, 0.27f}) + n * 0.09f, SKIN, 0);
  b.add(cone(p, {0, 1.2f, 0.03f}, {0.02f, 0.35f, 0.1f}, 0.2f, 0.02f) + n * 0.07f, SKIN, 0.12f);
  b.add(ellipsoid(p, {0, 2.12f, -0.03f}, {0.29f, 0.26f, 0.25f}) + n * 0.035f, SKIN, 0.12f);
  // long hanging arms of smoke
  vec3 q = mirror(p);
  b.add(cone(q, {0.28f, 1.85f, 0}, {0.42f, 0.9f, -0.08f}, 0.06f, 0.015f) + n * 0.03f, SKIN, 0.1f);
  // the smile: carved cavity with two rows of teeth that curve too far up
  b.cut(ellipsoid(p, {0, 2.07f, -0.24f}, {0.2f, 0.06f, 0.09f}), 0.02f);
  for (int i = -8; i <= 8; ++i) {
    float t = i / 8.0f;
    float x = t * 0.19f, y = 2.07f + t * t * 0.055f, z = -0.285f + t * t * 0.06f;
    b.add(ellipsoid(p, {x, y + 0.022f, z}, {0.0105f, 0.022f, 0.01f}), GLOW, 0.003f);
    b.add(ellipsoid(p, {x * 0.96f, y - 0.022f, z + 0.004f}, {0.0105f, 0.02f, 0.01f}), GLOW, 0.003f);
  }
  b.cut(sphere(q, {0.095f, 2.21f, -0.29f}, 0.055f), 0.02f);
  b.add(sphere(q, {0.095f, 2.21f, -0.285f}, 0.038f), GLOW, 0);
  return {b.d, b.region};
}

// ------------------------------------------------------------------ the Stilt (Level 0)
// Mostly limbs. A dark, dried thing on legs too long and too thin to hold it up, a knot of a body
// near the ceiling, and a head like a seed pod with one pale wet spot on it. It stands very still.
std::vector<Bone> stiltBones() {
  std::vector<Bone> b = {
      {-1, {0, 1.5f, 0}, {0, 1.6f, 0}},             // 0 pelvis
      {0, {0, 1.6f, 0}, {0, 1.88f, -0.02f}},        // 1 spine
      {1, {0, 1.88f, -0.02f}, {0, 2.06f, -0.06f}},  // 2 chest
      {2, {0, 2.06f, -0.06f}, {0, 2.22f, -0.16f}},  // 3 neck
      {3, {0, 2.22f, -0.16f}, {0, 2.42f, -0.22f}},  // 4 head
      {4, {0, 2.27f, -0.2f}, {0, 2.24f, -0.27f}},   // 5 jaw
  };
  for (int s = 1; s >= -1; s -= 2) {
    int base = (int)b.size();
    b.push_back({2, {0.12f * s, 2.02f, -0.04f}, {0.2f * s, 1.45f, -0.02f}});
    b.push_back({base, {0.2f * s, 1.45f, -0.02f}, {0.23f * s, 0.9f, -0.06f}});
    b.push_back({base + 1, {0.23f * s, 0.9f, -0.06f}, {0.24f * s, 0.6f, -0.09f}});
  }
  for (int s = 1; s >= -1; s -= 2) {
    int base = (int)b.size();
    b.push_back({0, {0.07f * s, 1.5f, 0}, {0.11f * s, 0.8f, 0.04f}});
    b.push_back({base, {0.11f * s, 0.8f, 0.04f}, {0.1f * s, 0.07f, 0.02f}});
    b.push_back({base + 1, {0.1f * s, 0.07f, 0.02f}, {0.1f * s, 0.02f, -0.13f}});
  }
  return b;
}

SdfSample stiltSdf(vec3 p) {
  SdfBuilder b;
  vec3 q = mirror(p);
  float bark = 0.002f * fbm(p * 60.0f, 3);
  // the knot of a body, hunched, ribs like knuckles
  b.add(ellipsoid(p, {0, 1.95f, -0.02f}, {0.085f, 0.15f, 0.07f}) + bark, SKIN, 0);
  b.add(cone(p, {0, 1.52f, 0.0f}, {0, 1.82f, -0.01f}, 0.035f, 0.05f) + bark, SKIN, 0.04f);
  b.add(ellipsoid(p, {0, 1.52f, 0}, {0.07f, 0.05f, 0.05f}) + bark, SKIN, 0.03f);
  for (int i = 0; i < 9; ++i) b.add(sphere(p, {0, 1.6f + i * 0.05f, 0.05f + 0.02f * std::sin(i * 0.9f)}, 0.014f), BONE, 0.012f);
  // a long thin neck and the seed-pod head
  b.add(cone(p, {0, 2.04f, -0.05f}, {0, 2.24f, -0.17f}, 0.02f, 0.016f) + bark, SKIN, 0.02f);
  b.add(ellipsoid(p, {0, 2.33f, -0.2f}, {0.055f, 0.1f, 0.075f}) + bark, SKIN, 0.03f);
  b.add(ellipsoid(p, {0, 2.42f, -0.17f}, {0.03f, 0.06f, 0.04f}) + bark, SKIN, 0.03f);
  b.add(sphere(p, {0.012f, 2.34f, -0.268f}, 0.017f), GLOW, 0.004f);  // the pale wet spot
  b.cut(ellipsoid(p, {0, 2.26f, -0.255f}, {0.02f, 0.004f, 0.02f}), 0.003f);
  // arms: sticks with knobbed joints, fingers longer than hands should be
  b.add(cone(q, {0.12f, 2.02f, -0.04f}, {0.2f, 1.45f, -0.02f}, 0.02f, 0.014f) + bark, SKIN, 0.02f);
  b.add(sphere(q, {0.2f, 1.45f, -0.02f}, 0.022f), BONE, 0.01f);
  b.add(cone(q, {0.2f, 1.45f, -0.02f}, {0.23f, 0.9f, -0.06f}, 0.014f, 0.011f) + bark, SKIN, 0.01f);
  b.add(sphere(q, {0.23f, 0.9f, -0.06f}, 0.016f), BONE, 0.008f);
  for (int k = 0; k < 3; ++k) {
    float z = -0.08f + k * 0.022f;
    b.add(cone(q, {0.23f, 0.89f, -0.06f}, {0.24f + k * 0.006f, 0.58f, z}, 0.007f, 0.0035f), SKIN, 0.004f);
  }
  // legs: impossibly long, a backward kink at the knee
  b.add(cone(q, {0.07f, 1.5f, 0}, {0.11f, 0.8f, 0.04f}, 0.024f, 0.016f) + bark, SKIN, 0.02f);
  b.add(sphere(q, {0.11f, 0.8f, 0.04f}, 0.025f), BONE, 0.01f);
  b.add(cone(q, {0.11f, 0.8f, 0.04f}, {0.1f, 0.07f, 0.02f}, 0.016f, 0.011f) + bark, SKIN, 0.01f);
  b.add(cone(q, {0.1f, 0.07f, 0.02f}, {0.1f, 0.012f, -0.14f}, 0.014f, 0.007f), SKIN, 0.008f);
  return {b.d, b.region};
}

// ------------------------------------------------------------------ the Partygoers
// Tall yellow felt tubes with a smile painted on, arms too long, no legs you can see. Slow.
// Stained. They want you to come to the party.
std::vector<Bone> partyBones() {
  std::vector<Bone> b = {
      {-1, {0, 0.05f, 0}, {0, 0.9f, 0}},   // 0 skirt
      {0, {0, 0.9f, 0}, {0, 1.5f, 0}},     // 1 body
      {1, {0, 1.5f, 0}, {0, 2.1f, 0}},     // 2 head
  };
  for (int s = 1; s >= -1; s -= 2) {
    int base = (int)b.size();
    b.push_back({1, {0.2f * s, 1.52f, 0}, {0.28f * s, 1.12f, -0.02f}});
    b.push_back({base, {0.28f * s, 1.12f, -0.02f}, {0.33f * s, 0.74f, -0.04f}});
  }
  return b;
}

SdfSample partySdf(vec3 p) {
  SdfBuilder b;
  vec3 q = mirror(p);
  float felt = 0.0025f * fbm(p * 40.0f, 3);
  // one long sock of a body, flaring at the floor, rounding off at the top
  b.add(cone(p, {0, 0.02f, 0}, {0, 1.55f, 0}, 0.31f, 0.2f) + felt, SKIN, 0);
  b.add(cone(p, {0, 1.5f, 0}, {0, 1.95f, 0}, 0.2f, 0.17f) + felt, SKIN, 0.06f);
  b.add(sphere(p, {0, 1.95f, 0.0f}, 0.17f) + felt, SKIN, 0.05f);
  // arms like stuffed tubes
  b.add(cone(q, {0.215f, 1.5f, 0}, {0.29f, 1.12f, -0.02f}, 0.068f, 0.06f) + felt, SKIN, 0.014f);
  b.add(cone(q, {0.29f, 1.12f, -0.02f}, {0.335f, 0.78f, -0.04f}, 0.06f, 0.055f) + felt, SKIN, 0.01f);
  b.add(ellipsoid(q, {0.335f, 0.74f, -0.05f}, {0.06f, 0.07f, 0.055f}) + felt, SKIN, 0.02f);
  // the painted smile: two eye blots and a wide grin, slightly raised paint
  b.add(ellipsoid(q, {0.065f, 1.9f, -0.162f}, {0.032f, 0.05f, 0.012f}), EYE, 0.003f);
  for (int i = -7; i <= 7; ++i) {
    float t = i / 7.0f;
    vec3 c{t * 0.1f, 1.77f + t * t * 0.045f, -0.168f + t * t * 0.02f};
    b.add(sphere(p, c, 0.018f - std::fabs(t) * 0.005f), EYE, 0.008f);
  }
  float d = b.d;
  int reg = b.region;
  // old stains soaked into the felt, darkest at the hands and the hem
  if (reg == SKIN) {
    float st = fbm(p * 5.0f + vec3{2, 7, 1}, 3) + (p.y < 0.4f ? 0.12f : 0.0f) + (std::fabs(p.x) > 0.28f && p.y < 1.0f ? 0.15f : 0.0f);
    if (st > 0.66f) reg = BONE;
  }
  return {d, reg};
}

// ------------------------------------------------------------------ props

SdfSample chairSdf(vec3 p) {
  SdfBuilder b;
  vec3 q = mirror(p);
  b.add(box(p, {0, 0.47f, 0}, {0.24f, 0.045f, 0.23f}, 0.035f), SKIN, 0);
  b.add(box(p, {0, 0.84f, 0.235f}, {0.22f, 0.24f, 0.035f}, 0.03f), SKIN, 0.01f);
  b.add(box(p, {0, 0.58f, 0.25f}, {0.03f, 0.1f, 0.015f}, 0.008f), EYE, 0.005f);
  b.add(box(q, {0.24f, 0.62f, 0.0f}, {0.025f, 0.012f, 0.13f}, 0.01f), SKIN, 0);
  b.add(cone(q, {0.24f, 0.62f, 0.05f}, {0.22f, 0.48f, 0.05f}, 0.012f, 0.012f), EYE, 0.005f);
  b.add(cylinder(p, {0, 0.3f, 0}, 0.026f, 0.15f, 0.005f), EYE, 0.01f);
  b.add(cylinder(p, {0, 0.36f, 0}, 0.035f, 0.05f, 0.01f), EYE, 0.01f);
  for (int k = 0; k < 5; ++k) {
    float a = k * 2.0f * kPi / 5.0f;
    vec3 tip{std::sin(a) * 0.3f, 0.07f, std::cos(a) * 0.3f};
    b.add(cone(p, {0, 0.13f, 0}, tip, 0.02f, 0.016f), EYE, 0.02f);
    b.add(sphere(p, tip - vec3{0, 0.035f, 0}, 0.03f), SKIN, 0.0f);
  }
  return {b.d + 0.0008f * fbm(p * 90.0f, 2), b.region};
}

SdfSample boxSdf(vec3 p) {
  SdfBuilder b;
  float sag = 0.006f * std::sin(p.x * 9.0f) * std::sin(p.z * 11.0f);
  b.add(box(p, {0, 0.19f, 0}, {0.24f, 0.19f, 0.18f}, 0.006f) + sag, SKIN, 0);
  // two flaps folded half open
  b.add(box(p, {0.0f, 0.43f, -0.12f}, {0.23f, 0.004f, 0.09f}, 0.002f), SKIN, 0.0f);
  b.add(box(p, {0.0f, 0.39f, 0.21f}, {0.23f, 0.06f, 0.004f}, 0.002f), SKIN, 0.0f);
  b.add(box(p, {0, 0.38f, 0.0f}, {0.03f, 0.004f, 0.18f}, 0.001f), BONE, 0.0f);  // tape
  return {b.d, b.region};
}

SdfSample bagSdf(vec3 p) {
  SdfBuilder b;
  float n = fbm(p * 6.0f, 3);
  float wr = 0.012f * std::sin(p.x * 22.0f + n * 4.0f);  // quilted ridges
  b.add(box(p, {0, 0.07f, 0}, {0.85f, 0.07f, 0.34f}, 0.065f) + n * 0.025f + wr, SKIN, 0);
  b.add(box(p, {0.55f, 0.155f, 0.02f}, {0.32f, 0.02f, 0.3f}, 0.02f) + n * 0.02f, SKIN, 0.05f);  // folded-back flap
  b.add(ellipsoid(p, {-0.98f, 0.075f, 0.0f}, {0.16f, 0.07f, 0.26f}) + n * 0.012f, EYE, 0.03f);  // pillow
  float d = std::max(b.d, -p.y);
  return {d, b.region};
}

SdfSample lanternSdf(vec3 p) {
  SdfBuilder b;
  b.add(cylinder(p, {0, 0.03f, 0}, 0.06f, 0.03f, 0.008f), SKIN, 0);
  b.add(cylinder(p, {0, 0.13f, 0}, 0.045f, 0.07f, 0.005f), GLOW, 0.0f);
  b.add(cylinder(p, {0, 0.22f, 0}, 0.055f, 0.02f, 0.008f), SKIN, 0.0f);
  vec3 h = p - vec3{0, 0.27f, 0};
  float ring = std::sqrt(std::pow(std::sqrt(h.x * h.x + h.y * h.y) - 0.045f, 2.0f) + h.z * h.z) - 0.005f;
  b.add(ring, BONE, 0.0f);
  return {b.d, b.region};
}

SdfSample canSdf(vec3 p) {
  SdfBuilder b;
  b.add(cylinder(p, {0, 0.06f, 0}, 0.033f, 0.06f, 0.004f), SKIN, 0);
  b.add(cylinder(p, {0, 0.06f, 0}, 0.0335f, 0.035f, 0.0f), EYE, 0.0f);  // label band
  return {b.d, b.region};
}

SdfSample coolerSdf(vec3 p) {
  SdfBuilder b;
  b.add(box(p, {0, 0.5f, 0}, {0.16f, 0.5f, 0.16f}, 0.02f), SKIN, 0);
  b.add(cylinder(p, {0, 1.2f, 0}, 0.13f, 0.2f, 0.06f), GLOW, 0.02f);
  b.add(box(p, {0, 0.82f, -0.165f}, {0.05f, 0.03f, 0.02f}, 0.008f), EYE, 0.005f);
  return {b.d, b.region};
}


// ------------------------------------------------------------------ people
// Customers, Ray, Dana's suit. Same skeleton layout as the Tenant (so they share the
// animation code), normal proportions. Four outfits share one body.
// Regions: 0 skin, 1 hair/visor, 2 top, 3 trousers, 4 shoes, 5 shirt/accent, 6 belt/tie/gloves, 7 whites/metal.
enum HumanRegion { H_SKIN = 0, H_HAIR = 1, H_TOP = 2, H_LEGS = 3, H_SHOE = 4, H_SHIRT = 5, H_LEATHER = 6, H_WHITE = 7 };
enum Outfit { O_CASUAL = 0, O_SUIT, O_WORK, O_HAZMAT };

std::vector<Bone> humanBones() {
  std::vector<Bone> b = {
      {-1, {0, 0.95f, 0}, {0, 1.05f, 0}},
      {0, {0, 1.05f, 0}, {0, 1.30f, 0}},
      {1, {0, 1.30f, 0}, {0, 1.47f, 0}},
      {2, {0, 1.47f, 0}, {0, 1.58f, -0.01f}},
      {3, {0, 1.58f, -0.01f}, {0, 1.80f, -0.02f}},
      {4, {0, 1.63f, -0.03f}, {0, 1.61f, -0.10f}},
  };
  for (int s = 1; s >= -1; s -= 2) {
    int base = (int)b.size();
    b.push_back({2, {0.19f * s, 1.44f, 0.0f}, {0.23f * s, 1.16f, 0.01f}});
    b.push_back({base, {0.23f * s, 1.16f, 0.01f}, {0.25f * s, 0.92f, -0.01f}});
    b.push_back({base + 1, {0.25f * s, 0.92f, -0.01f}, {0.26f * s, 0.78f, -0.02f}});
  }
  for (int s = 1; s >= -1; s -= 2) {
    int base = (int)b.size();
    b.push_back({0, {0.1f * s, 0.95f, 0}, {0.11f * s, 0.52f, 0}});
    b.push_back({base, {0.11f * s, 0.52f, 0}, {0.11f * s, 0.09f, 0.02f}});
    b.push_back({base + 1, {0.11f * s, 0.09f, 0.02f}, {0.11f * s, 0.03f, -0.14f}});
  }
  return b;
}

// Cloth: soft horizontal folds that bunch at the joints, plus fine weave.
float clothFolds(vec3 p, float amp) {
  float elbow = std::exp(-std::pow((p.y - 1.16f) / 0.06f, 2.0f)) * smoothstepf(0.17f, 0.21f, std::fabs(p.x));
  float knee = std::exp(-std::pow((p.y - 0.52f) / 0.07f, 2.0f)) * smoothstepf(0.16f, 0.07f, std::fabs(p.x));
  float waist = std::exp(-std::pow((p.y - 1.06f) / 0.05f, 2.0f));
  float base = std::sin(p.y * 55.0f + std::sin(p.x * 23.0f + p.z * 17.0f) * 2.2f);
  return amp * (base * (0.35f + elbow + knee + waist * 0.6f));
}

void humanHands(SdfBuilder& b, vec3 q, int reg, float puff) {
  b.add(ellipsoid(q, {0.258f, 0.865f, -0.02f}, {0.022f + puff, 0.05f + puff, 0.04f + puff}), reg, 0.02f);
  for (int k = 0; k < 4; ++k) {
    float z = -0.047f + k * 0.019f, len = (k == 1 || k == 2) ? 0.062f : 0.052f;
    vec3 a{0.26f, 0.825f, z}, tip{0.264f, 0.825f - len, z - 0.008f};
    b.add(cone(q, a, tip, 0.0085f + puff * 0.5f, 0.0068f + puff * 0.4f), reg, 0.004f);
  }
  b.add(cone(q, {0.248f, 0.885f, -0.05f}, {0.244f, 0.835f, -0.078f}, 0.0115f + puff * 0.5f, 0.0085f + puff * 0.4f), reg, 0.008f);
}

void humanFace(SdfBuilder& b, vec3 p, vec3 q) {
  b.add(cone(p, {0, 1.45f, 0}, {0, 1.6f, -0.01f}, 0.055f, 0.05f), H_SKIN, 0.03f);              // neck
  b.add(ellipsoid(p, {0, 1.54f, -0.045f}, {0.012f, 0.014f, 0.01f}), H_SKIN, 0.01f);              // throat
  b.add(ellipsoid(p, {0, 1.7f, -0.02f}, {0.083f, 0.108f, 0.098f}), H_SKIN, 0.03f);              // skull
  b.add(ellipsoid(p, {0, 1.635f, -0.06f}, {0.058f, 0.045f, 0.058f}), H_SKIN, 0.03f);            // jaw
  b.add(ellipsoid(p, {0, 1.618f, -0.092f}, {0.022f, 0.016f, 0.02f}), H_SKIN, 0.015f);           // chin
  b.add(ellipsoid(q, {0.045f, 1.688f, -0.086f}, {0.026f, 0.017f, 0.02f}), H_SKIN, 0.015f);      // cheekbones
  b.add(cone(p, {0, 1.728f, -0.104f}, {0, 1.678f, -0.128f}, 0.009f, 0.013f), H_SKIN, 0.01f);    // nose bridge
  b.add(sphere(p, {0, 1.676f, -0.124f}, 0.012f), H_SKIN, 0.008f);                               // tip
  b.add(sphere(q, {0.012f, 1.672f, -0.116f}, 0.0085f), H_SKIN, 0.006f);                         // nostril wings
  b.add(ellipsoid(q, {0.083f, 1.69f, -0.01f}, {0.012f, 0.028f, 0.02f}), H_SKIN, 0.01f);         // ears
  b.cut(ellipsoid(q, {0.091f, 1.69f, -0.012f}, {0.005f, 0.017f, 0.011f}), 0.004f);
  b.cut(sphere(q, {0.033f, 1.71f, -0.112f}, 0.017f), 0.008f);                                   // sockets
  b.add(sphere(q, {0.033f, 1.708f, -0.0975f}, 0.0115f), H_WHITE, 0);                             // eyeballs, set back
  b.add(sphere(q, {0.033f, 1.708f, -0.1048f}, 0.0072f), H_HAIR, 0);                              // irises
  b.add(ellipsoid(q, {0.033f, 1.7215f, -0.102f}, {0.0168f, 0.0068f, 0.0112f}), H_SKIN, 0.004f);  // upper lids (eyes open ~12 mm, not slits)
  b.add(ellipsoid(q, {0.033f, 1.6955f, -0.1015f}, {0.0158f, 0.0045f, 0.0102f}), H_SKIN, 0.004f); // lower lids
  b.add(ellipsoid(q, {0.034f, 1.69f, -0.103f}, {0.017f, 0.006f, 0.008f}), H_SKIN, 0.008f);      // the soft bags under them
  b.add(cone(q, {0.014f, 1.668f, -0.112f}, {0.03f, 1.645f, -0.1f}, 0.005f, 0.004f), H_SKIN, 0.008f);  // nose-to-mouth folds
  b.add(cone(q, {0.012f, 1.738f, -0.108f}, {0.052f, 1.742f, -0.098f}, 0.0065f, 0.0045f), H_HAIR, 0.004f);  // brows
  b.add(ellipsoid(p, {0, 1.653f, -0.111f}, {0.021f, 0.0055f, 0.009f}), H_SKIN, 0.006f);          // lips
  b.add(ellipsoid(p, {0, 1.642f, -0.108f}, {0.018f, 0.006f, 0.009f}), H_SKIN, 0.006f);
  b.cut(ellipsoid(p, {0, 1.648f, -0.116f}, {0.02f, 0.0025f, 0.012f}), 0.003f);                  // mouth line
}

void humanHair(SdfBuilder& b, vec3 p, int style) {
  float hair;
  if (style == 1) {  // neat short side part
    hair = std::max(ellipsoid(p, {0, 1.732f, 0.0f}, {0.09f, 0.085f, 0.104f}), 1.712f - p.y - std::max(0.0f, p.z) * 1.1f);
    hair = std::max(hair, -(p.z + 0.08f) - std::max(0.0f, 1.765f - p.y) * 3.0f);
    hair += 0.0012f * std::sin(p.x * 160.0f + p.z * 40.0f);
  } else {  // fuller, a little messy
    hair = std::max(ellipsoid(p, {0, 1.738f, 0.008f}, {0.095f, 0.09f, 0.11f}), 1.69f - p.y - std::max(0.0f, p.z) * 0.8f);
    hair = std::max(hair, -(p.z + 0.072f) - std::max(0.0f, 1.755f - p.y) * 3.0f);
    hair += 0.004f * fbm(p * 48.0f, 2) + 0.0018f * std::sin(p.z * 120.0f + p.x * 30.0f);
  }
  b.add(hair, H_HAIR, 0.01f);
}

void humanShoes(SdfBuilder& b, vec3 q, int style) {
  if (style == 0) {  // sneakers: white sole, laces
    b.add(ellipsoid(q, {0.11f, 0.058f, -0.045f}, {0.052f, 0.05f, 0.128f}), H_SHOE, 0.02f);
    b.add(box(q, {0.11f, 0.014f, -0.042f}, {0.054f, 0.014f, 0.13f}, 0.012f), H_WHITE, 0.004f);
    for (int k = 0; k < 4; ++k) b.add(box(q, {0.11f, 0.085f - k * 0.008f, -0.07f - k * 0.022f}, {0.026f, 0.003f, 0.005f}, 0.002f), H_WHITE, 0.002f);
  } else if (style == 1) {  // dress shoes: narrow, glossy, low heel
    b.add(ellipsoid(q, {0.11f, 0.05f, -0.05f}, {0.046f, 0.045f, 0.13f}), H_SHOE, 0.02f);
    b.add(box(q, {0.11f, 0.008f, -0.05f}, {0.047f, 0.008f, 0.13f}, 0.006f), H_LEATHER, 0.003f);
    b.add(box(q, {0.11f, 0.02f, 0.055f}, {0.04f, 0.02f, 0.03f}, 0.006f), H_LEATHER, 0.004f);
  } else if (style == 2) {  // work boots: tall, chunky tread
    b.add(ellipsoid(q, {0.11f, 0.07f, -0.04f}, {0.058f, 0.07f, 0.135f}), H_SHOE, 0.02f);
    b.add(cone(q, {0.11f, 0.06f, 0.02f}, {0.11f, 0.17f, 0.02f}, 0.055f, 0.05f), H_SHOE, 0.02f);
    float tread = 0.003f * std::sin(q.z * 160.0f);
    b.add(box(q, {0.11f, 0.016f, -0.04f}, {0.06f, 0.016f, 0.138f}, 0.01f) + tread, H_LEATHER, 0.004f);
  } else {  // hazmat overboots
    b.add(ellipsoid(q, {0.11f, 0.07f, -0.04f}, {0.068f, 0.075f, 0.145f}) + 0.003f * fbm(q * 40.0f, 2), H_SHOE, 0.02f);
    b.add(cone(q, {0.11f, 0.06f, 0.02f}, {0.11f, 0.24f, 0.02f}, 0.068f, 0.066f) + 0.004f * std::sin(q.y * 70.0f), H_SHOE, 0.025f);
    b.add(box(q, {0.11f, 0.014f, -0.04f}, {0.068f, 0.014f, 0.148f}, 0.01f), H_SHIRT, 0.004f);
  }
}

// Trousers from the waist down; `suitLeg` adds a pressed front crease, cargo adds pockets.
void humanLegs(SdfBuilder& b, vec3 p, vec3 q, int outfit) {
  float puff = outfit == O_HAZMAT ? 0.018f : (outfit == O_WORK ? 0.006f : 0.0f);
  float folds = clothFolds(p, outfit == O_HAZMAT ? 0.006f : 0.0025f);
  float hemY = outfit == O_HAZMAT ? 0.2f : (outfit == O_WORK ? 0.15f : 0.1f);
  b.add(ellipsoid(p, {0, 0.97f, 0}, {0.17f + puff, 0.12f, 0.11f + puff}) + folds, H_LEGS, 0);
  b.add(cone(q, {0.1f, 0.95f, 0}, {0.11f, 0.52f, 0}, 0.078f + puff, 0.057f + puff) + folds, H_LEGS, 0.04f);
  b.add(cone(q, {0.11f, 0.52f, 0}, {0.11f, hemY, 0.02f}, 0.057f + puff, 0.05f + puff) + folds, H_LEGS, 0.02f);
  b.add(ellipsoid(q, {0.11f, 0.37f, 0.022f}, {0.056f + puff, 0.12f, 0.058f + puff}) + folds, H_LEGS, 0.04f);  // calves
  b.add(ellipsoid(q, {0.075f, 0.92f, 0.05f}, {0.085f + puff, 0.09f, 0.075f + puff}) + folds, H_LEGS, 0.05f);  // seat
  b.add(sphere(q, {0.11f, 0.53f, -0.03f}, 0.05f + puff) + folds, H_LEGS, 0.03f);                            // knees
  if (outfit == O_SUIT) b.add(cone(q, {0.11f, 0.9f, -0.075f}, {0.11f, 0.12f, -0.052f}, 0.006f, 0.005f), H_LEGS, 0.012f);  // crease
  if (outfit == O_CASUAL) {
    b.add(cone(q, {0.11f, hemY + 0.02f, 0.02f}, {0.11f, hemY - 0.005f, 0.02f}, 0.056f, 0.056f), H_LEGS, 0.006f);  // rolled cuff
    b.add(box(q, {0.1f, 0.92f, 0.105f}, {0.05f, 0.055f, 0.006f}, 0.006f), H_LEGS, 0.006f);  // back pockets
    b.cut(cone(q, {0.12f, 1.0f, -0.09f}, {0.16f, 0.9f, -0.06f}, 0.003f, 0.003f), 0.002f);    // front pocket seams
  }
  if (outfit == O_WORK)  // cargo pockets on the thighs
    b.add(box(q, {0.168f, 0.66f, 0.0f}, {0.012f, 0.07f, 0.05f}, 0.008f), H_LEGS, 0.008f);
  if (outfit != O_HAZMAT) {  // belt and buckle
    float belt = std::max(ellipsoid(p, {0, 1.0f, 0}, {0.165f, 0.5f, 0.114f}), std::fabs(p.y - 1.0f) - 0.02f);
    b.add(belt, H_LEATHER, 0.003f);
    b.add(box(p, {0, 1.0f, -0.116f}, {0.026f, 0.02f, 0.006f}, 0.003f), H_WHITE, 0.002f);
    for (int s = -1; s <= 1; s += 2)  // belt loops
      b.add(box(p, {s * 0.11f, 1.0f, -0.088f}, {0.006f, 0.028f, 0.005f}, 0.002f), H_LEGS, 0.002f);
  }
}

SdfSample humanSdfOutfit(vec3 p, int outfit) {
  SdfBuilder b;
  vec3 q = mirror(p);
  const bool haz = outfit == O_HAZMAT;
  float folds = clothFolds(p, haz ? 0.007f : 0.003f);
  humanLegs(b, p, q, outfit);
  humanShoes(b, q, haz ? 3 : (outfit == O_SUIT ? 1 : (outfit == O_WORK ? 2 : 0)));

  // ---- torso and arms
  float puff = haz ? 0.03f : (outfit == O_WORK ? 0.012f : (outfit == O_SUIT ? 0.008f : 0.0f));
  float hemY = outfit == O_SUIT ? 0.86f : (outfit == O_CASUAL ? 1.0f : 0.93f);
  // a torso that's wider than it is deep (a body, not a tube): chest, waist, shoulder caps, the slope to the neck
  vec3 pe{p.x, p.y, p.z * 1.4f};
  float tee = outfit == O_CASUAL ? 0.016f : 0.0f;  // a tee hangs straight down from the chest, it doesn't balloon at the belt
  b.add(cone(pe, {0, hemY, 0.01f}, {0, 1.36f, 0.0f}, 0.15f + puff - tee, 0.168f + puff) / 1.2f + folds, H_TOP, 0.06f);
  b.add(ellipsoid(p, {0, 1.33f, -0.01f}, {0.185f + puff, 0.13f + puff * 0.6f, 0.108f + puff}) + folds, H_TOP, 0.05f);
  b.add(ellipsoid(p, {0, 1.12f, -0.005f}, {0.15f + puff - tee, 0.12f, 0.098f + puff - tee * 0.6f}) + folds, H_TOP, 0.06f);   // waist
  b.add(sphere(q, {0.178f, 1.405f, 0.0f}, 0.06f + puff) + folds, H_TOP, 0.045f);                          // shoulder caps
  b.add(cone(q, {0.03f, 1.5f, 0.012f}, {0.16f, 1.445f, 0.006f}, 0.042f + puff, 0.038f + puff), H_TOP, 0.04f);  // trapezius
  b.add(ellipsoid(q, {0.07f, 1.3f, 0.07f}, {0.07f, 0.09f, 0.04f}) + folds, H_TOP, 0.04f);                   // shoulder blades
  b.add(cone(q, {0.0f, 1.44f, 0}, {0.19f, 1.43f, 0}, 0.065f + puff, 0.06f + puff), H_TOP, 0.05f);
  float sleeveEnd = outfit == O_CASUAL ? 0.45f : 1.0f;  // fraction down the arm
  vec3 sh{0.19f, 1.44f, 0}, el{0.23f, 1.16f, 0.01f}, wr{0.25f, 0.935f, -0.01f};
  // upper arm: sleeve (short for a tee), skin under it
  if (outfit == O_CASUAL) {
    vec3 cut = sh + (el - sh) * sleeveEnd;
    b.add(cone(q, sh, cut, 0.062f, 0.056f) + folds, H_TOP, 0.03f);
    b.add(cone(q, cut + vec3{0, 0.01f, 0}, cut - vec3{0, 0.006f, 0}, 0.057f, 0.057f), H_TOP, 0.004f);  // sleeve hem
    b.add(cone(q, cut, el, 0.046f, 0.04f), H_SKIN, 0.02f);
    b.add(cone(q, el, wr, 0.04f, 0.031f), H_SKIN, 0.02f);
    // crew neck
    b.add(cone(p, {0, 1.455f, 0.0f}, {0, 1.47f, -0.005f}, 0.064f, 0.062f), H_TOP, 0.008f);
    // hem over the belt
    b.add(cone(pe, {0, hemY + 0.012f, 0.01f}, {0, hemY - 0.006f, 0.01f}, 0.146f, 0.146f) / 1.2f, H_TOP, 0.006f);  // the hem, lying flat over the jeans
  } else {
    b.add(cone(q, sh, el, 0.058f + puff, 0.05f + puff) + folds, H_TOP, 0.03f);
    b.add(cone(q, el, wr, 0.05f + puff, 0.042f + puff * 0.8f) + folds, H_TOP, 0.03f);
  }
  if (outfit == O_SUIT) {
    // shirt in the V of the jacket, tie, lapels, buttons, pocket flaps, cuffs
    float vHalf = std::max(0.0f, (p.y - 1.13f) * 0.33f);
    float v = std::max(std::fabs(p.x) - vHalf, 1.13f - p.y);
    b.cut(std::max(v, p.z + 0.1f), 0.004f);
    b.add(std::max(std::max(cone(p, {0, 1.1f, 0}, {0, 1.42f, 0}, 0.152f, 0.16f) + 0.006f, 1.12f - p.y), p.z + 0.06f), H_SHIRT, 0.004f);
    b.add(box(p, {0, 1.27f, -0.125f}, {0.016f, 0.15f, 0.008f}, 0.006f), H_LEATHER, 0.004f);   // tie
    b.add(box(p, {0, 1.425f, -0.118f}, {0.019f, 0.018f, 0.012f}, 0.008f), H_LEATHER, 0.004f); // knot
    for (int s = -1; s <= 1; s += 2) {
      vec3 a{s * 0.035f, 1.44f, -0.112f}, c{s * 0.075f, 1.15f, -0.135f};
      b.add(cone(p, a, c, 0.012f, 0.01f), H_TOP, 0.01f);                                       // lapel roll
      b.add(cone(p, {s * 0.02f, 1.46f, -0.08f}, {s * 0.045f, 1.415f, -0.112f}, 0.012f, 0.008f), H_SHIRT, 0.004f);  // collar points
      b.add(box(p, {s * 0.105f, 0.98f, -0.118f}, {0.045f, 0.012f, 0.012f}, 0.004f), H_TOP, 0.006f);  // pocket flaps
    }
    for (float y : {1.08f, 0.98f}) b.add(sphere(p, {0, y, -0.15f}, 0.009f), H_LEATHER, 0.002f);
    b.add(cone(q, wr + vec3{0, 0.015f, 0}, wr - vec3{0, 0.012f, 0}, 0.037f, 0.037f), H_SHIRT, 0.004f);  // shirt cuffs
  }
  if (outfit == O_WORK) {
    b.add(box(p, {0, 1.18f, -0.172f}, {0.004f, 0.25f, 0.005f}, 0.002f), H_WHITE, 0.002f);    // zip
    for (int s = -1; s <= 1; s += 2) {
      b.add(box(p, {s * 0.085f, 1.29f, -0.168f}, {0.042f, 0.05f, 0.008f}, 0.006f), H_TOP, 0.006f);   // chest pockets
      b.add(box(p, {s * 0.085f, 1.335f, -0.174f}, {0.044f, 0.012f, 0.008f}, 0.004f), H_TOP, 0.004f);
    }
    b.add(ellipsoid(p, {-0.085f, 1.29f, -0.178f}, {0.03f, 0.016f, 0.003f}), H_SHIRT, 0.002f);     // name patch
    b.add(cone(p, {0, 1.45f, 0.01f}, {0, 1.49f, 0.0f}, 0.085f, 0.075f), H_TOP, 0.012f);        // collar
    b.add(cone(p, {0, hemY + 0.03f, 0}, {0, hemY - 0.005f, 0}, 0.166f, 0.162f) + 0.0015f * std::sin(std::atan2(p.z, p.x) * 60.0f), H_TOP, 0.008f);  // knit waistband
    b.add(cone(q, wr + vec3{0, 0.03f, 0}, wr - vec3{0, 0.005f, 0}, 0.047f, 0.043f), H_TOP, 0.006f);  // knit cuffs
    // cap
    float crown = std::max(ellipsoid(p, {0, 1.765f, -0.008f}, {0.097f, 0.065f, 0.108f}), 1.752f - p.y);
    b.add(crown, H_LEATHER, 0.004f);
    b.add(ellipsoid(p, {0, 1.757f, -0.13f}, {0.082f, 0.007f, 0.072f}), H_LEATHER, 0.004f);   // brim
  }
  if (haz) {
    // hood with a big dark visor, a filter under it, gloves taped at the wrist, markings, an air hose
    b.add(ellipsoid(p, {0, 1.70f, 0.005f}, {0.138f, 0.165f, 0.142f}) + 0.004f * fbm(p * 30.0f, 2), H_TOP, 0.05f);
    b.add(ellipsoid(p, {0, 1.555f, 0.0f}, {0.15f, 0.06f, 0.13f}), H_TOP, 0.05f);  // hood skirt over the shoulders
    b.add(ellipsoid(p, {0, 1.705f, -0.118f}, {0.088f, 0.08f, 0.04f}), H_HAIR, 0.006f);          // visor
    float rim = std::fabs(ellipsoid(p, {0, 1.705f, -0.118f}, {0.096f, 0.088f, 0.044f})) - 0.006f;
    b.add(std::max(rim, -(p.z + 0.11f)), H_SHIRT, 0.004f);
    b.add(cylinder(p - vec3{0, 0, 0}, {0, 1.6f, -0.135f}, 0.028f, 0.012f, 0.008f), H_SHIRT, 0.01f);  // filter
    humanHands(b, q, H_LEATHER, 0.008f);
    b.add(cone(q, wr + vec3{0.0f, 0.07f, 0.0f}, wr - vec3{0, 0.04f, 0}, 0.06f, 0.05f), H_LEATHER, 0.012f);  // gauntlets
    b.add(cone(q, wr + vec3{0, 0.085f, 0}, wr + vec3{0, 0.06f, 0}, 0.063f, 0.062f), H_SHIRT, 0.004f);     // tape
    b.add(box(p, {0, 1.2f, -0.2f}, {0.006f, 0.24f, 0.006f}, 0.003f), H_SHIRT, 0.003f);           // zip flap
    const vec3 spots[] = {{-0.17f, 1.22f, -0.07f}, {-0.15f, 1.12f, -0.1f}, {-0.2f, 1.05f, -0.04f}, {0.13f, 0.72f, -0.08f}, {0.16f, 1.33f, -0.12f}};
    for (vec3 s : spots) b.add(sphere(p, s, 0.016f) + 0.0f, H_SHIRT, 0.0f);
    b.add(cone(p, {0.05f, 1.28f, 0.16f}, {0.09f, 1.0f, 0.2f}, 0.016f, 0.016f), H_WHITE, 0.01f);   // air hose
    b.add(cone(p, {0.09f, 1.0f, 0.2f}, {0.12f, 0.7f, 0.17f}, 0.016f, 0.016f), H_WHITE, 0.01f);
  } else {
    humanFace(b, p, q);
    if (outfit != O_WORK) humanHair(b, p, outfit == O_SUIT ? 1 : 0);
    else humanHair(b, p, 1);
    humanHands(b, q, H_SKIN, 0.0f);
  }
  return {b.d + 0.0009f * fbm(p * 70.0f, 2), b.region};
}

SdfSample humanSdf(vec3 p) { return humanSdfOutfit(p, O_CASUAL); }
SdfSample suitSdf(vec3 p) { return humanSdfOutfit(p, O_SUIT); }
SdfSample workerSdf(vec3 p) { return humanSdfOutfit(p, O_WORK); }
SdfSample hazmatSdf(vec3 p) { return humanSdfOutfit(p, O_HAZMAT); }

// ------------------------------------------------------------------ store fixtures
// Gondola shelving, 2 m long (x), double sided. Products by domain repetition.
SdfSample shelfSdf(vec3 p) {
  SdfBuilder b;
  vec3 a{p.x, p.y, std::fabs(p.z)};  // mirror the two faces
  b.add(box(p, {0, 0.06f, 0}, {1.0f, 0.06f, 0.44f}, 0.01f), EYE, 0);                 // kick plate
  b.add(box(p, {0, 0.82f, 0}, {0.98f, 0.8f, 0.025f}, 0.005f), EYE, 0.0f);            // pegboard spine
  for (float y : {0.15f, 0.55f, 0.95f, 1.35f}) b.add(box(a, {0, y, 0.24f}, {0.99f, 0.012f, 0.2f}, 0.004f), EYE, 0);
  b.add(box(p, {0.99f, 0.82f, 0}, {0.012f, 0.8f, 0.44f}, 0.004f), EYE, 0);            // end uprights
  b.add(box(p, {-0.99f, 0.82f, 0}, {0.012f, 0.8f, 0.44f}, 0.004f), EYE, 0);
  // stock: boxes, bottles and cans in a few colours, one row per shelf, both faces
  const float pitch = 0.14f;
  int cell = (int)std::floor((p.x + 1.0f) / pitch);
  for (int c = cell - 1; c <= cell + 1; ++c) {
    if (c < 0 || c >= 14) continue;
    float cx = -1.0f + (c + 0.5f) * pitch;
    for (int shelf = 0; shelf < 4; ++shelf) {
      float y0 = 0.162f + shelf * 0.4f;
      for (int side = -1; side <= 1; side += 2) {
        float hsh = hashf(c, shelf * 2 + (side > 0), 77);
        if (hsh < 0.12f) continue;  // gaps where stock ran out
        int reg = 1 + (int)(hash32((uint32_t)(c * 31 + shelf * 7 + side * 3)) % 3);
        float hgt = 0.12f + hashf(c, shelf, side + 9) * 0.16f;
        float zc = side * (0.31f - hashf(c, shelf, side) * 0.05f);
        if (shelf % 2 == 0)
          b.add(box(p, {cx, y0 + hgt * 0.5f, zc}, {pitch * 0.42f, hgt * 0.5f, 0.1f}, 0.006f), reg, 0);
        else
          b.add(cylinder(p, {cx, y0 + hgt * 0.5f, zc}, 0.04f, hgt * 0.5f, 0.01f), reg, 0);
      }
    }
  }
  return {b.d, b.region};
}

SdfSample counterSdf(vec3 p) {
  SdfBuilder b;
  b.add(box(p, {0, 0.46f, 0}, {1.0f, 0.46f, 0.34f}, 0.01f), SKIN, 0);              // body
  b.add(box(p, {0, 0.94f, 0}, {1.02f, 0.025f, 0.38f}, 0.008f), BONE, 0);            // top
  b.add(box(p, {0.6f, 0.975f, -0.2f}, {0.16f, 0.01f, 0.12f}, 0.004f), EYE, 0);        // rubber change mat
  b.add(box(p, {0, 0.46f, 0.345f}, {0.95f, 0.38f, 0.004f}, 0.002f), BONE, 0);        // clerk-side shelf panel
  b.add(box(p, {0, 0.5f, -0.345f}, {0.98f, 0.012f, 0.006f}, 0.003f), BONE, 0);       // trim strips on the customer face
  b.add(box(p, {0, 0.12f, -0.345f}, {0.98f, 0.06f, 0.006f}, 0.003f), EYE, 0);        // kick plate
  b.add(box(p, {-0.55f, 1.0f, -0.05f}, {0.12f, 0.035f, 0.1f}, 0.01f), EYE, 0.0f);    // card reader
  b.add(box(p, {-0.75f, 1.1f, 0.0f}, {0.2f, 0.14f, 0.16f}, 0.01f), BONE, 0.0f);      // lottery/candy rack
  return {b.d, b.region};
}

SdfSample freezerSdf(vec3 p) {
  SdfBuilder b;
  b.add(box(p, {0, 1.0f, 0.05f}, {0.5f, 1.0f, 0.38f}, 0.02f), SKIN, 0);              // cabinet
  b.add(box(p, {0, 1.02f, -0.335f}, {0.44f, 0.86f, 0.012f}, 0.006f), GLOW, 0.0f);   // lit glass door
  b.add(box(p, {0.38f, 1.0f, -0.36f}, {0.012f, 0.3f, 0.02f}, 0.006f), EYE, 0.0f);    // handle
  b.add(box(p, {0, 1.95f, -0.34f}, {0.5f, 0.05f, 0.02f}, 0.006f), EYE, 0.0f);        // header strip
  return {b.d, b.region};
}

SdfSample panelSdf(vec3 p) {
  SdfBuilder b;
  b.add(box(p, {0, 1.45f, 0}, {0.26f, 0.38f, 0.06f}, 0.01f), SKIN, 0);
  b.add(box(p, {0, 1.45f, -0.065f}, {0.22f, 0.33f, 0.006f}, 0.004f), EYE, 0);
  for (int r = 0; r < 6; ++r)
    for (int c = -1; c <= 1; c += 2)
      b.add(box(p, {c * 0.08f, 1.22f + r * 0.09f, -0.075f}, {0.05f, 0.015f, 0.012f}, 0.003f), BONE, 0);
  b.add(sphere(p, {0.18f, 1.75f, -0.07f}, 0.012f), GLOW, 0);
  b.add(cylinder(p, {0, 2.2f, 0}, 0.035f, 0.4f, 0.0f), EYE, 0.0f);                    // conduit up
  return {b.d, b.region};
}

SdfSample boilerSdf(vec3 p) {
  SdfBuilder b;
  b.add(cylinder(p, {0, 0.85f, 0}, 0.36f, 0.82f, 0.05f) + 0.003f * fbm(p * 30.0f, 2), SKIN, 0);
  b.add(cylinder(p, {0, 0.05f, 0}, 0.4f, 0.05f, 0.01f), EYE, 0.0f);
  b.add(cylinder(p, {0, 1.95f, 0}, 0.06f, 0.35f, 0.0f), EYE, 0.0f);
  b.add(box(p, {0, 0.5f, -0.36f}, {0.1f, 0.08f, 0.02f}, 0.01f), BONE, 0.0f);
  b.add(sphere(p, {0.1f, 1.2f, -0.36f}, 0.05f), BONE, 0.0f);                           // gauge
  return {b.d, b.region};
}

SdfSample lockerSdf(vec3 p) {
  SdfBuilder b;
  b.add(box(p, {0, 0.95f, 0}, {0.27f, 0.95f, 0.27f}, 0.01f), SKIN, 0);
  for (int k = 0; k < 6; ++k)  // vent slits in the door (you can see out)
    b.cut(box(p, {0, 1.55f + k * 0.035f, -0.27f}, {0.15f, 0.007f, 0.02f}, 0.002f), 0.002f);
  b.add(box(p, {0.2f, 1.0f, -0.28f}, {0.012f, 0.08f, 0.015f}, 0.004f), BONE, 0);
  b.add(box(p, {0, 0.95f, -0.272f}, {0.255f, 0.93f, 0.004f}, 0.002f), SKIN, 0);
  return {b.d, b.region};
}

SdfSample couchSdf(vec3 p) {
  SdfBuilder b;
  float base = box(p, {0, 0.3f, 0.02f}, {0.98f, 0.16f, 0.42f}, 0.06f);
  b.add(base, SKIN, 0);
  for (int k = -1; k <= 1; k += 2)  // seat cushions, slightly sagging
    b.add(box(p, {k * 0.44f, 0.5f - 0.012f * std::cos(p.x * 3.0f), -0.04f}, {0.43f, 0.07f, 0.36f}, 0.06f), SKIN, 0.02f);
  for (int k = -1; k <= 1; k += 2) b.add(box(p, {k * 0.44f, 0.78f, 0.3f}, {0.42f, 0.24f, 0.1f}, 0.08f), SKIN, 0.03f);  // back
  for (int k = -1; k <= 1; k += 2) b.add(box(p, {k * 0.96f, 0.52f, 0.02f}, {0.1f, 0.14f, 0.44f}, 0.07f), SKIN, 0.03f);  // arms
  for (int sx = -1; sx <= 1; sx += 2)
    for (int sz = -1; sz <= 1; sz += 2) b.add(cylinder(p, {sx * 0.9f, 0.06f, sz * 0.36f}, 0.03f, 0.06f, 0.01f), BONE, 0);
  b.add(box(p, {-0.5f, 0.66f, 0.12f}, {0.2f, 0.16f, 0.07f}, 0.07f), EYE, 0.03f);  // a throw pillow
  return {b.d + 0.002f * fbm(p * 40.0f, 2), b.region};
}

SdfSample tvSdf(vec3 p) {
  SdfBuilder b;
  b.add(box(p, {0, 0.25f, 0}, {0.6f, 0.25f, 0.22f}, 0.01f), BONE, 0);                 // stand
  b.cut(box(p, {0, 0.22f, -0.22f}, {0.52f, 0.14f, 0.06f}, 0.01f), 0.004f);            // open shelf
  b.add(box(p, {-0.2f, 0.16f, -0.08f}, {0.18f, 0.04f, 0.12f}, 0.01f), EYE, 0);        // VCR
  b.add(box(p, {0, 0.74f, 0.03f}, {0.32f, 0.24f, 0.23f}, 0.04f), EYE, 0);             // CRT body
  b.add(box(p, {0, 0.76f, 0.24f}, {0.22f, 0.17f, 0.08f}, 0.06f), EYE, 0.04f);         // tube back
  b.add(box(p, {0, 0.74f, -0.205f}, {0.27f, 0.2f, 0.01f}, 0.03f), GLOW, 0);           // glass
  b.add(cylinder(p, {0.24f, 0.56f, -0.205f}, 0.012f, 0.008f), SKIN, 0);              // power light
  return {b.d, b.region};
}

SdfSample tableSdf(vec3 p) {
  SdfBuilder b;
  b.add(box(p, {0, 0.4f, 0}, {0.55f, 0.025f, 0.3f}, 0.01f), BONE, 0);
  for (int sx = -1; sx <= 1; sx += 2)
    for (int sz = -1; sz <= 1; sz += 2) b.add(box(p, {sx * 0.48f, 0.19f, sz * 0.24f}, {0.025f, 0.19f, 0.025f}, 0.005f), BONE, 0);
  b.add(cylinder(p, {0.2f, 0.47f, 0.05f}, 0.045f, 0.05f, 0.005f), SKIN, 0);          // mug
  b.cut(cylinder(p, {0.2f, 0.5f, 0.05f}, 0.036f, 0.05f), 0.002f);
  b.add(box(p, {-0.15f, 0.435f, -0.05f}, {0.03f, 0.01f, 0.09f}, 0.008f), EYE, 0);     // remote
  return {b.d, b.region};
}

SdfSample tubeSdf(vec3 p) {  // the rim of a slide opening, facing -Z out of a wall
  SdfBuilder b;
  float rr = std::sqrt(p.x * p.x + p.y * p.y);
  float qx = rr - 0.5f, qz = p.z + 0.035f;
  b.add(std::sqrt(qx * qx + qz * qz) - 0.07f, SKIN, 0);
  // a short lip of tube going into the wall, so the rim reads as a pipe end
  float shell = std::max(std::max(rr - 0.53f, -(rr - 0.47f)), std::fabs(p.z - 0.02f) - 0.05f);
  b.add(shell, SKIN, 0.01f);
  return {b.d, b.region};
}

SdfSample lampSdf(vec3 p) {
  SdfBuilder b;
  b.add(cylinder(p, {0, 0.02f, 0}, 0.15f, 0.02f, 0.01f), EYE, 0);
  b.add(cylinder(p, {0, 0.75f, 0}, 0.012f, 0.74f), EYE, 0);
  float shade = cone(p, {0, 1.38f, 0}, {0, 1.62f, 0}, 0.22f, 0.14f);
  shade = std::max(shade, -cone(p, {0, 1.36f, 0}, {0, 1.64f, 0}, 0.21f, 0.13f));
  b.add(shade, GLOW, 0);
  return {b.d, b.region};
}

SdfSample cartSdf(vec3 p) {
  SdfBuilder b;
  // wire basket: hollow box with bars
  float basket = box(p, {0, 0.68f, 0}, {0.25f, 0.2f, 0.42f}, 0.01f);
  basket = std::max(basket, -box(p, {0, 0.72f, 0}, {0.235f, 0.2f, 0.405f}, 0.01f));
  float bars = std::fabs(std::sin(p.x * 70.0f)) * std::fabs(std::sin(p.z * 70.0f));
  b.add(basket + (bars < 0.4f ? 0.0f : 0.004f), SKIN, 0);
  b.add(cone(p, {-0.25f, 0.9f, 0.45f}, {0.25f, 0.9f, 0.45f}, 0.014f, 0.014f), BONE, 0.0f);   // handle
  for (int sx = -1; sx <= 1; sx += 2)
    for (int sz = -1; sz <= 1; sz += 2) {
      b.add(cone(p, {sx * 0.22f, 0.48f, sz * 0.38f}, {sx * 0.2f, 0.07f, sz * 0.36f}, 0.01f, 0.01f), SKIN, 0.0f);
      b.add(sphere(p, {sx * 0.2f, 0.045f, sz * 0.36f}, 0.045f), EYE, 0.0f);
    }
  b.add(box(p, {0, 0.2f, 0}, {0.2f, 0.01f, 0.35f}, 0.005f), SKIN, 0.0f);                       // bottom rack
  return {b.d, b.region};
}

// The register: a beige 90s electronic till. Model space: clerk side +z, customer -z,
// origin on the counter top.
SdfSample registerSdf(vec3 p) {
  SdfBuilder b;
  float base = box(p, {0, 0.065f, 0}, {0.2f, 0.065f, 0.19f}, 0.012f);
  base = std::max(base, -box(p, {0, 0.045f, 0.12f}, {0.178f, 0.036f, 0.12f}, 0.004f));  // drawer bay
  b.add(base, 0, 0);
  // sloped keypad deck, high at the back (customer side)
  float deck = std::max(box(p, {0, 0.17f, 0.01f}, {0.19f, 0.06f, 0.16f}, 0.015f), (p.y - 0.19f) + p.z * 0.32f);
  b.add(deck, 0, 0.01f);
  // keys: domain repetition across the slope
  {
    float kx = 0.034f, kz = 0.03f;
    float cx = std::round((p.x + 0.115f) / kx), cz = std::round((p.z - 0.005f) / kz);
    cx = clampf(cx, 0, 7); cz = clampf(cz, 0, 4);
    vec3 c{-0.115f + cx * kx, 0, 0.005f + cz * kz};
    c.y = 0.19f - c.z * 0.32f + 0.003f;
    int reg = (cx >= 6 || (cz == 4 && cx < 2)) ? 2 : 1;
    b.add(box(p, c, {0.012f, 0.006f, 0.0105f}, 0.003f), reg, 0.0f);
  }
  // clerk display on a short neck
  b.add(box(p, {0, 0.26f, -0.09f}, {0.11f, 0.04f, 0.025f}, 0.008f), 0, 0.01f);
  b.add(box(p, {0, 0.262f, -0.064f}, {0.088f, 0.024f, 0.004f}, 0.002f), 3, 0.0f);
  // customer pole display
  b.add(cylinder(p, {0.145f, 0.32f, -0.15f}, 0.011f, 0.1f), 0, 0.004f);
  b.add(box(p, {0.145f, 0.44f, -0.15f}, {0.065f, 0.026f, 0.02f}, 0.006f), 0, 0.004f);
  b.add(box(p, {0.145f, 0.44f, -0.171f}, {0.054f, 0.016f, 0.003f}, 0.002f), 3, 0.0f);
  // receipt printer with a curl of paper
  b.add(box(p, {-0.14f, 0.235f, -0.125f}, {0.05f, 0.035f, 0.05f}, 0.01f), 0, 0.01f);
  b.add(box(p, {-0.14f, 0.29f, -0.135f}, {0.032f, 0.03f, 0.0015f}, 0.001f), 2, 0.0f);
  return {b.d, b.region};
}

// Cash drawer: tray with bill slots and coin cups. Origin at the drawer's bottom centre.
SdfSample drawerSdf(vec3 p) {
  SdfBuilder b;
  float tray = box(p, {0, 0.035f, 0}, {0.17f, 0.035f, 0.115f}, 0.004f);
  tray = std::max(tray, -box(p, {0, 0.05f, -0.005f}, {0.16f, 0.035f, 0.1f}, 0.003f));
  b.add(tray, 0, 0);
  for (int k = 0; k < 4; ++k) {  // dividers and bills under their clips
    float x = -0.12f + k * 0.08f;
    b.add(box(p, {x + 0.04f, 0.04f, -0.035f}, {0.002f, 0.03f, 0.065f}, 0.001f), 0, 0);
    b.add(box(p, {x, 0.022f + 0.004f * (k % 2), -0.035f}, {0.034f, 0.008f, 0.062f}, 0.002f), 1, 0.0f);
    b.add(box(p, {x, 0.045f, -0.06f}, {0.006f, 0.004f, 0.03f}, 0.002f), 2, 0.0f);  // clip
  }
  for (int k = 0; k < 5; ++k) {  // coin cups along the front
    vec3 c{-0.13f + k * 0.065f, 0.02f, 0.07f};
    b.add(cylinder(p, c, 0.026f, 0.012f, 0.004f), 3, 0.0f);
    b.add(cylinder(p, c + vec3{0, 0.006f, 0}, 0.02f, 0.008f, 0.002f), 2, 0.0f);
  }
  b.add(box(p, {0, 0.04f, 0.118f}, {0.176f, 0.036f, 0.006f}, 0.003f), 0, 0.002f);  // front panel
  b.cut(box(p, {0, 0.058f, 0.124f}, {0.05f, 0.008f, 0.006f}, 0.004f), 0.003f);     // finger pull
  return {b.d, b.region};
}

SdfSample snackSdf(vec3 p) {  // a bag of chips: puffy pillow, crimped ends
  SdfBuilder b;
  float puff = box(p, {0, 0.13f, 0}, {0.08f, 0.1f, 0.012f}, 0.012f) - 0.022f * (1.0f - std::pow(std::fabs(p.y - 0.13f) / 0.11f, 2.0f)) *
                                                                         (1.0f - std::pow(std::fabs(p.x) / 0.09f, 2.0f));
  b.add(puff + 0.0015f * std::sin(p.y * 90.0f + p.x * 40.0f), 0, 0);
  b.add(box(p, {0, 0.233f, 0}, {0.082f, 0.012f, 0.004f}, 0.002f) + 0.0015f * std::sin(p.x * 220.0f), 2, 0.005f);
  b.add(box(p, {0, 0.027f, 0}, {0.082f, 0.012f, 0.004f}, 0.002f) + 0.0015f * std::sin(p.x * 220.0f), 2, 0.005f);
  b.add(ellipsoid(p, {0, 0.14f, -0.03f}, {0.05f, 0.04f, 0.006f}), 1, 0.004f);  // label window
  return {b.d, b.region};
}

SdfSample bottleSdf(vec3 p) {  // 20 oz soda
  SdfBuilder b;
  float r = 0.034f;
  float y = p.y;
  float prof = y < 0.02f ? r * (0.85f + y * 7.0f) : (y < 0.15f ? r : (y < 0.2f ? r - (y - 0.15f) * 0.36f : 0.0135f));
  float body = std::max(std::sqrt(p.x * p.x + p.z * p.z) - prof, std::max(-p.y, p.y - 0.225f));
  b.add(body, 0, 0);
  b.add(cylinder(p, {0, 0.1f, 0}, r + 0.0015f, 0.035f, 0.0f), 1, 0.0f);   // label
  b.add(cylinder(p, {0, 0.235f, 0}, 0.0155f, 0.012f, 0.003f), 2, 0.0f);  // cap
  return {b.d, b.region};
}

SdfSample packSdf(vec3 p) {  // candy / cereal box
  SdfBuilder b;
  b.add(box(p, {0, 0.1f, 0}, {0.06f, 0.1f, 0.022f}, 0.003f), 0, 0);
  b.add(box(p, {0, 0.12f, -0.0225f}, {0.045f, 0.035f, 0.001f}, 0.001f), 1, 0.0f);
  b.add(box(p, {0, 0.05f, -0.0225f}, {0.05f, 0.012f, 0.001f}, 0.001f), 2, 0.0f);
  return {b.d, b.region};
}

// First-person arm. Hand at the origin pointing down -z, the forearm runs back toward the camera.
// Regions: 0 sleeve, 1 hand / glove, 2 cuff, 3 flashlight.
SdfSample fpArmSdf(vec3 p, bool light) {
  SdfBuilder b;
  b.add(cone(p, {0, -0.012f, 0.07f}, {0.01f, -0.05f, 0.46f}, 0.043f, 0.056f) + 0.002f * std::sin(p.z * 70.0f + p.x * 30.0f), 0, 0);
  b.add(cone(p, {0, -0.01f, 0.085f}, {0, -0.012f, 0.06f}, 0.047f, 0.046f), 2, 0.006f);
  b.add(ellipsoid(p, {0, 0, -0.005f}, {0.045f, 0.04f, 0.06f}), 1, 0.02f);              // fist
  for (int k = 0; k < 4; ++k)                                                          // knuckles
    b.add(sphere(p, {-0.03f + k * 0.02f, 0.03f, -0.035f}, 0.013f), 1, 0.008f);
  b.add(cone(p, {0.04f, 0.015f, 0.01f}, {0.018f, 0.04f, -0.045f}, 0.013f, 0.011f), 1, 0.008f);  // thumb
  if (light) {
    float rr = std::sqrt(p.x * p.x + p.y * p.y);
    float tube = std::max(rr - 0.016f + 0.0012f * (std::sin(p.z * 260.0f) > 0.6f ? 1.0f : 0.0f), std::fabs(p.z + 0.01f) - 0.1f);
    b.add(tube, 3, 0.002f);  // knurled grip
    float head = std::max(rr - (0.019f + std::max(0.0f, -(p.z + 0.11f)) * 0.22f), std::fabs(p.z + 0.14f) - 0.035f);
    b.add(head, 3, 0.004f);
    b.add(std::max(rr - 0.024f, std::fabs(p.z + 0.176f) - 0.004f), 2, 0.002f);  // bezel ring
  }
  return {b.d, b.region};
}
SdfSample fpArmLightSdf(vec3 p) { return fpArmSdf(p, true); }

// ---------------------------------------------------------------- new levels
// Playplace column: an hourglass of white plaster on a quilted blue cushion, flaring into the
// ceiling under a purple-blue metal rim. 3 m tall.
SdfSample hourglassSdf(vec3 p) {
  SdfBuilder b;
  float r = std::sqrt(p.x * p.x + p.z * p.z);
  float t = p.y - 1.45f;
  float prof = 0.5f + 0.2f * t * t + (p.y > 2.15f ? 0.62f * (p.y - 2.15f) * (p.y - 2.15f) : 0.0f);
  float body = std::max((r - prof) * 0.62f, std::max(-p.y, p.y - 2.84f));
  b.add(body, 0, 0);
  float ang = std::atan2(p.z, p.x);
  float quilt = 0.012f * std::fabs(std::sin(ang * 9.0f)) + 0.01f * std::fabs(std::sin(p.y * 10.0f));
  b.add(cylinder(p, {0, 0.32f, 0}, 1.0f, 0.32f, 0.07f) + quilt, 1, 0.03f);
  b.add(cylinder(p, {0, 2.9f, 0}, 1.28f, 0.1f, 0.04f), 2, 0.012f);   // rim, into the ceiling
  b.add(cylinder(p, {0, 2.74f, 0}, 1.22f, 0.035f, 0.015f), 2, 0.01f);
  return {b.d, b.region};
}

// A blue spiral tube slide coming down out of a round platform in the ceiling, on thin legs.
SdfSample spiralSdf(vec3 p) {
  SdfBuilder b;
  const float R = 0.95f, tube = 0.3f, y0 = 2.5f, y1 = 0.55f, turns = 1.55f;
  const int N = 26;
  vec3 prev{R, y0, 0};
  float best = 1e9f;
  for (int i = 1; i <= N; ++i) {
    float k = (float)i / N, a = turns * 6.2832f * k;
    vec3 cur{R * std::cos(a), y0 + (y1 - y0) * k, R * std::sin(a)};
    best = std::min(best, cone(p, prev, cur, tube, tube));
    prev = cur;
  }
  float ae = turns * 6.2832f;
  vec3 tan{-std::sin(ae), 0, std::cos(ae)};
  best = std::min(best, cone(p, prev, prev + tan * 0.75f + vec3{0, -0.12f, 0}, tube, tube * 0.96f));  // run-out
  b.add(best, 0, 0);
  b.add(cylinder(p, {R, 2.75f, 0}, 0.34f, 0.25f, 0.05f), 0, 0.06f);  // where it leaves the platform
  b.add(cylinder(p, {0, 2.93f, 0}, 1.6f, 0.05f, 0.012f), 2, 0);       // the platform
  b.add(cylinder(p, {0, 1.45f, 0}, 0.06f, 1.45f, 0.0f), 1, 0);        // centre post
  for (int k = 0; k < 3; ++k) {                                        // legs
    float a = 1.0f + k * 2.1f;
    vec3 base{R * std::cos(a), 0, R * std::sin(a)};
    b.add(cone(p, base, base + vec3{0, 1.2f, 0}, 0.025f, 0.025f), 1, 0);
  }
  return {b.d, b.region};
}

// The suburb house: two storeys of tan siding on a 6 x 6 m footprint, a mauve gable roof,
// dark windows, a front door (+z). Its base runs a metre underground for the hills.
// One of the houses out in the Suburbs, like the footage: a plain two-storey box, narrow gable
// end, steep roof with a little overhang, cream siding, and NO DOOR. Two windows per floor on every
// face, white frames with a cross in them, dark glass that catches the sky. Ridge runs along z.
SdfSample houseSdf(vec3 p) {
  SdfBuilder b;
  const float hw = 2.1f, hd = 2.7f, eave = 4.9f, ridge = 7.0f;
  float lap = 0.005f * std::fabs(std::sin(p.y * 6.2832f * 5.0f));  // lap siding
  b.add(box(p, {0, eave * 0.5f - 0.5f, 0}, {hw, eave * 0.5f + 0.5f, hd}, 0.015f) + lap, 0, 0);  // body, foundation sunk 1 m
  float roofTop = eave + (ridge - eave) * (1.0f - std::fabs(p.x) / (hw + 0.25f));
  float gable = std::max(std::max(std::fabs(p.x) - hw, std::fabs(p.z) - hd), std::max(p.y - (roofTop - 0.16f), eave - 0.1f - p.y));
  b.add(gable + lap, 0, 0);
  float slab = std::max(p.y - roofTop, roofTop - 0.2f - p.y) * 0.8f;
  float roof = std::max(std::max(slab, std::fabs(p.z) - (hd + 0.3f)), std::max(std::fabs(p.x) - (hw + 0.25f), eave - 0.15f - p.y));
  b.add(roof, 1, 0);
  // windows: recessed dark glass, a white frame proud of the wall, a cross (mullion + transom)
  auto window = [&](vec3 c, vec3 n, vec3 t) {
    const float ww = 0.4f, wh = 0.5f;
    vec3 q = p - c;
    float lt = q.x * t.x + q.z * t.z, ln = q.x * n.x + q.z * n.z, ly = q.y;
    float hole = std::max(std::max(std::fabs(lt) - ww, std::fabs(ly) - wh), std::fabs(ln + 0.02f) - 0.09f);
    b.cut(hole, 0.0f, 2);
    float frameOuter = std::max(std::max(std::fabs(lt) - (ww + 0.07f), std::fabs(ly) - (wh + 0.07f)), std::fabs(ln - 0.02f) - 0.035f);
    float frameInner = std::max(std::fabs(lt) - ww, std::fabs(ly) - wh);
    b.add(std::max(frameOuter, -frameInner), 3, 0);
    float bars = std::min(std::fabs(lt) - 0.025f, std::fabs(ly) - 0.025f);
    b.add(std::max(std::max(bars, std::max(std::fabs(lt) - ww, std::fabs(ly) - wh)), std::fabs(ln + 0.03f) - 0.025f), 3, 0);
    b.add(std::max(std::max(std::fabs(lt) - (ww + 0.1f), std::fabs(ly + wh + 0.07f) - 0.035f), std::fabs(ln - 0.04f) - 0.06f), 3, 0);  // sill
  };
  for (int fl = 0; fl < 2; ++fl) {
    float wy = 1.35f + fl * 2.45f;
    for (int s = -1; s <= 1; s += 2) {
      for (int k = -1; k <= 1; k += 2) {
        window({k * 0.85f, wy, s * hd}, {0, 0, (float)s}, {1, 0, 0});         // gable ends
        window({s * hw, wy, k * 1.2f}, {(float)s, 0, 0}, {0, 0, 1});          // long sides
      }
    }
  }
  return {b.d, b.region};
}

// Office doorway, one side: a strip of wall that narrows a full-width opening to a door,
// with the white casing on its edge and the wall above the door. Origin = centre of the strip.
SdfSample doorSideSdf(vec3 p) {
  SdfBuilder b;
  const float h = 2.8f;
  b.add(box(p, {0, h * 0.5f, 0}, {0.21f, h * 0.5f, 0.08f}, 0.0f), 0, 0);              // infill
  b.add(box(p, {-0.46f, (2.1f + h) * 0.5f, 0}, {0.26f, (h - 2.1f) * 0.5f, 0.08f}, 0.0f), 0, 0);  // over the door
  b.add(box(p, {-0.23f, 1.05f, 0}, {0.035f, 1.07f, 0.1f}, 0.006f), 1, 0);             // casing
  b.add(box(p, {-0.46f, 2.12f, 0}, {0.27f, 0.035f, 0.1f}, 0.006f), 1, 0);
  return {b.d, b.region};
}

// An emptied-out bookstore gondola: two faces of bare wooden shelves back to back, end panels, a kick base.
SdfSample bookcaseSdf(vec3 p) {
  SdfBuilder b;
  vec3 a{p.x, p.y, std::fabs(p.z)};
  b.add(box(p, {0, 0.05f, 0}, {0.9f, 0.05f, 0.3f}, 0.004f), 1, 0);                 // kick base
  b.add(box(p, {0, 0.95f, 0}, {0.88f, 0.9f, 0.012f}, 0.002f), 0, 0);               // back spine
  for (int k = 0; k < 6; ++k) b.add(box(a, {0, 0.1f + k * 0.34f, 0.15f}, {0.885f, 0.012f, 0.15f}, 0.003f), 0, 0);  // shelves
  for (int s = -1; s <= 1; s += 2) b.add(box(p, {s * 0.9f, 0.93f, 0}, {0.018f, 0.93f, 0.31f}, 0.004f), 1, 0);      // ends
  b.add(box(p, {0, 1.86f, 0}, {0.92f, 0.012f, 0.32f}, 0.003f), 1, 0);              // top
  b.add(box(a, {0, 0.95f, 0.15f}, {0.012f, 0.9f, 0.15f}, 0.002f), 0, 0);            // middle divider
  return {b.d, b.region};
}

// One bed of a trampoline court, a 2 x 2 m tile: black jumping mat, blue foam pads over the frame
// and springs on all four sides, yellow caps on the corners. `gap`: the back pad has come away from
// the wall, leaving a dark slot between it and the wall you could slip down.
SdfSample trampSdfG(vec3 p, bool gap) {
  SdfBuilder b;
  float zn = gap ? -0.45f : -0.84f;  // the back (north, -z) pad
  float bedZ0 = gap ? -0.29f : -0.68f;
  (void)bedZ0;  // the bed itself is drawn live (game_park.cpp drawBeds) so it can give under people
  b.add(box(p, {0, 0.075f, 0.84f}, {1.0f, 0.075f, 0.16f}, 0.04f), 0, 0);
  b.add(box(p, {0, 0.075f, zn}, {1.0f, 0.075f, 0.16f}, 0.04f), 0, 0);
  for (int s = -1; s <= 1; s += 2) b.add(box(p, {s * 0.84f, 0.075f, gap ? 0.2f : 0.0f}, {0.16f, 0.075f, gap ? 0.8f : 1.0f}, 0.04f), 0, 0);
  for (int sx = -1; sx <= 1; sx += 2)
    for (int sz = -1; sz <= 1; sz += 2) b.add(cylinder(p, {sx * 0.84f, 0.08f, sz > 0 ? 0.84f : zn}, 0.11f, 0.08f, 0.02f), 2, 0.01f);
  return {b.d, b.region};
}
SdfSample trampSdf(vec3 p) { return trampSdfG(p, false); }
SdfSample trampGapSdf(vec3 p) { return trampSdfG(p, true); }

// A door in a wall that doesn't go anywhere: casing, a six-panel door, a brass knob.
// The wall is at +z; it stands a few centimetres proud of it, facing -z.
SdfSample wallDoorSdf(vec3 p) {
  SdfBuilder b;
  const float w = 0.46f, h = 2.05f;
  b.add(box(p, {0, h * 0.5f, 0.0f}, {w, h * 0.5f, 0.02f}, 0.002f), 1, 0);                       // the door
  for (int r = 0; r < 3; ++r)                                                                   // its panels
    for (int c = -1; c <= 1; c += 2) {
      float y0 = r == 0 ? 0.18f : (r == 1 ? 0.95f : 1.45f), y1 = r == 0 ? 0.85f : (r == 1 ? 1.35f : 1.9f);
      b.cut(box(p, {c * 0.2f, (y0 + y1) * 0.5f, -0.024f}, {0.15f, (y1 - y0) * 0.5f, 0.008f}, 0.003f), 0.004f);
    }
  b.add(box(p, {-(w + 0.035f), (h + 0.04f) * 0.5f, -0.012f}, {0.035f, (h + 0.04f) * 0.5f, 0.032f}, 0.004f), 0, 0);  // casing
  b.add(box(p, {(w + 0.035f), (h + 0.04f) * 0.5f, -0.012f}, {0.035f, (h + 0.04f) * 0.5f, 0.032f}, 0.004f), 0, 0);
  b.add(box(p, {0, h + 0.055f, -0.012f}, {w + 0.07f, 0.035f, 0.032f}, 0.004f), 0, 0);
  b.add(cylinder(p, {0.36f, 1.0f, -0.035f}, 0.03f, 0.004f, 0.002f) , 2, 0);                     // rose
  b.add(sphere(p, {0.36f, 1.0f, -0.07f}, 0.028f), 2, 0.012f);                                  // knob
  b.add(box(p, {0.36f, 1.0f, -0.05f}, {0.008f, 0.008f, 0.02f}, 0.002f), 2, 0.006f);
  return {b.d, b.region};
}

// An old wooden staircase, carved newels and turned spindles, climbing toward -z: 16 steps,
// 3.4 m up over 3.6 m, up into the dark through a hole in the ceiling. Origin: middle of its run.
SdfSample stairsSdf(vec3 p) {
  SdfBuilder b;
  const int N = 16;
  const float rise = 0.21f, tread = 0.225f, z0 = 1.8f, hw = 0.56f;
  int k = (int)std::floor((z0 - p.z) / tread);
  for (int i = k - 1; i <= k + 1; ++i) {
    if (i < 0 || i >= N) continue;
    float zc = z0 - (i + 0.5f) * tread, top = (i + 1) * rise;
    b.add(box(p, {0, top * 0.5f, zc}, {hw, top * 0.5f, tread * 0.5f}, 0.0f), 0, 0);            // the step, closed underneath
    b.add(box(p, {0, top - 0.012f, zc + 0.012f}, {hw - 0.02f, 0.014f, tread * 0.5f + 0.02f}, 0.006f), 1, 0);  // tread with a nosing
    for (int s = -1; s <= 1; s += 2) {                                                          // turned spindles
      vec3 q{p.x - s * (hw - 0.06f), p.y - top, p.z - zc};
      float r = 0.02f + 0.012f * std::max(0.0f, std::sin(q.y * 9.0f)) + 0.01f * std::exp(-std::pow((q.y - 0.18f) * 18.0f, 2.0f));
      b.add(std::max(std::sqrt(q.x * q.x + q.z * q.z) - r, std::fabs(q.y - 0.45f) - 0.45f), 2, 0);
    }
  }
  for (int s = -1; s <= 1; s += 2) {
    float x = s * (hw - 0.06f);
    b.add(cone(p, {x, 1.05f, z0 + 0.05f}, {x, N * rise + 0.9f, z0 - N * tread}, 0.035f, 0.035f), 2, 0.01f);  // handrail
    // the stringer along the side, following the slope
    {
      vec3 q{p.x - s * (hw + 0.02f), p.y, p.z};
      float along = (z0 - q.z) / (N * tread), yline = along * N * rise;
      float d = std::max(std::max(std::fabs(q.x) - 0.03f, std::fabs(q.y - (yline - 0.05f)) - 0.17f), std::max(q.z - z0, -(q.z + (N * tread - z0))));
      b.add(d, 0, 0);
    }
    // carved newel post at the bottom: square shaft, collars, a big ball finial
    vec3 c{x, 0, z0 + 0.04f};
    b.add(box(p, c + vec3{0, 0.55f, 0}, {0.075f, 0.55f, 0.075f}, 0.008f), 2, 0);
    b.add(box(p, c + vec3{0, 0.12f, 0}, {0.095f, 0.12f, 0.095f}, 0.01f), 2, 0.01f);
    b.add(box(p, c + vec3{0, 1.1f, 0}, {0.1f, 0.035f, 0.1f}, 0.01f), 2, 0.01f);
    b.add(sphere(p, c + vec3{0, 1.24f, 0}, 0.085f) + 0.006f * std::sin(p.x * 120.0f) * std::sin(p.y * 120.0f), 2, 0.02f);
    b.add(sphere(p, c + vec3{0, 0.7f, 0}, 0.1f), 2, 0.03f);
  }
  return {b.d, b.region};
}

// The door itself, swung open 90 degrees. Origin = the hinge, door runs along +z.
SdfSample doorLeafSdf(vec3 p) {
  SdfBuilder b;
  b.add(box(p, {0, 1.03f, 0.45f}, {0.022f, 1.02f, 0.45f}, 0.004f), 0, 0);
  b.add(sphere(p, {0.05f, 1.0f, 0.82f}, 0.03f), 1, 0.01f);
  b.add(sphere(p, {-0.05f, 1.0f, 0.82f}, 0.03f), 1, 0.01f);
  return {b.d, b.region};
}

// An open right hand reaching out, palm down: sleeve and cuff, a palm, four jointed fingers
// curling a little at each knuckle (with nails), and a thumb. Fingers point down -z.
SdfSample reachHandSdf(vec3 p) {
  SdfBuilder b;
  b.add(cone(p, {0, 0.004f, 0.07f}, {0.006f, 0.012f, 0.5f}, 0.041f, 0.054f) + 0.0018f * std::sin(p.z * 70.0f + p.x * 30.0f), 0, 0);
  b.add(cone(p, {0, 0.002f, 0.05f}, {0, 0.003f, 0.082f}, 0.044f, 0.045f), 2, 0.004f);  // cuff
  b.add(cone(p, {0, 0.0f, 0.055f}, {0, -0.002f, -0.012f}, 0.025f, 0.028f), 1, 0.012f);  // wrist
  b.add(box(p, {0.002f, -0.004f, -0.05f}, {0.038f, 0.0115f, 0.044f}, 0.011f), 1, 0.014f);  // palm
  b.add(ellipsoid(p, {-0.024f, -0.012f, -0.035f}, {0.016f, 0.012f, 0.028f}), 1, 0.012f);   // thenar pad
  const vec3 down{0, -1, 0};
  for (int k = 0; k < 4; ++k) {  // index .. pinky, left to right
    static const float lens[4] = {0.95f, 1.0f, 0.94f, 0.76f};
    static const float rads[4] = {0.0092f, 0.0096f, 0.009f, 0.0078f};
    float x = -0.027f + k * 0.0185f;
    float spread = (k - 1.4f) * 0.1f;
    vec3 fwd{std::sin(spread), 0, -std::cos(spread)};
    float L = lens[k], r = rads[k];
    vec3 a{x, -0.003f, -0.088f + (k == 3 ? 0.008f : 0.0f)};
    auto dirAt = [&](float ang) { return normalize(fwd * std::cos(ang) + down * std::sin(ang)); };
    vec3 j1 = a + dirAt(0.12f + k * 0.03f) * (0.043f * L);
    vec3 j2 = j1 + dirAt(0.42f + k * 0.04f) * (0.027f * L);
    vec3 d3 = dirAt(0.72f + k * 0.04f);
    vec3 tip = j2 + d3 * (0.021f * L);
    b.add(sphere(p, a + vec3{0, 0.006f, 0}, r * 1.08f), 1, 0.006f);  // knuckle
    b.add(cone(p, a, j1, r, r * 0.93f), 1, 0.005f);
    b.add(cone(p, j1, j2, r * 0.93f, r * 0.85f), 1, 0.003f);
    b.add(cone(p, j2, tip, r * 0.85f, r * 0.74f), 1, 0.0025f);
    vec3 up = normalize(cross(cross(d3, vec3{0, 1, 0}), d3)) * -1.0f;
    b.add(ellipsoid(p, tip - d3 * 0.0065f + up * (r * 0.62f), {r * 0.62f, r * 0.22f, r * 0.75f}), 3, 0.0015f);  // nail
  }
  vec3 t0{-0.036f, -0.012f, -0.022f}, t1{-0.058f, -0.024f, -0.054f}, t2{-0.066f, -0.032f, -0.08f};  // thumb
  b.add(cone(p, t0, t1, 0.0128f, 0.0108f), 1, 0.012f);
  b.add(cone(p, t1, t2, 0.0108f, 0.0088f), 1, 0.004f);
  return {b.d, b.region};
}
SdfSample fpHandSdf(vec3 p) { return fpArmSdf(p, false); }

// A party table you can get under: a top, four legs, a paper tablecloth hanging off the front
// and sides, a cake and paper plates on top. Model space: front (-z) is the open side.
SdfSample deskSdf(vec3 p) {
  SdfBuilder b;
  b.add(box(p, {0, 0.74f, 0}, {0.62f, 0.025f, 0.38f}, 0.008f), 0, 0);
  for (int sx = -1; sx <= 1; sx += 2)
    for (int sz = -1; sz <= 1; sz += 2) b.add(cylinder(p, {sx * 0.56f, 0.36f, sz * 0.32f}, 0.022f, 0.36f), 1, 0.004f);
  // tablecloth draping over the back and sides, scalloped hem
  float hem = 0.5f + 0.03f * std::sin(p.x * 30.0f) + 0.03f * std::sin(p.z * 30.0f);
  float cloth = std::max(std::fabs(box(p, {0, 0.64f, 0.05f}, {0.64f, 0.13f, 0.4f}, 0.01f)) - 0.011f, hem - p.y);
  cloth = std::max(cloth, -(p.z + 0.3f));  // open at the front so you can crawl under
  b.add(cloth, 2, 0.004f);
  // cake: two tiers, candles
  b.add(cylinder(p, {0.15f, 0.83f, 0.05f}, 0.13f, 0.065f, 0.01f), 3, 0.004f);
  b.add(cylinder(p, {0.15f, 0.93f, 0.05f}, 0.085f, 0.04f, 0.008f), 3, 0.004f);
  for (int k = 0; k < 5; ++k) {
    float a = k * 1.2566f;
    b.add(cylinder(p, {0.15f + std::cos(a) * 0.05f, 1.0f, 0.05f + std::sin(a) * 0.05f}, 0.005f, 0.03f), 2, 0.0f);
  }
  for (int k = 0; k < 3; ++k) b.add(cylinder(p, {-0.35f + k * 0.18f, 0.77f, -0.15f + (k % 2) * 0.2f}, 0.08f, 0.004f), 1, 0.0f);  // plates
  return {b.d, b.region};
}

// A balloon arch for a doorway, 2 m wide: balloons in four colours packed along an arch, with a
// foil banner hanging across the top.
SdfSample archSdf(vec3 p) {
  SdfBuilder b;
  const int N = 46;
  for (int i = 0; i < N; ++i) {
    float t = (float)i / (N - 1);
    float a = t * kPi;
    vec3 c{std::cos(a) * -0.86f, 0.05f + std::sin(a) * 2.05f, 0};
    for (int k = 0; k < 3; ++k) {
      float h = hashf(i, k, 7);
      vec3 o{(hashf(i, k, 3) - 0.5f) * 0.18f, (hashf(i, k, 5) - 0.5f) * 0.14f, (k - 1) * 0.1f};
      float r = 0.085f + h * 0.05f;
      b.add(ellipsoid(p, c + o, {r, r * 1.15f, r}), (int)(hashf(i, k, 11) * 3.99f) == 3 ? 3 : (int)(hashf(i, k, 11) * 3.0f), 0.0f);
    }
  }
  // the banner: a sagging foil strip with bumps for letters
  float sag = 1.62f - 0.12f * (1.0f - (p.x * p.x) / 0.49f);
  float banner = box(p, {0, sag, 0}, {0.62f, 0.09f, 0.008f}, 0.004f) - 0.008f * std::max(0.0f, std::sin(p.x * 26.0f));
  b.add(banner, 3, 0.002f);
  return {b.d, b.region};
}

// ------------------------------------------------------------------ meshing

float segDist(vec3 p, vec3 a, vec3 b) {
  vec3 pa = p - a, ba = b - a;
  float h = clampf(dot(pa, ba) / std::max(dot(ba, ba), 1e-8f), 0, 1);
  return length(pa - ba * h);
}

using BoneMask = bool (*)(int bone, vec3 p);
// People: an arm bone only moves the arm on its own side, a leg bone only the leg below the hips,
// and the torso doesn't take the hands. (Nearest-bone weights let the shoulders drag the ribs and
// the chest drag the upper arms, which is what made Ray's arm fold in on itself at the breaker.)
bool humanMask(int b, vec3 p) {
  float ax = std::fabs(p.x);
  if (b >= 6 && b <= 11) {  // arms: 6-8 right (+x), 9-11 left (-x)
    bool right = b <= 8;
    if ((right && p.x < 0.12f) || (!right && p.x > -0.12f)) return false;
    // only what's clear of the body: the shoulder cap up top, the arm itself lower down.
    // (The jacket hem next to a hanging hand used to follow the hand up to the breaker.)
    return (p.y > 1.3f && ax > 0.15f) || (p.y > 1.12f && ax > 0.172f) || ax > 0.2f;
  }
  if (b >= 12) {  // legs: 12-14 right, 15-17 left
    bool right = b <= 14;
    if (p.y > 1.0f) return false;
    if ((right && p.x < -0.02f) || (!right && p.x > 0.02f)) return false;
    return true;
  }
  if (b <= 2) return !(ax > 0.235f && p.y < 1.3f);  // pelvis/spine/chest: not the hanging arms
  return true;
}

// Partygoers: the arms are separate tubes beside a wide body; only the tubes follow the arm bones.
bool partyMask(int b, vec3 p) {
  float rBody = 0.31f - 0.11f * clampf(p.y / 1.53f, 0.0f, 1.0f) + 0.012f;
  bool outside = std::sqrt(p.x * p.x + p.z * p.z) > rBody && p.y > 0.66f && p.y < 1.62f;
  if (b >= 3) {
    bool right = b <= 4;
    return outside && (right ? p.x > 0.1f : p.x < -0.1f);
  }
  return !outside;
}

void (*gProgFn)(float, void*) = nullptr;
void* gProgUser = nullptr;
int gSculpted = 0;
constexpr int kSculptTotal = 45;  // roughly how many models build() makes; only drives the loading bar

void finish(Model& m, const SdfFn& f, vec3 bmin, vec3 bmax, float cell, const std::vector<Bone>& bones, BoneMask mask = nullptr) {
  SdfMesh s = surfaceNets(f, bmin, bmax, cell);
  m.bones = bones;
  m.skinned = !bones.empty();
  Mesh mesh;
  mesh.stride = 14;
  mesh.v.reserve(s.pos.size() * 14);
  size_t badNormals = 0;
  for (size_t i = 0; i < s.pos.size(); ++i) {
    vec3 p = s.pos[i], n = s.nrm[i];
    float nl = std::sqrt(n.x * n.x + n.y * n.y + n.z * n.z);
    if (!std::isfinite(nl) || nl < 1e-6f) { n = {0, 1, 0}; ++badNormals; }  // a NaN normal blacks out SSAO in big boxes
    else n = n * (1.0f / nl);
    float ao = std::isfinite(s.ao[i]) ? s.ao[i] : 1.0f;
    int b0 = 0, b1 = 0;
    float w0 = 1, w1 = 0;
    if (m.skinned) {
      float d0 = 1e9f, d1 = 1e9f;
      for (size_t k = 0; k < bones.size(); ++k) {
        if (mask && !mask((int)k, p)) continue;
        float d = segDist(p, bones[k].head, bones[k].tail);
        if (d < d0) { d1 = d0; b1 = b0; d0 = d; b0 = (int)k; }
        else if (d < d1) { d1 = d; b1 = (int)k; }
      }
      // Smooth falloff so joints bend instead of shearing.
      float e0 = 1.0f, e1 = std::exp(-(d1 - d0) / (mask ? 0.035f : 0.025f));
      w0 = e0 / (e0 + e1);
      w1 = e1 / (e0 + e1);
    }
    mesh.v.insert(mesh.v.end(), {p.x, p.y, p.z, n.x, n.y, n.z, p.x, p.y, ao, (float)s.region[i],
                                 (float)b0, (float)b1, w0, w1});
  }
  // Drop broken triangles: NaN vertices, vertices outside the sculpt bounds, or
  // slivers spanning many cells (they show up as huge dark sheets at some angles).
  auto bad = [&](uint32_t i) {
    vec3 p = s.pos[i];
    if (!(std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z))) return true;
    float pad = cell * 2.0f;
    return p.x < bmin.x - pad || p.y < bmin.y - pad || p.z < bmin.z - pad || p.x > bmax.x + pad || p.y > bmax.y + pad || p.z > bmax.z + pad;
  };
  float maxEdge2 = (cell * 6.0f) * (cell * 6.0f);
  size_t dropped = 0;
  mesh.idx.reserve(s.idx.size());
  for (size_t t = 0; t + 2 < s.idx.size(); t += 3) {
    uint32_t a = s.idx[t], b = s.idx[t + 1], c = s.idx[t + 2];
    vec3 pa = s.pos[a], pb = s.pos[b], pc = s.pos[c];
    vec3 e1 = pb - pa, e2 = pc - pb, e3 = pa - pc;
    if (bad(a) || bad(b) || bad(c) || dot(e1, e1) > maxEdge2 || dot(e2, e2) > maxEdge2 || dot(e3, e3) > maxEdge2) { ++dropped; continue; }
    mesh.idx.insert(mesh.idx.end(), {a, b, c});
  }
  if (dropped || badNormals) std::fprintf(stderr, "[br9] sculpt (%.2f x %.2f x %.2f m): fixed %zu bad normals, dropped %zu broken triangles\n", bmax.x - bmin.x, bmax.y - bmin.y, bmax.z - bmin.z, badNormals, dropped);
  m.mesh.upload(mesh);
  m.triangles = (int)(mesh.idx.size() / 3);
  ++gSculpted;
  if (gProgFn) gProgFn(std::min(0.98f, gSculpted / (float)kSculptTotal), gProgUser);
}

mat4 euler(float x, float y, float z) { return rotY(y) * rotX(x) * rotZ(z); }

}  // namespace

namespace creatures {

Model& creature(CreatureId id) { return gCreatures[id]; }
void setProgress(void (*fn)(float, void*), void* user) { gProgFn = fn; gProgUser = user; gSculpted = 0; }
Model& prop(PropId id) { return gProps[id]; }

bool build(float quality) {
  float k = 1.0f / clampf(quality, 0.5f, 1.5f);
  Uint32 t0 = SDL_GetTicks();

  Model& t = gCreatures[CR_TENANT];
  finish(t, tenantSdf, {-0.42f, -0.01f, -0.36f}, {0.42f, 2.75f, 0.24f}, 0.0105f * k, tenantBones());
  t.region[SKIN] = {0.055f, 0.047f, 0.042f, 0};
  t.region[EYE] = {0.004f, 0.004f, 0.004f, 0};
  t.region[BONE] = {0.32f, 0.28f, 0.22f, 0};
  t.region[GLOW] = {0.2f, 0.03f, 0.025f, 0};  // a Route 9 Park staff polo, mostly blood now
  t.spec[SKIN] = 0.22f; t.spec[EYE] = 1.6f; t.spec[BONE] = 0.4f; t.spec[GLOW] = 0.1f;

  Model& h = gCreatures[CR_HOUND];
  finish(h, houndSdf, {-0.4f, -0.01f, -0.98f}, {0.4f, 1.08f, 0.62f}, 0.0095f * k, houndBones());
  h.region[SKIN] = {0.34f, 0.31f, 0.29f, 0};
  h.region[EYE] = {0.1f, 0.05f, 0.05f, 0};
  h.region[BONE] = {0.55f, 0.5f, 0.38f, 0};
  h.region[GLOW] = {0.1f, 0.12f, 0.17f, 0};  // denim
  h.spec[SKIN] = 0.45f; h.spec[BONE] = 0.7f; h.spec[GLOW] = 0.1f;

  Model& g = gCreatures[CR_GRIN];
  finish(g, grinSdf, {-0.62f, 0.15f, -0.5f}, {0.62f, 2.5f, 0.5f}, 0.014f * k, grinBones());
  g.region[SKIN] = {0.006f, 0.006f, 0.007f, 0};
  g.region[GLOW] = {0.95f, 0.95f, 0.9f, 6.0f};
  g.spec[SKIN] = 0.05f;

  std::vector<Bone> none;
  finish(gProps[PR_CHAIR], chairSdf, {-0.38f, -0.01f, -0.38f}, {0.38f, 1.12f, 0.36f}, 0.012f * k, none);
  gProps[PR_CHAIR].region[SKIN] = {0.035f, 0.035f, 0.04f, 0};
  gProps[PR_CHAIR].region[EYE] = {0.25f, 0.25f, 0.27f, 0};
  gProps[PR_CHAIR].spec[EYE] = 1.0f;
  finish(gProps[PR_BOX], boxSdf, {-0.28f, -0.01f, -0.24f}, {0.28f, 0.48f, 0.26f}, 0.012f * k, none);
  gProps[PR_BOX].region[SKIN] = {0.42f, 0.3f, 0.17f, 0};
  gProps[PR_BOX].region[BONE] = {0.5f, 0.45f, 0.35f, 0};
  gProps[PR_BOX].spec[BONE] = 0.8f;
  finish(gProps[PR_BAG], bagSdf, {-1.2f, -0.01f, -0.45f}, {0.95f, 0.26f, 0.45f}, 0.014f * k, none);
  gProps[PR_BAG].region[SKIN] = {0.06f, 0.11f, 0.07f, 0};
  gProps[PR_BAG].region[EYE] = {0.3f, 0.28f, 0.24f, 0};
  gProps[PR_BAG].spec[SKIN] = 0.35f;
  finish(gProps[PR_LANTERN], lanternSdf, {-0.08f, -0.01f, -0.08f}, {0.08f, 0.33f, 0.08f}, 0.005f * k, none);
  gProps[PR_LANTERN].region[SKIN] = {0.12f, 0.2f, 0.12f, 0};
  gProps[PR_LANTERN].region[GLOW] = {0.6f, 0.58f, 0.5f, 0};
  gProps[PR_LANTERN].region[BONE] = {0.3f, 0.3f, 0.3f, 0};
  gProps[PR_LANTERN].spec[GLOW] = 1.5f;
  finish(gProps[PR_CAN], canSdf, {-0.04f, -0.01f, -0.04f}, {0.04f, 0.13f, 0.04f}, 0.004f * k, none);
  gProps[PR_CAN].region[SKIN] = {0.5f, 0.5f, 0.52f, 0};
  gProps[PR_CAN].region[EYE] = {0.45f, 0.08f, 0.06f, 0};
  gProps[PR_CAN].spec[SKIN] = 1.5f;
  finish(gProps[PR_COOLER], coolerSdf, {-0.19f, -0.01f, -0.19f}, {0.19f, 1.42f, 0.19f}, 0.012f * k, none);
  gProps[PR_COOLER].region[SKIN] = {0.6f, 0.58f, 0.52f, 0};
  gProps[PR_COOLER].region[GLOW] = {0.25f, 0.4f, 0.55f, 0};
  gProps[PR_COOLER].region[EYE] = {0.1f, 0.1f, 0.12f, 0};
  gProps[PR_COOLER].spec[GLOW] = 1.8f;

  Model& st = gCreatures[CR_STILT];
  finish(st, stiltSdf, {-0.32f, -0.01f, -0.34f}, {0.32f, 2.52f, 0.14f}, 0.0065f * k, stiltBones());
  st.region[SKIN] = {0.035f, 0.03f, 0.026f, 0};
  st.region[EYE] = {0.01f, 0.01f, 0.01f, 0};
  st.region[BONE] = {0.09f, 0.075f, 0.06f, 0};
  st.region[GLOW] = {0.9f, 0.86f, 0.72f, 1.6f};
  st.spec[SKIN] = 0.5f; st.spec[GLOW] = 2.0f;

  Model& pg = gCreatures[CR_PARTYGOER];
  finish(pg, partySdf, {-0.44f, -0.01f, -0.36f}, {0.44f, 2.16f, 0.36f}, 0.009f * k, partyBones(), partyMask);
  pg.region[SKIN] = {0.8f, 0.5f, 0.03f, 0};
  pg.region[EYE] = {0.55f, 0.06f, 0.05f, 0};
  pg.region[BONE] = {0.5f, 0.2f, 0.07f, 0};
  pg.region[GLOW] = {0, 0, 0, 0};
  pg.spec[SKIN] = 0.15f; pg.spec[EYE] = 0.5f;

  // People: four outfits on one skeleton.
  struct HumanDef { CreatureId id; SdfFn f; vec4 r[8]; float sp[8]; float hi; };
  const HumanDef defs[] = {
      {CR_HUMAN, humanSdf,
       {{0.62f, 0.45f, 0.36f, 0}, {0.06f, 0.04f, 0.03f, 0}, {0.2f, 0.25f, 0.4f, 0}, {0.1f, 0.13f, 0.25f, 0},
        {0.8f, 0.8f, 0.78f, 0}, {0.8f, 0.8f, 0.78f, 0}, {0.18f, 0.1f, 0.05f, 0}, {0.85f, 0.84f, 0.8f, 0}},
       {0.3f, 0.35f, 0.1f, 0.1f, 0.3f, 0.2f, 0.6f, 0.9f}, 1.86f},
      {CR_SUIT, suitSdf,
       {{0.62f, 0.45f, 0.36f, 0}, {0.05f, 0.04f, 0.03f, 0}, {0.07f, 0.075f, 0.09f, 0}, {0.07f, 0.075f, 0.09f, 0},
        {0.02f, 0.018f, 0.016f, 0}, {0.82f, 0.82f, 0.8f, 0}, {0.36f, 0.05f, 0.06f, 0}, {0.85f, 0.84f, 0.8f, 0}},
       {0.3f, 0.45f, 0.25f, 0.25f, 1.6f, 0.3f, 0.7f, 0.9f}, 1.86f},
      {CR_WORKER, workerSdf,
       {{0.62f, 0.45f, 0.36f, 0}, {0.3f, 0.29f, 0.27f, 0}, {0.12f, 0.22f, 0.42f, 0}, {0.1f, 0.18f, 0.33f, 0},
        {0.22f, 0.13f, 0.07f, 0}, {0.82f, 0.78f, 0.66f, 0}, {0.07f, 0.08f, 0.1f, 0}, {0.6f, 0.6f, 0.58f, 0}},
       {0.3f, 0.3f, 0.12f, 0.1f, 0.4f, 0.1f, 0.3f, 1.4f}, 1.86f},
      {CR_HAZMAT, hazmatSdf,
       {{0.6f, 0.45f, 0.35f, 0}, {0.008f, 0.008f, 0.01f, 0}, {0.86f, 0.74f, 0.14f, 0}, {0.86f, 0.74f, 0.14f, 0},
        {0.88f, 0.36f, 0.06f, 0}, {0.015f, 0.015f, 0.015f, 0}, {0.012f, 0.012f, 0.012f, 0}, {0.72f, 0.07f, 0.04f, 0}},
       {0.2f, 2.2f, 0.65f, 0.65f, 0.5f, 0.3f, 0.7f, 0.8f}, 1.9f},
  };
  for (const HumanDef& d : defs) {
    Model& hm = gCreatures[d.id];
    finish(hm, d.f, {-0.36f, -0.01f, -0.24f}, {0.36f, d.hi, 0.26f}, 0.0072f * k, humanBones(), humanMask);
    for (int r = 0; r < 8; ++r) { hm.region[r] = d.r[r]; hm.spec[r] = d.sp[r]; }
  }

  auto fixture = [&](PropId id, SdfFn f, vec3 lo, vec3 hi, float cell, vec4 r0, vec4 r1, vec4 r2, vec4 r3) {
    finish(gProps[id], f, lo, hi, cell * k, none);
    gProps[id].region[0] = r0; gProps[id].region[1] = r1; gProps[id].region[2] = r2; gProps[id].region[3] = r3;
  };
  fixture(PR_SHELF, shelfSdf, {-1.05f, -0.01f, -0.48f}, {1.05f, 1.66f, 0.48f}, 0.012f,
          {0.7f, 0.2f, 0.15f, 0}, {0.75f, 0.74f, 0.7f, 0}, {0.85f, 0.65f, 0.1f, 0}, {0.15f, 0.35f, 0.6f, 0});
  gProps[PR_SHELF].spec[1] = 0.8f;
  fixture(PR_COUNTER, counterSdf, {-1.06f, -0.01f, -0.42f}, {1.06f, 1.3f, 0.42f}, 0.01f,
          {0.42f, 0.28f, 0.16f, 0}, {0.08f, 0.08f, 0.09f, 0}, {0.75f, 0.72f, 0.66f, 0}, {0.3f, 0.8f, 0.5f, 2.5f});
  fixture(PR_FREEZER, freezerSdf, {-0.54f, -0.01f, -0.4f}, {0.54f, 2.04f, 0.47f}, 0.012f,
          {0.78f, 0.78f, 0.8f, 0}, {0.25f, 0.25f, 0.27f, 0}, {0.6f, 0.6f, 0.6f, 0}, {0.55f, 0.75f, 0.85f, 1.4f});
  gProps[PR_FREEZER].spec[3] = 1.8f;
  fixture(PR_PANEL, panelSdf, {-0.3f, 1.0f, -0.1f}, {0.3f, 2.62f, 0.08f}, 0.008f,
          {0.42f, 0.43f, 0.42f, 0}, {0.2f, 0.2f, 0.2f, 0}, {0.1f, 0.1f, 0.1f, 0}, {0.9f, 0.15f, 0.1f, 3.0f});
  fixture(PR_BOILER, boilerSdf, {-0.44f, -0.01f, -0.44f}, {0.44f, 2.32f, 0.44f}, 0.012f,
          {0.25f, 0.14f, 0.08f, 0}, {0.15f, 0.15f, 0.15f, 0}, {0.6f, 0.58f, 0.5f, 0}, {0, 0, 0, 0});
  fixture(PR_LOCKER, lockerSdf, {-0.3f, -0.01f, -0.3f}, {0.3f, 1.92f, 0.3f}, 0.009f,
          {0.22f, 0.3f, 0.26f, 0}, {0, 0, 0, 0}, {0.6f, 0.6f, 0.6f, 0}, {0, 0, 0, 0});
  gProps[PR_LOCKER].spec[0] = 0.8f;
  fixture(PR_CART, cartSdf, {-0.3f, -0.01f, -0.48f}, {0.3f, 0.95f, 0.5f}, 0.008f,
          {0.6f, 0.6f, 0.62f, 0}, {0.05f, 0.05f, 0.05f, 0}, {0.7f, 0.1f, 0.08f, 0}, {0, 0, 0, 0});
  gProps[PR_CART].spec[0] = 1.4f;
  fixture(PR_COUCH, couchSdf, {-1.1f, -0.01f, -0.5f}, {1.1f, 1.06f, 0.5f}, 0.012f,
          {0.24f, 0.27f, 0.22f, 0}, {0.45f, 0.28f, 0.18f, 0}, {0.12f, 0.07f, 0.04f, 0}, {0, 0, 0, 0});
  fixture(PR_TVSET, tvSdf, {-0.62f, -0.01f, -0.26f}, {0.62f, 1.0f, 0.34f}, 0.008f,
          {0.9f, 0.2f, 0.1f, 1.5f}, {0.07f, 0.07f, 0.075f, 0}, {0.18f, 0.12f, 0.08f, 0}, {0.02f, 0.025f, 0.03f, 0});
  gProps[PR_TVSET].spec[3] = 1.6f;
  fixture(PR_TABLE, tableSdf, {-0.58f, -0.01f, -0.33f}, {0.58f, 0.53f, 0.33f}, 0.007f,
          {0.75f, 0.72f, 0.65f, 0}, {0.05f, 0.05f, 0.05f, 0}, {0.3f, 0.19f, 0.11f, 0}, {0, 0, 0, 0});
  fixture(PR_TUBE, tubeSdf, {-0.62f, -0.62f, -0.14f}, {0.62f, 0.62f, 0.09f}, 0.008f,
          {0.15f, 0.25f, 0.85f, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0});
  gProps[PR_TUBE].spec[0] = 1.5f;
  fixture(PR_REGISTER, registerSdf, {-0.24f, -0.01f, -0.24f}, {0.24f, 0.5f, 0.23f}, 0.0045f,
          {0.66f, 0.62f, 0.54f, 0}, {0.09f, 0.09f, 0.1f, 0}, {0.85f, 0.83f, 0.78f, 0}, {0.08f, 0.5f, 0.3f, 1.2f});
  fixture(PR_DRAWER, drawerSdf, {-0.2f, -0.01f, -0.14f}, {0.2f, 0.09f, 0.14f}, 0.004f,
          {0.2f, 0.2f, 0.21f, 0}, {0.42f, 0.5f, 0.36f, 0}, {0.62f, 0.6f, 0.55f, 0}, {0.06f, 0.06f, 0.07f, 0});
  gProps[PR_DRAWER].spec[2] = 1.4f;
  fixture(PR_SNACK, snackSdf, {-0.12f, -0.01f, -0.06f}, {0.12f, 0.27f, 0.06f}, 0.004f,
          {0.85f, 0.12f, 0.08f, 0}, {0.9f, 0.75f, 0.3f, 0}, {0.75f, 0.75f, 0.78f, 0}, {0, 0, 0, 0});
  gProps[PR_SNACK].spec[0] = 1.2f; gProps[PR_SNACK].spec[2] = 1.6f;
  fixture(PR_BOTTLE, bottleSdf, {-0.05f, -0.01f, -0.05f}, {0.05f, 0.26f, 0.05f}, 0.0035f,
          {0.1f, 0.04f, 0.02f, 0}, {0.75f, 0.08f, 0.06f, 0}, {0.8f, 0.78f, 0.75f, 0}, {0, 0, 0, 0});
  gProps[PR_BOTTLE].spec[0] = 2.0f;
  fixture(PR_PACK, packSdf, {-0.08f, -0.01f, -0.04f}, {0.08f, 0.22f, 0.04f}, 0.004f,
          {0.9f, 0.7f, 0.1f, 0}, {0.85f, 0.2f, 0.12f, 0}, {0.15f, 0.25f, 0.6f, 0}, {0, 0, 0, 0});
  fixture(PR_FPARM, fpArmLightSdf, {-0.08f, -0.12f, -0.22f}, {0.08f, 0.08f, 0.52f}, 0.004f,
          {0.36f, 0.06f, 0.07f, 0}, {0.62f, 0.45f, 0.36f, 0}, {0.28f, 0.04f, 0.05f, 0}, {0.1f, 0.1f, 0.11f, 0});
  gProps[PR_FPARM].spec[3] = 1.6f;
  fixture(PR_FPHAND, fpHandSdf, {-0.08f, -0.12f, -0.1f}, {0.08f, 0.08f, 0.52f}, 0.004f,
          {0.36f, 0.06f, 0.07f, 0}, {0.62f, 0.45f, 0.36f, 0}, {0.28f, 0.04f, 0.05f, 0}, {0.03f, 0.03f, 0.035f, 0});
  fixture(PR_REACH, reachHandSdf, {-0.1f, -0.09f, -0.16f}, {0.07f, 0.08f, 0.52f}, 0.0028f,
          {0.36f, 0.06f, 0.07f, 0}, {0.62f, 0.45f, 0.36f, 0}, {0.28f, 0.04f, 0.05f, 0}, {0.78f, 0.6f, 0.55f, 0});
  fixture(PR_HOURGLASS, hourglassSdf, {-1.35f, -0.01f, -1.35f}, {1.35f, 3.01f, 1.35f}, 0.02f,
          {0.78f, 0.77f, 0.74f, 0}, {0.06f, 0.12f, 0.62f, 0}, {0.3f, 0.2f, 0.62f, 0}, {0.9f, 0.7f, 0.1f, 0});
  fixture(PR_SPIRAL, spiralSdf, {-2.3f, -0.01f, -2.3f}, {2.3f, 3.0f, 2.3f}, 0.024f,
          {0.05f, 0.1f, 0.65f, 0}, {0.55f, 0.56f, 0.6f, 0}, {0.5f, 0.5f, 0.52f, 0}, {0.1f, 0.1f, 0.1f, 0});
  fixture(PR_HOUSE, houseSdf, {-2.5f, -1.05f, -3.15f}, {2.5f, 7.15f, 3.15f}, 0.035f,
          {0.8f, 0.77f, 0.6f, 0}, {0.38f, 0.33f, 0.35f, 0}, {0.16f, 0.2f, 0.26f, 0.25f}, {0.9f, 0.9f, 0.86f, 0});
  gProps[PR_HOUSE].spec[2] = 2.2f;  // the glass is glossy
  fixture(PR_DOORSIDE, doorSideSdf, {-0.76f, -0.01f, -0.13f}, {0.25f, 2.81f, 0.13f}, 0.01f,
          {0.6f, 0.53f, 0.42f, 0}, {0.82f, 0.81f, 0.77f, 0}, {0, 0, 0, 0}, {0, 0, 0, 0});
  fixture(PR_DOORLEAF, doorLeafSdf, {-0.1f, -0.01f, -0.04f}, {0.1f, 2.08f, 0.95f}, 0.006f,
          {0.84f, 0.83f, 0.8f, 0}, {0.6f, 0.6f, 0.62f, 0}, {0, 0, 0, 0}, {0, 0, 0, 0});
  fixture(PR_DESK, deskSdf, {-0.68f, -0.01f, -0.44f}, {0.68f, 1.06f, 0.48f}, 0.008f,
          {0.85f, 0.85f, 0.82f, 0}, {0.55f, 0.55f, 0.58f, 0}, {0.85f, 0.3f, 0.45f, 0}, {0.95f, 0.85f, 0.72f, 0});
  fixture(PR_ARCH, archSdf, {-1.08f, -0.2f, -0.28f}, {1.08f, 2.32f, 0.28f}, 0.012f,
          {0.92f, 0.32f, 0.3f, 0}, {0.45f, 0.8f, 0.65f, 0}, {0.95f, 0.75f, 0.2f, 0}, {0.85f, 0.65f, 0.25f, 0});
  gProps[PR_ARCH].spec[0] = 1.6f; gProps[PR_ARCH].spec[1] = 1.6f; gProps[PR_ARCH].spec[2] = 1.6f; gProps[PR_ARCH].spec[3] = 2.2f;
  fixture(PR_BOOKCASE, bookcaseSdf, {-0.95f, -0.01f, -0.35f}, {0.95f, 1.9f, 0.35f}, 0.012f,
          {0.6f, 0.42f, 0.24f, 0}, {0.46f, 0.31f, 0.17f, 0}, {0, 0, 0, 0}, {0, 0, 0, 0});
  fixture(PR_STAIRS, stairsSdf, {-0.7f, -0.01f, -1.9f}, {0.7f, 4.45f, 1.95f}, 0.014f,
          {0.16f, 0.07f, 0.04f, 0}, {0.24f, 0.11f, 0.06f, 0}, {0.13f, 0.055f, 0.03f, 0}, {0, 0, 0, 0});
  gProps[PR_STAIRS].spec[1] = 0.9f; gProps[PR_STAIRS].spec[2] = 1.1f;
  fixture(PR_TRAMP, trampSdf, {-1.05f, -0.01f, -1.05f}, {1.05f, 0.17f, 1.05f}, 0.012f,
          {0.08f, 0.28f, 0.78f, 0}, {0.012f, 0.012f, 0.014f, 0}, {0.95f, 0.75f, 0.08f, 0}, {0, 0, 0, 0});
  fixture(PR_TRAMPGAP, trampGapSdf, {-1.05f, -0.01f, -1.05f}, {1.05f, 0.17f, 1.05f}, 0.012f,
          {0.08f, 0.28f, 0.78f, 0}, {0.012f, 0.012f, 0.014f, 0}, {0.95f, 0.75f, 0.08f, 0}, {0, 0, 0, 0});
  gProps[PR_TRAMP].spec[0] = 0.6f; gProps[PR_TRAMPGAP].spec[0] = 0.6f;
  fixture(PR_WALLDOOR, wallDoorSdf, {-0.56f, -0.01f, -0.11f}, {0.56f, 2.16f, 0.04f}, 0.006f,
          {0.82f, 0.8f, 0.74f, 0}, {0.48f, 0.33f, 0.2f, 0}, {0.72f, 0.56f, 0.26f, 0}, {0, 0, 0, 0});
  gProps[PR_WALLDOOR].spec[2] = 1.7f; gProps[PR_WALLDOOR].spec[1] = 0.5f;
  fixture(PR_LAMP, lampSdf, {-0.24f, -0.01f, -0.24f}, {0.24f, 1.66f, 0.24f}, 0.008f,
          {0, 0, 0, 0}, {0.1f, 0.09f, 0.08f, 0}, {0, 0, 0, 0}, {0.95f, 0.8f, 0.55f, 1.2f});

  std::fprintf(stderr, "[br9] sculpted models in %u ms (tenant %d tris, hound %d, grin %d)\n", SDL_GetTicks() - t0,
               t.triangles, h.triangles, g.triangles);
  return true;
}

void pose(CreatureId id, const AnimInput& in, const mat4& world, std::vector<mat4>& out) {
  const Model& m = gCreatures[id];
  size_t n = m.bones.size();
  std::vector<mat4> local(n, mat4::identity());
  vec3 rootOffset{0, 0, 0};
  float ph = in.phase, sp = std::min(in.speed, 2.0f), t = in.time, a = in.alert;
  float tw = in.twitch * std::sin(t * 43.0f);

  if (id == CR_HUMAN || id == CR_SUIT || id == CR_WORKER || id == CR_HAZMAT) {
    float walk = std::min(sp, 1.6f);
    float run = clampf(sp - 1.1f, 0.0f, 0.9f);  // past a brisk walk the body leans in and the arms pump
    float idle = 1.0f - std::min(walk, 1.0f);
    float breath = std::sin(t * 1.55f + in.phase * 0.0f);
    float breathe = breath * 0.015f;
    float shift = std::sin(t * 0.33f) + 0.35f * std::sin(t * 0.81f + 1.0f);  // weight moving foot to foot
    // walking: the body rides highest over the planted foot, drops at full stride, and sways over each foot in turn
    rootOffset.y = -0.025f * std::fabs(std::sin(ph)) * walk - 0.008f * std::fabs(shift) * idle + 0.004f * breath * idle;
    rootOffset.x = 0.018f * shift * idle + 0.022f * std::cos(ph) * walk * (1.0f - run * 0.5f);
    local[0] = euler(0.05f * run, 0.07f * std::sin(ph) * walk, 0.02f * std::sin(ph) * walk + 0.035f * shift * idle);
    local[1] = euler(0.04f * walk + 0.16f * run + breathe, 0, -0.012f * std::cos(ph) * walk);
    local[2] = euler(breathe, -0.08f * std::sin(ph) * walk, 0.01f * std::cos(ph) * walk);
    local[3] = euler(-0.05f - 0.05f * run, in.look * 0.4f, 0);
    // the head keeps itself level and looking ahead while the body bobs under it
    local[4] = euler(0.04f + 0.03f * std::sin(t * 0.5f) - 0.12f * run + 0.012f * std::fabs(std::sin(ph)) * walk, in.look * 0.6f + 0.05f * std::sin(t * 0.3f) * idle,
                     0.03f * std::sin(t * 0.41f) * idle - 0.01f * std::cos(ph) * walk);
    for (int s = 0; s < 2; ++s) {
      float sg = s == 0 ? 1.0f : -1.0f;
      float swing = std::sin(ph + (s == 0 ? kPi : 0.0f)) * 0.32f * walk;
      int ua = 6 + s * 3;
      local[ua] = euler(swing * (1.0f - in.carry) + 0.9f * in.carry, 0, 0.06f * sg);
      local[ua] = local[ua] * euler(0.03f * std::sin(t * 0.7f + s) * idle, 0, 0.03f * sg * idle);
      // forearms lag the upper arm a beat and bend more as the pace picks up; shoulders lift a hair on each breath
      local[ua + 1] = euler(0.15f + 0.25f * walk + 0.08f * idle + 0.7f * in.carry + 0.9f * run + 0.12f * std::sin(ph + (s == 0 ? kPi : 0.0f) - 0.7f) * walk, 0, 0);
      local[ua] = local[ua] * euler(0, 0, 0.012f * sg * breath * idle);
      local[ua + 2] = euler(0.05f + 0.1f * idle, 0, 0.1f * sg * idle);
      int th = 12 + s * 3;
      float lph = ph + (s == 0 ? 0.0f : kPi);
      float relaxed = std::max(0.0f, s == 0 ? -shift : shift) * idle;  // the leg not taking the weight
      local[th] = euler(std::sin(lph) * 0.42f * walk + 0.07f * relaxed, 0, -0.03f * sg * shift * idle);
      // knee: folds on the swing, gives a little as the heel takes the weight
      local[th + 1] = euler(-std::max(0.0f, std::cos(lph)) * (0.7f + 0.5f * run) * walk - 0.16f * relaxed - 0.1f * std::max(0.0f, std::sin(lph)) * walk, 0, 0);
      // heel strike, roll through, push off the toe
      local[th + 2] = euler(0.22f * std::sin(lph) * walk - 0.12f * std::max(0.0f, std::sin(lph + 1.2f)) * walk + 0.08f * relaxed, 0, 0);
      if (in.sit == 1) { local[th] = euler(1.5f, 0, 0.08f * sg); local[th + 1] = euler(-0.1f, 0, 0); local[th + 2] = euler(-0.4f, 0, 0); }
      if (in.sit == 2) { local[th] = euler(0.1f, 0, 0.05f * sg); local[th + 1] = euler(-1.55f, 0, 0); local[th + 2] = euler(0.6f, 0, 0); }
      if (in.sit == 3) { local[th] = euler(1.5f, 0, 0.06f * sg); local[th + 1] = euler(-1.45f, 0, 0); local[th + 2] = euler(0.0f, 0, 0); }
      if (in.hug > 0) {
        local[ua] = euler(1.2f * in.hug, -0.5f * sg * in.hug, 0.1f * sg);
        local[ua + 1] = euler(0.9f * in.hug, 0, 0);
      }
      if (in.sit == 1 || in.sit == 3) local[ua + 1] = euler(0.6f + 0.7f * in.carry, 0, 0);
      if (in.cross > 0 && in.offer < 0.2f && in.hold < 0.5f) {  // arms folded across the chest
        // upper arms hang nearly straight, elbows bent a bit under square, forearms across the lower chest
        local[ua] = euler(0.14f * in.cross, 0, -0.16f * sg * in.cross);
        local[ua + 1] = euler(1.42f * in.cross + (s == 0 ? 0.08f : 0.0f), 1.18f * sg * in.cross, 0);  // one arm sits over the other
        local[ua + 2] = euler(0.05f, 0, -0.25f * sg);
      }
      if (s == 0 && (in.hold > 0 || in.offer > 0)) {  // right hand: holding something, or handing it over
        float h = in.hold * (1.0f - in.offer);
        local[ua] = euler(swing * 0.3f * (1.0f - in.offer) + 0.25f * h + 1.05f * in.offer, -0.1f * h, 0.05f);
        local[ua + 1] = euler(1.15f * h + 0.3f * in.offer, 0, 0);
        local[ua + 2] = euler(-0.2f * h, 0, 0);
      }
    }
    if (in.sit == 1) { rootOffset.y = -0.84f; local[1] = euler(-0.25f, 0, 0); }
    if (in.sit == 2) { rootOffset.y = -0.44f; local[1] = euler(0.1f, 0, 0); }
    if (in.sit == 3) rootOffset.y = -0.47f;
  } else if (id == CR_PARTYGOER) {
    // waddling side to side, head tipping like it's listening for you, arms swinging late
    float walk = std::min(sp, 1.2f);
    float w = std::sin(ph) * walk;
    rootOffset.y = -0.02f * std::fabs(std::sin(ph)) * walk;
    local[0] = euler(0.04f * walk, 0.06f * w, 0.09f * w);
    local[1] = euler(0.05f + 0.03f * std::sin(t * 0.9f), 0, -0.05f * w);
    local[2] = euler(0.12f * std::sin(t * 0.6f) - 0.1f * a, 0.3f * std::sin(t * 0.37f), 0.35f * std::sin(t * 0.43f) * (1.0f - a) + 0.25f * tw);
    for (int s = 0; s < 2; ++s) {
      float sg = s == 0 ? 1.0f : -1.0f;
      int ua = 3 + s * 2;
      float swing = std::sin(ph + (s == 0 ? kPi : 0.0f) - 0.6f) * 0.25f * walk;
      // when it wants you, both arms come up and out, for a hug
      local[ua] = euler(swing + 0.75f * a, 0, (0.03f + 0.12f * a) * sg);
      local[ua + 1] = euler(0.15f + 0.5f * a, 0, 0);
    }
  } else if (id == CR_TENANT || id == CR_STILT) {
    // when it's hunting its movement drops frames, like bad stop-motion
    if (a > 0.3f) t = std::floor(t * 9.0f) / 9.0f;
    float snap = std::pow(std::max(0.0f, std::sin(t * 0.37f)), 40.0f);
    tw += snap * 0.9f;
    float walk = std::min(sp, 1.3f);
    rootOffset.y = -0.035f * std::fabs(std::sin(ph)) * walk - 0.05f * a;
    local[0] = euler(0, 0.08f * std::sin(ph) * walk, 0);
    local[1] = euler(-0.22f - 0.12f * a + 0.02f * std::sin(t * 1.1f), 0, 0.03f * std::sin(ph) * walk);
    local[2] = euler(-0.22f - 0.08f * a + 0.015f * std::sin(t * 1.7f), -0.08f * std::sin(ph) * walk, 0);
    local[3] = euler(-0.35f + 0.05f * a, 0.25f * tw, 0.4f * tw);
    local[4] = euler(0.75f + 0.1f * a, 0.15f * std::sin(t * 0.6f) + 0.2f * tw, 0.12f * std::sin(t * 0.37f) + 0.35f * tw);
    local[5] = euler(-0.05f - 0.25f * a - 0.08f * std::max(0.0f, std::sin(t * 2.3f)), 0, 0);
    local[2] = local[2] * euler(0.025f * std::sin(t * (1.1f + 1.6f * a)), 0, 0);  // slow, deep breaths; fast when it has you
    rootOffset.x += 0.02f * std::cos(ph) * walk;                                   // a lurching weight shift
    for (int s = 0; s < 2; ++s) {
      float sg = s == 0 ? 1.0f : -1.0f;
      float swing = std::sin(ph + (s == 0 ? kPi : 0.0f)) * 0.35f * walk;
      int ua = 6 + s * 3;
      // Hunting: arms come up and forward, elbows bent, fingers splayed toward you.
      local[ua] = euler(swing * (1.0f - a) + 0.35f + 0.75f * a, 0, 0.05f * sg);
      local[ua + 1] = euler(0.25f + 0.25f * walk + 0.55f * a, 0, -0.04f * sg * a);
      local[ua + 2] = euler(0.15f + 0.1f * std::sin(t * 2.0f + s), 0, 0);
      int th = 12 + s * 3;
      float lph = ph + (s == 0 ? 0.0f : kPi);
      local[th] = euler(std::sin(lph) * 0.45f * walk + 0.15f * a, 0, 0);
      local[th + 1] = euler(-std::max(0.0f, std::cos(lph)) * 0.75f * walk - 0.2f * a, 0, 0);
      local[th + 2] = euler(0.2f * std::sin(lph) * walk, 0, 0);
    }
  } else if (id == CR_HOUND) {
    float gait = std::min(sp, 2.0f);
    rootOffset.y = -0.03f * std::fabs(std::sin(ph * 2.0f)) * gait;
    local[0] = euler(0.05f * std::sin(ph * 2.0f) * gait, 0.1f * std::sin(ph) * gait, 0);
    local[1] = euler(0.04f * std::sin(ph * 2.0f + 1.0f) * gait, 0.12f * std::sin(ph + 0.5f) * gait, 0);
    local[2] = euler(0, 0.1f * std::sin(ph + 1.0f) * gait, 0.05f * std::sin(ph) * gait);
    float listen = (1.0f - std::min(gait, 1.0f));
    local[3] = euler(0.1f * a, 0.35f * std::sin(t * 1.3f) * listen + 0.3f * tw, 0.3f * tw);
    local[4] = euler(-0.15f * a + 0.1f * std::sin(t * 2.0f) * listen, 0.2f * std::sin(t * 0.9f) * listen, 0.45f * std::sin(t * 0.7f) * listen + 0.5f * tw);
    local[5] = euler(-0.15f - 0.4f * a - 0.15f * std::max(0.0f, std::sin(t * 9.0f)) * a, 0, 0);
    local[2] = local[2] * euler(0.02f * std::sin(t * (6.0f + 8.0f * a)) * (0.4f + a), 0, 0);  // panting
    float bound = clampf((gait - 1.15f) * 2.0f, 0, 1);  // at a full run, front legs together then back legs together
    if (bound > 0) {
      local[0] = local[0] * euler(0.22f * std::sin(ph * 2.0f) * bound, 0, 0);
      local[1] = local[1] * euler(-0.18f * std::sin(ph * 2.0f + 0.6f) * bound, 0, 0);
      rootOffset.y += 0.07f * std::max(0.0f, std::sin(ph * 2.0f + 0.3f)) * bound;
    }
    for (int s = 0; s < 2; ++s) {
      float off = s == 0 ? 0.0f : kPi * (1.0f - bound * 0.92f);
      int fa = 6 + s * 3, hl = 12 + s * 3;
      float f = std::sin(ph + off), h2 = std::sin(ph + off + kPi);
      local[fa] = euler(0.45f * f * gait, 0, 0);
      local[fa + 1] = euler(-0.5f * std::max(0.0f, -std::cos(ph + off)) * gait, 0, 0);
      local[fa + 2] = euler(0.25f * f * gait, 0, 0);
      local[hl] = euler(0.5f * h2 * gait, 0, 0);
      local[hl + 1] = euler(0.55f * std::max(0.0f, std::cos(ph + off + kPi)) * gait, 0, 0);
      local[hl + 2] = euler(-0.3f * h2 * gait, 0, 0);
    }
  } else if (id == CR_GRIN) {
    rootOffset.y = 0.06f * std::sin(t * 1.1f);
    local[0] = euler(0.05f * std::sin(t * 0.7f) - 0.2f * a, 0, 0.06f * std::sin(t * 0.5f));
    local[1] = euler(0.12f * a + 0.05f * std::sin(t * 0.9f), 0.15f * std::sin(t * 0.3f), 0.25f * std::sin(t * 0.43f) + 0.3f * tw);
    local[2] = euler(0.3f * std::sin(t * 1.3f), 0, 0.25f * std::sin(t * 0.9f));
  }

  static const bool kBindPose = std::getenv("NOCLIP_BINDPOSE") != nullptr;  // dev: inspect skinning
  if (kBindPose) { local.assign(n, mat4::identity()); rootOffset = {0, 0, 0}; }
  // World transforms down the hierarchy, then skinning matrices.
  std::vector<mat4> W(n);
  out.resize(n);
  for (size_t i = 0; i < n; ++i) {
    const Bone& b = m.bones[i];
    if (b.parent < 0) W[i] = world * translate(b.head + rootOffset) * local[i];
    else W[i] = W[b.parent] * translate(b.head - m.bones[b.parent].head) * local[i];
    out[i] = W[i] * translate(-b.head);
  }
}

}  // namespace creatures
