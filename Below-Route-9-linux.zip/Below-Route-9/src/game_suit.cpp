// The suit. Someone left a hazmat suit at the bottom of the fall, slumped like a person.
// Dana puts it on and keeps it on: yellow sleeves, black gloves, the visor's edge, her own breathing.
// Further in, sometimes, there are two more of them, far down a hallway, walking away.
#include <cmath>
#include <cstdlib>

#include "audio.h"
#include "game.h"
#include "texgen.h"

void Game::suitReset() {
  suitState_ = 0;
  suitT_ = 0;
  teamState_ = 0;
  teamT_ = 0;
  teamAt_ = rng_.range(45.0f, 110.0f);
  if (levelIndex_ == 0 && !hazmat_ && !wentBack_) {
    // just ahead of where you land, sitting against nothing, head down
    vec3 f{-std::sin(checkpointYaw_), 0, -std::cos(checkpointYaw_)};
    vec3 start = level_.tileCenter(level_.startX, level_.startZ);
    suitPos_ = start;
    for (float d : {1.7f, 1.2f}) {
      for (int turn = 0; turn < 4; ++turn) {
        vec3 dir = turn == 0 ? f : (turn == 1 ? vec3{f.z, 0, -f.x} : (turn == 2 ? vec3{-f.z, 0, f.x} : f * -1.0f));
        vec3 c = start + dir * d;
        int sx, sz, cx, cz;
        level_.tileOf(start.x, start.z, sx, sz);
        level_.tileOf(c.x, c.z, cx, cz);
        if (!level_.solid.empty() && level_.solid[level_.idx(cx, cz)]) continue;
        bool ok = true;
        if (cx != sx || cz != sz)
          for (int k = 0; k < 4; ++k)
            if (sx + kDX[k] == cx && sz + kDZ[k] == cz && level_.blocked(sx, sz, k)) ok = false;
        if (!ok) continue;
        suitPos_ = c;
        suitYaw_ = std::atan2(dir.x, dir.z);  // facing back toward you
        suitState_ = 1;
        break;
      }
      if (suitState_) break;
    }
  }
}

bool Game::suitFocus() const {
  if (suitState_ != 1) return false;
  vec3 d = level_.delta(pos_, suitPos_);
  d.y = 0;
  return length(d) < 1.9f;
}

bool Game::suitInteract() {
  if (!suitFocus()) return false;
  suitState_ = 2;  // putting it on
  suitT_ = 0;
  if (A_) { A_->play(Sfx::Paper, 0.6f); A_->play(Sfx::Zip, 0.8f, 0, 0.9f); }
  return true;
}

void Game::suitUpdate(float dt) {
  if (suitState_ == 2) {
    suitT_ += dt;
    if (suitT_ > 1.1f && !hazmat_) {
      hazmat_ = true;
      unlockBadge(9);
      toast_ = "THRESHOLD SURVEY  -  UNIT 4";
      toastTime_ = 3.0f;
      breathT_ = 0;
      saveProgress();
    }
    if (suitT_ > 2.2f) {
      suitState_ = 3;
      say("DANA", "(It's still warm inside.)", 2.8f);
    }
  }
  // breathing in the respirator
  if (hazmat_ && !inStore() && screen_ == Screen::Playing && A_) {
    float rate = 1.0f + fear_ * 0.9f + (sprinting_ ? 0.5f : 0.0f);
    breathT_ += dt * rate;
    if (breathT_ >= 2.4f) {
      breathT_ = 0;
      A_->play(Sfx::Breath, 0.35f + fear_ * 0.3f, 0, 1.0f / std::max(0.7f, rate * 0.85f));
    }
  }
  // the survey team, far away, once per level
  if (levelIndex_ >= 0 && levelIndex_ <= 2 && screen_ == Screen::Playing && hazmat_) {
    teamT_ += dt;
    if (teamState_ == 0 && teamT_ > teamAt_) {
      // need a long straight view down a hallway
      vec3 f = forward();
      int dir = std::fabs(f.x) > std::fabs(f.z) ? (f.x > 0 ? PX : NX) : (f.z > 0 ? PZ : NZ);
      int x, z;
      level_.tileOf(pos_.x, pos_.z, x, z);
      int n = 0;
      int cx = x, cz = z;
      while (n < 12 && !level_.blocked(cx, cz, dir)) { cx += kDX[dir]; cz += kDZ[dir]; ++n; }
      if (n >= 7) {
        teamState_ = 1;
        teamT_ = 0;
        teamDir_ = {(float)kDX[dir], 0, (float)kDZ[dir]};
        teamPos_ = level_.tileCenter(x, z) + teamDir_ * (Level::kTile * (n - 4.5f));
        teamLen_ = Level::kTile * 3.5f;
        if (A_) { A_->play(Sfx::HeavyStep, 0.25f, 0, 0.6f); A_->play(Sfx::Spark, 0.2f); }
      } else {
        teamAt_ = teamT_ + 4.0f;  // try again in a bit
      }
    } else if (teamState_ == 1) {
      teamPos_ += teamDir_ * (0.9f * dt);
      teamLen_ -= 0.9f * dt;
      vec3 d = level_.delta(pos_, teamPos_);
      d.y = 0;
      if (teamT_ > 2.5f && teamT_ - dt <= 2.5f) say("DANA", "...Hey. HEY!", 1.8f);
      if (A_ && std::fmod(teamT_, 0.62f) < dt) A_->play(Sfx::Footstep, 0.12f, 0, 0.8f);
      if (length(d) < 7.0f || teamT_ > 13.0f || teamLen_ < 0.5f) {
        teamState_ = 2;  // gone, between one flicker and the next
        if (A_) A_->play(Sfx::Brownout, 0.6f);
        fear_ = std::min(1.0f, fear_ + 0.25f);
      }
    }
  }
}

void Game::suitDraw(Shader& S, vec3 cam) {
  S.set("uMat", MAT_MODEL);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  if (suitState_ == 1 || (suitState_ == 2 && suitT_ < 0.6f)) {
    vec3 p = near(suitPos_, cam);
    p.y = level_.floorAt(suitPos_.x, suitPos_.z);
    AnimInput in;
    in.time = 0;  // nobody's breathing in it
    in.sit = 1;
    in.look = 0.35f;
    drawCreatureAt(S, CR_HAZMAT, translate(p) * rotY(suitYaw_) * rotX(-0.18f), in);
  }
  if (teamState_ == 1) {
    for (int k = 0; k < 2; ++k) {
      vec3 side{teamDir_.z, 0, -teamDir_.x};
      vec3 p = near(teamPos_ + teamDir_ * (k * 1.3f) + side * (k ? 0.35f : -0.25f), cam);
      p.y = level_.floorAt(p.x, p.z);
      AnimInput in;
      in.time = time_ + k * 3.0f;
      in.phase = teamT_ * 5.2f + k * 1.7f;
      in.speed = 0.7f;
      drawCreature(S, CR_HAZMAT, p, std::atan2(-teamDir_.x, -teamDir_.z), in);
    }
    // the red air hose they drag behind them, back toward you, lying in loose curves
    S.set("uMat", MAT_PROP);
    vec3 side{teamDir_.z, 0, -teamDir_.x};
    vec3 a = near(teamPos_ + side * -0.25f, cam);
    float total = std::max(0.5f, teamLen_ + 2.0f);
    const int N = 28;
    vec3 prev = a;
    for (int i = 1; i <= N; ++i) {
      float u = (float)i / N;
      float d = u * total;
      // the slack settles into slow S-bends; the far end stays where it came round the corner
      float wig = std::sin(d * 1.3f + 0.7f) * 0.32f * std::min(1.0f, d * 0.8f) + std::sin(d * 3.1f) * 0.06f;
      vec3 q = a - teamDir_ * d + side * wig;
      vec3 mid = (prev + q) * 0.5f;
      vec3 seg = q - prev;
      float sl = length(seg);
      float yaw = std::atan2(seg.x, seg.z);
      drawPart(translate({mid.x, level_.floorAt(mid.x, mid.z) + 0.018f, mid.z}) * rotY(yaw) * scale({0.035f, 0.035f, sl + 0.01f}),
               {0.62f, 0.05f, 0.04f}, 0.05f);
      prev = q;
    }
    // the second one wheels a black equipment case in front of him
    vec3 cp = near(teamPos_ + teamDir_ * (1.3f + 0.55f) + side * 0.35f, cam);
    float fy = level_.floorAt(cp.x, cp.z);
    float cy = std::atan2(teamDir_.x, teamDir_.z);
    mat4 base = translate({cp.x, fy, cp.z}) * rotY(cy);
    drawPart(base * translate({0, 0.42f, 0}) * scale({0.46f, 0.72f, 0.3f}), {0.025f, 0.025f, 0.028f});      // hard case
    drawPart(base * translate({0, 0.42f, 0.152f}) * scale({0.4f, 0.64f, 0.01f}), {0.04f, 0.04f, 0.045f});    // lid ridge
    drawPart(base * translate({0, 0.8f, -0.05f}) * scale({0.16f, 0.03f, 0.04f}), {0.08f, 0.08f, 0.09f});     // handle
    for (int w = -1; w <= 1; w += 2)                                                                          // wheels
      drawPart(base * translate({w * 0.17f, 0.035f, -0.11f}) * scale({0.04f, 0.07f, 0.07f}), {0.05f, 0.05f, 0.05f});
    drawPart(base * translate({0.12f, 0.62f, 0.158f}) * scale({0.1f, 0.06f, 0.004f}), {0.85f, 0.75f, 0.12f});  // yellow survey label
    S.set("uMat", MAT_MODEL);
  }
}

void Game::suitHUD() {
  float W = (float)R_->winW, H = (float)R_->winH, s = ui();
  if (hazmat_ && !inStore()) {
    if (!texVisor_) {
      // The visor: clear in the middle, the rubber seal darkening the edges, a few scratches, a soft reflection.
      Image v;
      v.w = 640; v.h = 360;
      v.px.resize((size_t)v.w * v.h * 4);
      for (int y = 0; y < v.h; ++y)
        for (int x = 0; x < v.w; ++x) {
          float u = (x + 0.5f) / v.w * 2 - 1, w = (y + 0.5f) / v.h * 2 - 1;
          float e = std::pow(std::pow(std::fabs(u) / 1.06f, 2.6f) + std::pow(std::fabs(w) / 1.12f, 2.6f), 1.0f / 2.6f);
          float a = smoothstepf(0.9f, 1.1f, e) * 0.9f;
          float shade = 0.012f;
          float streak = std::exp(-std::pow((u + w * 0.8f + 0.9f) / 0.12f, 2.0f)) * 0.05f * (w < 0 ? 1.0f : 0.3f);
          float scratch = hashf(x / 2, y * 3 / 5, 77) > 0.9993f ? 0.12f : 0.0f;
          float alpha = std::min(1.0f, a + streak + scratch);
          float col = a > streak ? shade : 0.9f;
          size_t i = ((size_t)y * v.w + x) * 4;
          v.px[i] = v.px[i + 1] = v.px[i + 2] = (uint8_t)(col * 255);
          v.px[i + 3] = (uint8_t)(alpha * 255);
        }
      texVisor_ = makeTexture(v, true, false);
      Image f;
      f.w = 256; f.h = 128;
      f.px.resize((size_t)f.w * f.h * 4);
      for (int y = 0; y < f.h; ++y)
        for (int x = 0; x < f.w; ++x) {
          float u = (x + 0.5f) / f.w * 2 - 1, w = (y + 0.5f) / f.h;
          float a = std::exp(-(u * u) * 3.0f) * smoothstepf(0.0f, 1.0f, w) * (0.75f + 0.25f * hashf(x / 4, y / 4, 5));
          size_t i = ((size_t)y * f.w + x) * 4;
          f.px[i] = f.px[i + 1] = f.px[i + 2] = 235;
          f.px[i + 3] = (uint8_t)(clampf(a, 0, 1) * 255);
        }
      texFog_ = makeTexture(f, true, false);
    }
    // the breath fogging the lower visor on every exhale
    float cyc = breathT_ / 2.4f;
    float fog = cyc > 0.5f ? std::sin((cyc - 0.5f) / 0.5f * kPi) : 0.0f;
    R_->image(texFog_, W * 0.2f, H * 0.62f, W * 0.6f, H * 0.4f, fog * (0.1f + fear_ * 0.12f));
    R_->image(texVisor_, 0, 0, W, H, 1.0f);
  }
  if (suitState_ == 2) {  // putting it on: a few seconds of rubber and dark
    float a = clampf(suitT_ / 0.35f, 0, 1) * clampf((2.2f - suitT_) / 0.6f, 0, 1);
    R_->rect(0, 0, W, H, 0, 0, 0, a);
  }
  if (suitFocus() && screen_ == Screen::Playing) {
    std::string p = std::string(usingPad_ ? "[A]" : "[E]") + " PUT ON THE SUIT";
    R_->text(p, W * 0.5f - R_->textWidth(p, s) * 0.5f, H * 0.62f, s, 0.95f, 0.92f, 0.82f, 0.9f);
  }
}

// Blinking: every few seconds, faster when scared, a fifth of a second of dark.
float Game::lidClosure() const {
  if (!settings.blink || blinkPhase_ < 0) return 0.0f;
  float k = blinkPhase_;  // 0..1 through the blink
  return std::sin(std::min(k, 1.0f) * kPi);
}

void Game::updateBlink(float dt) {
  static const bool capture = std::getenv("BR9_NOHUD") != nullptr;  // trailers: eyes open
  if (!settings.blink || capture || hiding_ >= 0) { blinkPhase_ = -1; return; }
  if (blinkPhase_ >= 0) {
    blinkPhase_ += dt / (0.17f + 0.05f * fear_);
    if (blinkPhase_ >= 1.0f) {
      blinkPhase_ = -1;
      blinkT_ = rng_.range(3.0f, 7.0f) * (1.0f - 0.55f * fear_);
      if (rng_.f01() < 0.12f) blinkT_ = 0.25f;  // sometimes twice
    }
    return;
  }
  blinkT_ -= dt;
  if (blinkT_ <= 0) blinkPhase_ = 0;
}

void Game::drawBlink() {
  float c = lidClosure();
  if (c <= 0.001f || (screen_ != Screen::Playing && screen_ != Screen::Plunge)) return;
  float W = (float)R_->winW, H = (float)R_->winH;
  // two lids with soft edges meeting slightly above the middle
  float meet = H * 0.47f;
  float top = meet * c, bot = (H - meet) * c;
  R_->rect(0, 0, W, top, 0, 0, 0, 1);
  R_->rect(0, H - bot, W, bot, 0, 0, 0, 1);
  const int N = 10;
  float feather = H * 0.06f;
  for (int i = 0; i < N; ++i) {
    float a = (1.0f - (i + 0.5f) / N) * std::min(1.0f, c * 2.0f);
    R_->rect(0, top + i * feather / N, W, feather / N, 0.02f, 0.01f, 0.01f, a);
    R_->rect(0, H - bot - (i + 1) * feather / N, W, feather / N, 0.02f, 0.01f, 0.01f, a);
  }
}
