#include "entity.h"
#include <cmath>
#include <vector>

void Stalker::placeFar(const Level& L, vec3 playerPos, Rng& rng, int minTiles, int maxTiles) {
  int px, pz;
  L.tileOf(playerPos.x, playerPos.z, px, pz);
  std::vector<int> d = L.bfs(px, pz);
  std::vector<int> cands;
  for (int i = 0; i < L.W * L.H; ++i) {
    if (d[i] < minTiles || d[i] > maxTiles || L.pillar[i]) continue;
    vec3 c = L.tileCenter(i % L.W, i / L.W);
    if (L.lineOfSight(c.x, c.z, playerPos.x, playerPos.z)) continue;
    cands.push_back(i);
  }
  if (cands.empty())
    for (int i = 0; i < L.W * L.H; ++i) if (d[i] >= minTiles / 2 && !L.pillar[i]) cands.push_back(i);
  if (cands.empty()) cands.push_back(0);
  int pick = cands[rng.next() % cands.size()];
  pos = L.tileCenter(pick % L.W, pick / L.W);
  goal_ = pos;
  setState(Wander);
  idleFor_ = 0;
  lostTime_ = 0;
}

bool Stalker::canSee(const Level& L, vec3 target, float range) const {
  if (P.blind) return false;
  vec3 dd = L.delta(pos, target);
  float dx = dd.x, dz = dd.z;
  float d = std::sqrt(dx * dx + dz * dz);
  if (d > range * P.sight) return false;
  if (d > 3.5f) {
    float fx = -std::sin(yaw), fz = -std::cos(yaw);
    if ((fx * dx + fz * dz) / std::max(d, 1e-4f) < -0.2f) return false;
  }
  return L.lineOfSight(pos.x, pos.z, target.x, target.z);
}

void Stalker::pickWanderGoal(const Level& L, vec3 playerPos, Rng& rng, int radius) {
  int cx, cz;
  if (rng.f01() < 0.33f) L.tileOf(playerPos.x, playerPos.z, cx, cz);
  else L.tileOf(pos.x, pos.z, cx, cz);
  for (int tries = 0; tries < 20; ++tries) {
    int gx = cx + rng.irange(-radius, radius), gz = cz + rng.irange(-radius, radius);
    if (L.hasPillar(gx, gz)) continue;
    goal_ = L.tileCenter(gx, gz);
    goal_.x += rng.range(-0.5f, 0.5f);
    goal_.z += rng.range(-0.5f, 0.5f);
    goal_ = L.wrap(goal_);
    return;
  }
}

void Stalker::moveToward(const Level& L, vec3 target, float spd, float dt, bool direct) {
  vec3 aim = target;
  if (!direct) {
    int sx, sz, gx, gz, nx, nz;
    L.tileOf(pos.x, pos.z, sx, sz);
    L.tileOf(target.x, target.z, gx, gz);
    if ((sx != gx || sz != gz) && L.nextStep(sx, sz, gx, gz, nx, nz)) aim = L.tileCenter(nx, nz);
  }
  vec3 d = L.delta(pos, aim);
  d.y = 0;
  float len = length(d);
  if (len < 0.02f) { speed = 0; return; }
  if (L.floorAt(pos.x, pos.z) < -0.1f) spd *= 0.75f;  // wading
  vec3 dir = d * (1.0f / len);
  float step = std::min(len, spd * dt);
  vec3 before = pos;
  pos += dir * step;
  L.collide(pos, P.radius);
  speed = length(pos - before) / std::max(dt, 1e-4f);
  pos = L.wrap(pos);
  float targetYaw = std::atan2(-dir.x, -dir.z);
  float dy = std::remainder(targetYaw - yaw, 2.0f * kPi);
  yaw += dy * std::min(1.0f, dt * 6.0f);
}

Stalker::Events Stalker::update(float dt, const Level& L, const Perception& p, Rng& rng) {
  Events ev;
  if (state == Dormant) return ev;
  stateTime += dt;
  twitch = std::max(0.0f, twitch - dt * 3.0f);
  if (rng.f01() < dt * 0.6f) twitch = 1.0f;

  vec3 toP = L.delta(pos, p.playerPos);
  toP.y = 0;
  float dist = length(toP);
  bool sees = canSee(L, p.playerPos, p.sightRange);
  bool hears = dist < p.noiseRadius * P.hearing;
  if (p.hidden) {  // you got into a locker without it seeing: it loses you
    sees = hears = false;
    if (hunt > 0) { hunt = 0; lastKnown_ = p.playerPos; setState(Search); }
  }
  auto far = [&](vec3 a, float r) { vec3 q = L.delta(pos, a); q.y = 0; return length(q) >= r; };
  if (hunt > 0) {  // it simply knows
    hunt -= dt;
    if (state != Chase) { setState(Chase); chaseTime = 0; ev.chaseStarted = true; }
    lastKnown_ = p.playerPos;
    lostTime_ = 0;
    moveToward(L, lastKnown_, huntSpeed, dt, L.lineOfSight(pos.x, pos.z, p.playerPos.x, p.playerPos.z));
    if (dist < P.catchDist && L.lineOfSight(pos.x, pos.z, p.playerPos.x, p.playerPos.z)) ev.caught = true;
    if (hunt <= 0) setState(Search);
    anim += speed * dt * (2.0f * kPi / (P.stride * 2.0f));
    stepPhase_ += speed * dt / P.stride;
    if (stepPhase_ >= 1.0f) { stepPhase_ -= 1.0f; ev.step = true; }
    return ev;
  }

  if (state != Chase) {
    bool trigger = sees;
    // Blind hunters lunge at loud, close noises.
    if (P.blind && hears && p.noiseRadius >= 12.0f && dist < 9.0f) trigger = true;
    if (P.blind && dist < 1.4f && p.noiseRadius > 0.0f) trigger = true;
    if (trigger) {
      lastKnown_ = p.playerPos;
      setState(Chase);
      chaseTime = 0;
      lostTime_ = 0;
      ev.chaseStarted = true;
    }
  }

  switch (state) {
    case Wander:
      if (hears) { lastKnown_ = p.playerPos; setState(Investigate); break; }
      moveToward(L, goal_, P.wanderSpeed, dt, false);
      if (!far(goal_, 0.6f)) { idleFor_ = rng.range(1.0f, 3.5f); setState(Idle); }
      break;
    case Idle:
      speed = 0;
      if (hears) { lastKnown_ = p.playerPos; setState(Investigate); break; }
      if (stateTime > idleFor_) { pickWanderGoal(L, p.playerPos, rng, 9); setState(Wander); }
      break;
    case Investigate:
      if (hears) lastKnown_ = p.playerPos;
      moveToward(L, lastKnown_, P.investigateSpeed, dt, false);
      if (!far(lastKnown_, 0.8f) || stateTime > 25.0f) setState(Search);
      break;
    case Chase: {
      chaseTime += dt;
      bool contact = sees || (P.blind && hears);
      if (contact) { lastKnown_ = p.playerPos; lostTime_ = 0; }
      else lostTime_ += dt;
      float spd = std::min(P.chaseBase + chaseTime * P.chaseAccel, P.chaseMax);
      bool direct = contact && L.lineOfSight(pos.x, pos.z, lastKnown_.x, lastKnown_.z);
      moveToward(L, lastKnown_, spd, dt, direct);
      bool touching = dist < P.catchDist && L.lineOfSight(pos.x, pos.z, p.playerPos.x, p.playerPos.z);
      if (touching && (sees || P.blind)) ev.caught = true;
      if (lostTime_ > P.giveUp || (!contact && !far(lastKnown_, 0.6f) && lostTime_ > 1.0f)) setState(Search);
    } break;
    case Search:
      if (hears) { lastKnown_ = p.playerPos; setState(Investigate); break; }
      if (!far(goal_, 0.6f) || stateTime < dt * 1.5f) {
        goal_ = lastKnown_;
        goal_.x += rng.range(-4.0f, 4.0f);
        goal_.z += rng.range(-4.0f, 4.0f);
        goal_ = L.wrap(goal_);
      }
      moveToward(L, goal_, P.searchSpeed, dt, false);
      if (stateTime > 9.0f) { pickWanderGoal(L, p.playerPos, rng, 10); setState(Wander); }
      break;
    default: break;
  }

  anim += speed * dt * (2.0f * kPi / (P.stride * 2.0f));
  stepPhase_ += speed * dt / P.stride;
  if (stepPhase_ >= 1.0f) { stepPhase_ -= 1.0f; ev.step = true; }
  return ev;
}

Grin::Events Grin::update(float dt, const Level& L, const Perception& p, const std::vector<float>& st, vec3 camForward, Rng& rng) {
  Events ev;
  if (!active) return ev;
  anim += dt;
  twitch = std::max(0.0f, twitch - dt * 2.0f);
  if (rng.f01() < dt * 0.3f) twitch = 1.0f;
  vec3 to = L.delta(pos, p.playerPos);
  to.y = 0;
  float dist = length(to);
  bool los = !p.hidden && dist < 22.0f && L.lineOfSight(pos.x, pos.z, p.playerPos.x, p.playerPos.z);
  bool playerInDark = p.playerLight < 0.25f;
  // Being looked at with the light off makes it hold still.
  vec3 toG = normalize(-to);
  bool watched = dot(toG, normalize(vec3{camForward.x, 0, camForward.z})) > 0.8f;
  bool drawn = los && playerInDark && p.flashlightOn;
  float wasAlert = alert;
  alert = clampf(alert + (drawn ? dt * 1.5f : -dt * 0.5f), 0.0f, 1.0f);
  if (alert > 0.6f && wasAlert <= 0.6f) ev.noticed = true;

  vec3 target = home;
  float spd = 0.6f;
  if (drawn) { target = p.playerPos; spd = 1.9f + alert * 0.8f; }
  else if (los && playerInDark && !watched) { target = p.playerPos; spd = 0.9f; }  // creeps when unobserved
  vec3 d = L.delta(pos, target);
  d.y = 0;
  float len = length(d);
  speed = 0;
  if (len > 0.05f) {
    vec3 step = d * (std::min(len, spd * dt) / len);
    vec3 next = pos + step;
    L.collide(next, 0.3f);
    // It never leaves the dark.
    if (L.lightAt(next.x, next.z, st) < 0.12f) { speed = length(next - pos) / std::max(dt, 1e-4f); pos = L.wrap(next); }
    float ty = std::atan2(-d.x, -d.z);
    yaw += std::remainder(ty - yaw, 2.0f * kPi) * std::min(1.0f, dt * 3.0f);
  }
  // It is always looking at you.
  if (los) {
    float ty = std::atan2(-to.x, -to.z);
    yaw += std::remainder(ty - yaw, 2.0f * kPi) * std::min(1.0f, dt * 2.0f);
  }
  if (dist < 0.9f && playerInDark) ev.caught = true;
  return ev;
}
