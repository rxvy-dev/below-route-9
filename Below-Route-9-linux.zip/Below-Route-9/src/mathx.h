// Small vector / matrix library. Column-major matrices, right-handed, -Z forward.
#pragma once
#include <cmath>
#include <cstdint>

constexpr float kPi = 3.14159265358979f;

struct vec2 { float x = 0, y = 0; };
struct vec4 { float x = 0, y = 0, z = 0, w = 0; };
struct vec3 {
  float x = 0, y = 0, z = 0;
  vec3() = default;
  constexpr vec3(float a, float b, float c) : x(a), y(b), z(c) {}
  vec3 operator+(const vec3& o) const { return {x + o.x, y + o.y, z + o.z}; }
  vec3 operator-(const vec3& o) const { return {x - o.x, y - o.y, z - o.z}; }
  vec3 operator*(float s) const { return {x * s, y * s, z * s}; }
  vec3 operator-() const { return {-x, -y, -z}; }
  vec3& operator+=(const vec3& o) { x += o.x; y += o.y; z += o.z; return *this; }
  vec3& operator-=(const vec3& o) { x -= o.x; y -= o.y; z -= o.z; return *this; }
};
inline float dot(vec3 a, vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline vec3 cross(vec3 a, vec3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
inline float length(vec3 a) { return std::sqrt(dot(a, a)); }
inline vec3 normalize(vec3 a) { float l = length(a); return l > 1e-6f ? a * (1.0f / l) : vec3{0, 0, 0}; }
inline vec3 lerp(vec3 a, vec3 b, float t) { return a + (b - a) * t; }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float smoothstepf(float a, float b, float x) { float t = clampf((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }

struct mat4 {
  float m[16];
  static mat4 identity() { mat4 r{}; for (int i = 0; i < 16; ++i) r.m[i] = (i % 5 == 0) ? 1.f : 0.f; return r; }
  mat4 operator*(const mat4& b) const {
    mat4 r{};
    for (int c = 0; c < 4; ++c)
      for (int rr = 0; rr < 4; ++rr) {
        float s = 0;
        for (int k = 0; k < 4; ++k) s += m[k * 4 + rr] * b.m[c * 4 + k];
        r.m[c * 4 + rr] = s;
      }
    return r;
  }
};

inline mat4 perspective(float fovyRad, float aspect, float zn, float zf) {
  mat4 r{};
  float f = 1.0f / std::tan(fovyRad * 0.5f);
  r.m[0] = f / aspect; r.m[5] = f;
  r.m[10] = (zf + zn) / (zn - zf); r.m[11] = -1;
  r.m[14] = 2 * zf * zn / (zn - zf);
  return r;
}
inline mat4 lookAt(vec3 eye, vec3 center, vec3 up) {
  vec3 f = normalize(center - eye), s = normalize(cross(f, up)), u = cross(s, f);
  mat4 r = mat4::identity();
  r.m[0] = s.x; r.m[4] = s.y; r.m[8] = s.z;
  r.m[1] = u.x; r.m[5] = u.y; r.m[9] = u.z;
  r.m[2] = -f.x; r.m[6] = -f.y; r.m[10] = -f.z;
  r.m[12] = -dot(s, eye); r.m[13] = -dot(u, eye); r.m[14] = dot(f, eye);
  return r;
}
inline mat4 translate(vec3 t) { mat4 r = mat4::identity(); r.m[12] = t.x; r.m[13] = t.y; r.m[14] = t.z; return r; }
inline mat4 scale(vec3 s) { mat4 r = mat4::identity(); r.m[0] = s.x; r.m[5] = s.y; r.m[10] = s.z; return r; }
inline mat4 rotY(float a) { mat4 r = mat4::identity(); float c = std::cos(a), s = std::sin(a); r.m[0] = c; r.m[2] = -s; r.m[8] = s; r.m[10] = c; return r; }
inline mat4 rotX(float a) { mat4 r = mat4::identity(); float c = std::cos(a), s = std::sin(a); r.m[5] = c; r.m[6] = s; r.m[9] = -s; r.m[10] = c; return r; }
inline mat4 rotZ(float a) { mat4 r = mat4::identity(); float c = std::cos(a), s = std::sin(a); r.m[0] = c; r.m[1] = s; r.m[4] = -s; r.m[5] = c; return r; }

// Deterministic RNG (xorshift-based), shared by generation code.
struct Rng {
  uint64_t s;
  explicit Rng(uint64_t seed = 0x9E3779B97F4A7C15ull) : s(seed ? seed : 1) {}
  uint32_t next() { s ^= s << 13; s ^= s >> 7; s ^= s << 17; return (uint32_t)(s >> 16); }
  float f01() { return (next() & 0xFFFFFF) / float(0x1000000); }
  float range(float a, float b) { return a + (b - a) * f01(); }
  int irange(int a, int bInclusive) { return a + (int)(next() % (uint32_t)(bInclusive - a + 1)); }
};

inline uint32_t hash32(uint32_t x) {
  x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16; return x;
}
inline float hashf(int a, int b = 0, int c = 0) {
  return (hash32((uint32_t)a * 73856093u ^ hash32((uint32_t)b * 19349663u ^ hash32((uint32_t)c * 83492791u))) & 0xFFFFFF) / float(0x1000000);
}
