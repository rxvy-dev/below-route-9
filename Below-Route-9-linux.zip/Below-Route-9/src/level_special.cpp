// Levels with their own furniture and rules:
//   Parking   - lettered piers, painted bay lines, abandoned cars (pipes are drawn in game_special.cpp)
//   Office    - "Count On Me": the mural room with two doors onto metre-wide corridors
//   Playplace - an open hall of balls, hourglass pillars and spiral slides
//   Suburbs   - rolling hills of identical houses under an open sky
#include <algorithm>
#include <cmath>

#include "level.h"
#include "creatures.h"

namespace {
vec3 dirV(int d) { return {(float)kDX[d], 0, (float)kDZ[d]}; }
}  // namespace

// Rolling hills, seamless over the level (periods divide the level size).
float Level::terrainH(float x, float z) const {
  const float A = theme.terrain, tau = 6.2831853f;
  float u = x / periodX, v = z / periodZ;
  float h = 0.55f * std::sin(tau * (u * 2.0f) + 0.7f) * std::cos(tau * (v * 3.0f) + 1.3f) +
            0.3f * std::sin(tau * (u * 4.0f + v * 4.0f) + 2.1f) +
            0.15f * std::sin(tau * (u * 8.0f) + 0.4f) * std::cos(tau * (v * 6.0f) + 0.9f);
  return A * h;
}

void Level::specialLayout(Rng& rng) {
  auto seam = [&](int x, int z, int d) {
    return (d == PX && x == W - 1) || (d == NX && x == 0) || (d == PZ && z == H - 1) || (d == NZ && z == 0);
  };
  switch (theme.special) {
    case Special::Park: {
      // One big hall in the middle of the map; everything else is outside the building.
      park.x0 = W / 2 - 8; park.x1 = W / 2 + 7; park.z0 = H / 2 - 6; park.z1 = H / 2 + 5;
      bed.assign(W * H, 0);
      auto inside = [&](int x, int z) { return x >= park.x0 && x <= park.x1 && z >= park.z0 && z <= park.z1; };
      for (int z = 0; z < H; ++z)
        for (int x = 0; x < W; ++x) {
          int i = idx(x, z);
          pillar[i] = 0; pool[i] = 0;
          if (!inside(x, z)) { solid[i] = 1; zone[i] = 3; eWall[i] = 0; sWall[i] = 0; continue; }
          eWall[i] = inside(x + 1, z) ? 0 : 1;
          sWall[i] = inside(x, z + 1) ? 0 : 1;
        }
      for (int z = park.z0; z <= park.z1; ++z) setWall(park.x0, z, NX, 1);
      for (int x = park.x0; x <= park.x1; ++x) setWall(x, park.z0, NZ, 1);
      // the court: twelve beds across, five deep, against the back (north) wall; the foam pit beside it
      for (int z = park.z0; z <= park.z0 + 4; ++z) {
        for (int x = park.x0 + 2; x <= park.x0 + 13; ++x) bed[idx(x, z)] = 1;
        for (int x = park.x0 + 14; x <= park.x1; ++x) bed[idx(x, z)] = 2;
      }
      park.crevX = park.x0 + 9 + (int)(rng.next() % 3);
      park.crevZ = park.z0;
      // Mom and Dad by the tables at the front, watching
      park.mom = tileCenter(park.x0 + 6, park.z1 - 2) + vec3{0.2f, 0, 0.3f};
      park.dad = tileCenter(park.x0 + 7, park.z1 - 2) + vec3{0.1f, 0, 0.1f};
      park.momYaw = 0.12f; park.dadYaw = -0.1f;
      park.kids.clear();
      for (int k = 0; k < 6; ++k) {
        int x = rng.irange(park.x0 + 2, park.x0 + 13), z = rng.irange(park.z0 + 1, park.z0 + 4);
        if (std::abs(x - park.crevX) <= 1 && z <= park.z0 + 1) continue;
        park.kids.push_back(tileCenter(x, z) + vec3{rng.range(-0.3f, 0.3f), 0, rng.range(-0.3f, 0.3f)});
      }
    } break;
    case Special::Suburbs: {
      // open ground everywhere; houses on a loose grid, each a 3 x 3 tile block nobody walks into
      for (int i = 0; i < W * H; ++i) { eWall[i] = 0; sWall[i] = 0; pillar[i] = 0; }
      for (int gz = 1; gz < H - 3; gz += 6)
        for (int gx = 1; gx < W - 3; gx += 5) {
          int x = gx + (int)(rng.next() % 2), z = gz + (int)(rng.next() % 3);
          if (x + 2 >= W - 1 || z + 2 >= H - 1) continue;
          for (int dz = 0; dz < 3; ++dz)
            for (int dx = 0; dx < 3; ++dx) solid[idx(x + dx, z + dz)] = 1;
        }
    } break;
    case Special::Playplace: {
      // one great hall: almost every wall knocked through
      for (int z = 0; z < H; ++z)
        for (int x = 0; x < W; ++x) {
          if (!seam(x, z, PX) && rng.next() % 100 < 85) eWall[idx(x, z)] = 0;
          if (!seam(x, z, PZ) && rng.next() % 100 < 85) sWall[idx(x, z)] = 0;
          pillar[idx(x, z)] = 0;
        }
    } break;
    case Special::Office: {
      // The mural room: 5 x 4 tiles. Its north wall has a door at each end; behind each door a
      // metre-wide corridor runs straight north, much further than it should, then opens out.
      const int RW = 5, RD = 4, CL = 12;
      int x0 = W / 2 - 2, z0 = H / 2;
      for (int z = z0; z < z0 + RD; ++z)
        for (int x = x0; x < x0 + RW; ++x) {
          pillar[idx(x, z)] = 0;
          for (int d = 0; d < 4; ++d) {
            int nx = x + kDX[d], nz = z + kDZ[d];
            bool inside = nx >= x0 && nx < x0 + RW && nz >= z0 && nz < z0 + RD;
            setWall(x, z, d, inside ? 0 : 1);
          }
        }
      // one ordinary way out of the room on the south side, so it's not a dead end
      setWall(x0 + 2, z0 + RD - 1, PZ, 0);
      for (int side = 0; side < 2; ++side) {
        int cx = side == 0 ? x0 : x0 + RW - 1;
        setWall(cx, z0, NZ, 0);  // the doorway
        for (int k = 1; k <= CL; ++k) {
          int z = z0 - k;
          narrow[idx(cx, z)] = 1;
          pillar[idx(cx, z)] = 0;
          setWall(cx, z, PX, 1);
          setWall(cx, z, NX, 1);
          if (k < CL) setWall(cx, z, NZ, 0);
        }
        setWall(cx, z0 - CL, NZ, 0);  // and out the far end, into the rest of the offices
      }
      mural = idx(x0 + 2, z0);
      startX = x0 + 2;
      startZ = z0 + 2;
    } break;
    default: break;
  }
}

void Level::specialStart() {
  if (theme.special == Special::Park) {  // at the tables, looking at the court
    startX = park.x0 + 8; startZ = park.z1 - 3;
    startYawSet = true; startYaw = 0.0f;
    return;
  }
  if (theme.special == Special::Suburbs) {  // start out on open ground, not wedged between two houses
    auto clear = [&](int x, int z) {
      for (int dz = -2; dz <= 2; ++dz)
        for (int dx = -2; dx <= 2; ++dx) if (solid[idx(x + dx, z + dz)]) return false;
      return true;
    };
    for (int r = 0; r < W; ++r)
      for (int dz = -r; dz <= r; ++dz)
        for (int dx = -r; dx <= r; ++dx)
          if (clear(startX + dx, startZ + dz)) { startX = wx(startX + dx); startZ = wz(startZ + dz); return; }
  }
  if (theme.special == Special::Office && mural >= 0) {
    startX = mural % W;
    startZ = mural / W + 2;  // the middle of the room, looking at the mural
    startYaw = 0.0f;         // facing -z
    startYawSet = true;
  }
}

void Level::specialProps(Rng& rng) {
  if (theme.special == Special::Park) {
    for (int z = park.z0; z <= park.z1; ++z)
      for (int x = park.x0; x <= park.x1; ++x) {
        if (!isBed(x, z)) continue;
        addProp(x == park.crevX && z == park.crevZ ? PR_TRAMPGAP : PR_TRAMP, tileCenter(x, z), 0, 0, 0, 0);
      }
    // tables and chairs for the parents, a row of cubbies for shoes along the side wall
    for (int k = 0; k < 4; ++k) {
      vec3 c = tileCenter(park.x0 + 3 + k * 3, park.z1 - 1);
      addProp(PR_TABLE, c, 0, 0, 0.5f, 0.3f);
      addProp(PR_CHAIR, c + vec3{0, 0, -0.7f}, kPi, 0, 0.25f, 0.25f);
      addProp(PR_CHAIR, c + vec3{0, 0, 0.7f}, 0.1f, 0, 0.25f, 0.25f);
    }
    for (int z = park.z0 + 6; z <= park.z1 - 1; ++z) {
      vec3 c = tileCenter(park.x0, z) + vec3{-0.62f, 0, 0};
      addProp(PR_LOCKER, c, -kPi * 0.5f, 0, 0.28f, 0.28f);
      addProp(PR_LOCKER, c + vec3{0, 0, 0.6f}, -kPi * 0.5f, 0, 0.28f, 0.28f);
    }
    return;
  }
  auto dropPropsIn = [&](auto pred) {
    std::vector<PropInstance> keep;
    for (const PropInstance& p : props) {
      int tx = (int)std::floor(p.pos.x / kTile), tz = (int)std::floor(p.pos.z / kTile);
      if (!pred(wx(tx), wz(tz))) keep.push_back(p);
    }
    props.swap(keep);
    propsAtTile.assign(W * H, {});
    for (size_t i = 0; i < props.size(); ++i) {
      int tx = (int)std::floor(props[i].pos.x / kTile), tz = (int)std::floor(props[i].pos.z / kTile);
      propsAtTile[idx(tx, tz)].push_back((int)i);
    }
  };
  switch (theme.special) {
    case Special::Office: {
      int mx0 = mural >= 0 ? mural % W : -99, mz0 = mural >= 0 ? mural / W : -99;
      // nothing in the corridors, and the mural room stays empty like the video: just carpet
      dropPropsIn([&](int x, int z) { return isNarrow(x, z) || (x >= mx0 - 2 && x <= mx0 + 2 && z >= mz0 && z <= mz0 + 3); });
      // most of the corridor lights are dead
      for (int i = 0; i < W * H; ++i)
        if (narrow[i] && lightAtTile[i] >= 0 && rng.next() % 100 < 75) lights[lightAtTile[i]].kind = 2;
      if (mural < 0) break;
      int mx = mural % W, mz = mural / W;
      // a doorway at each end of each corridor: wall strips narrow the opening to a door
      for (int side = 0; side < 2; ++side) {
        int cx = side == 0 ? mx - 2 : mx + 2;
        for (int end = 0; end < 2; ++end) {
          float ez = end == 0 ? mz * kTile : (mz - 12) * kTile;  // the edge the doorway sits in
          float cxm = (cx + 0.5f) * kTile;
          for (int s = -1; s <= 1; s += 2) {
            vec3 at{cxm + s * 0.71f, 0, ez};
            addProp(PR_DOORSIDE, at, s > 0 ? 0.0f : kPi, 0, 0.21f, 0.09f);
          }
        }
        // the doors: the left one stands open into the room, the right one is pushed into its corridor
        float cxm = (cx + 0.5f) * kTile, ez = mz * kTile;
        if (side == 0) addProp(PR_DOORLEAF, {cxm - 0.46f, 0, ez + 0.02f}, -0.25f, 0, 0, 0);
        else addProp(PR_DOORLEAF, {cxm + 0.46f, 0, ez - 0.02f}, kPi + 0.15f, 0, 0, 0);
      }
    } break;
    case Special::Playplace: {
      dropPropsIn([&](int, int) { return false; });
      // hourglass pillars on a loose grid, a spiral slide in some of the gaps
      int n = 0;
      for (int gz = 2; gz < H - 2; gz += 5)
        for (int gx = 2; gx < W - 2; gx += 5) {
          int x = gx + (int)(rng.next() % 2), z = gz + (int)(rng.next() % 2);
          if (std::abs(x - startX) < 2 && std::abs(z - startZ) < 2) continue;
          vec3 c{x * kTile, 0, z * kTile};  // on a tile corner
          if ((n++ % 4) == 3) addProp(PR_SPIRAL, c, rng.range(0, 6.28f), 0, 0.3f, 0.3f);
          else {
            addProp(PR_HOURGLASS, c, rng.range(0, 6.28f), 0, 0.82f, 0.82f);
            props.back().variant = (rng.next() % 4 == 0) ? 1 : 0;  // the odd yellow cushion
          }
        }
    } break;
    case Special::Suburbs: {
      dropPropsIn([&](int x, int z) { return solid[idx(x, z)] != 0; });
      // a house on every solid 3x3 block (find each block's top-left corner)
      for (int z = 0; z < H; ++z)
        for (int x = 0; x < W; ++x) {
          if (!solid[idx(x, z)] || solid[idx(x - 1, z)] || solid[idx(x, z - 1)]) continue;
          vec3 c{(x + 1.5f) * kTile, 0, (z + 1.5f) * kTile};
          float lo = 1e9f;
          for (int k = 0; k < 9; ++k) lo = std::min(lo, terrainH(c.x + (k % 3 - 1) * 2.9f, c.z + (k / 3 - 1) * 2.9f));
          c.y = lo - 0.15f;
          int quarter = (int)(rng.next() % 4);
          addProp(PR_HOUSE, c, quarter * kPi * 0.5f + rng.range(-0.04f, 0.04f), rng.range(-0.025f, 0.025f), 0, 0);
        }
    } break;
    case Special::Parking: {
      // cars nobody came back for, parked in the bays between the piers
      int cars = 0;
      for (int tries = 0; tries < 400 && cars < 26; ++tries) {
        int x = (int)(rng.next() % W), z = (int)(rng.next() % H);
        int i = idx(x, z);
        if (pillar[i] || solid[i] || pool[i] || !propsAtTile[i].empty() || (std::abs(x - startX) < 3 && std::abs(z - startZ) < 3)) continue;
        bool along = rng.next() % 2;
        vec3 c = tileCenter(x, z) + vec3{rng.range(-0.2f, 0.2f), 0, rng.range(-0.2f, 0.2f)};
        float yaw = (along ? 0.0f : kPi * 0.5f) + (rng.next() % 2 ? kPi : 0.0f) + rng.range(-0.06f, 0.06f);
        addProp(PR_CAR, c, yaw, 0, 0.9f, 2.1f);
        props.back().variant = (int)(rng.next() % 6);
        ++cars;
      }
    } break;
    default: break;
  }
}

void Level::specialDecals(Rng& rng) {
  switch (theme.special) {
    case Special::Office: {
      if (mural < 0) break;
      int mx = mural % W, mz = mural / W;
      Decal d;
      d.n = {0, 0, 1};
      d.pos = {(mx + 0.5f) * kTile, 1.72f, mz * kTile + kWallT * 0.5f + 0.006f};
      d.w = 4.6f; d.h = 4.6f * 384.0f / 1024.0f;
      d.kind = DECAL_MURAL;
      d.color = {1, 1, 1};
      decals.push_back(d);
    } break;
    case Special::Parking: {
      // a stencilled letter on each pier (A-H by area), and white bay lines between them
      for (int z = 0; z < H; ++z)
        for (int x = 0; x < W; ++x) {
          if (!pillar[idx(x, z)]) continue;
          int letter = ((x / 6) + (z / 6) * 3) % 8;
          vec3 c = tileCenter(x, z, 1.5f);
          for (int k = 0; k < 4; k += 2) {
            int d0 = (k + (x + z) % 2) % 4;
            vec3 n = dirV(d0);
            Decal dc;
            dc.n = n;
            dc.pos = c + n * (kPillar + 0.006f);
            dc.w = 0.42f; dc.h = 0.42f;
            dc.kind = DECAL_LETTER + letter;
            dc.color = {0.03f, 0.03f, 0.03f};
            decals.push_back(dc);
          }
          // bay lines run out from the pier
          for (int k = 0; k < 2; ++k) {
            vec3 along = k ? vec3{1, 0, 0} : vec3{0, 0, 1};
            if (rng.next() % 3 == 0) continue;
            Decal st;
            st.n = {0, 1, 0};
            st.right = along;
            st.pos = tileCenter(x, z, 0.004f) + along * (kPillar + 1.25f);
            st.w = 2.4f; st.h = 0.12f;
            st.kind = DECAL_STRIPE;
            st.color = {0.85f, 0.85f, 0.8f};
            decals.push_back(st);
          }
        }
    } break;
    default: break;
  }
}
