#include "render.h"
#include "../third_party/font8x8_basic.h"
#include <algorithm>
#include <cmath>
#include <cstdio>

static float gAniso = 1.0f;

QualityPreset qualityPreset(int q) {
  switch (q) {
    case 0: return {0.65f, 0, false, false, true, true};
    case 1: return {0.85f, 1024, true, true, true, true};
    default: return {1.0f, 2048, true, true, true, true};
  }
}

// ================================================================ shaders

static const char* kWorldVS = R"(#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNrm;
layout(location = 2) in vec2 aUV;
layout(location = 3) in vec2 aAux;
layout(location = 4) in vec4 aBones;
uniform mat4 uViewProj;
uniform mat4 uModel;
uniform int uSkinned;
uniform mat4 uBones[24];
out vec3 vPos;
out vec3 vNrm;
out vec3 vBind;
out vec2 vUV;
out vec2 vAux;
void main() {
  mat4 M = uModel;
  if (uSkinned == 1) {
    int i0 = int(aBones.x + 0.5), i1 = int(aBones.y + 0.5);
    M = uModel * (uBones[i0] * aBones.z + uBones[i1] * aBones.w);
  }
  vec4 wp = M * vec4(aPos, 1.0);
  vPos = wp.xyz;
  vNrm = mat3(M) * aNrm;
  vBind = aPos;
  vUV = aUV;
  vAux = aAux;
  gl_Position = uViewProj * wp;
}
)";

static const char* kShadowFS = R"(#version 330 core
void main() {}
)";

static const char* kWorldFS = R"(#version 330 core
in vec3 vPos;
in vec3 vNrm;
in vec3 vBind;
in vec2 vUV;
in vec2 vAux;
out vec4 oColor;

uniform sampler2D uAlbedo;
uniform sampler2D uLightmap;
uniform sampler2D uLightState;
uniform sampler2D uGrime;
uniform sampler2DShadow uSunShadow;
uniform int uSunOn;
uniform mat4 uSunVP;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform sampler2D uPoolMask;
uniform int uPoolOn;
uniform vec2 uPoolSize;
uniform sampler2DShadow uShadow;
uniform int uShadowOn;
uniform mat4 uShadowVP;
uniform int uMat;
uniform vec3 uTint;
uniform float uUVScale;
uniform int uWallFull;   // the wall texture is one picture from floor to ceiling (the park)
uniform int uCeilTiles;  // the ceiling is a suspended tile grid (stains stop at each tile's edge)
uniform float uBump;
uniform float uEmissive;
uniform float uRough;
uniform vec4 uRegion[8];
uniform float uSpecR[8];
uniform int uHuman;  // the sculpted model is a person (skin, eyes, hair, cloth get their own materials)
uniform vec3 uCamPos;
uniform vec4 uRipple[8];  // xz, birth time, strength
uniform vec3 uFlashPos;
uniform vec3 uFlashDir;
uniform float uFlash;
uniform vec3 uFogColor;
uniform float uFogDensity;
uniform float uTime;
uniform vec2 uLMSize;
uniform float uLMPerMeter;
uniform float uGlitch;
uniform float uWallH;
uniform vec3 uLightColor;
uniform float uGrimeAmt;
uniform int uFlipU;
uniform float uWetFloor;  // standing water in the damp patches
uniform vec3 uAmbient;    // sky light (outdoor levels)
uniform vec3 uBounce;     // colour light picks up bouncing off the walls
uniform sampler2D uIndirect;  // bounce light diffused round corners and down corridors (baked)
uniform sampler2D uWear;      // worn lanes in the floor (baked, same grid)
uniform vec2 uGISize;
uniform float uGIScale;
// --- ray tracing through the tile grid
uniform int uRT;
uniform int uRTSamples;      // shadow rays per light (2 or 4)
uniform float uAmbFloor;     // the faint light everywhere (lower: darkness is really dark)
uniform sampler2D uRTGrid;    // per tile: r = wall/pillar/solid/sky bits, gb = fixture index + 1
uniform sampler2D uRTLights;  // row 0: x y z intensity, row 1: state id, kind
uniform sampler2D uRTWall;
uniform sampler2D uRTCeil;
uniform vec2 uGridSize;
uniform vec2 uPanel;          // fixture half-size (x, z)
uniform vec4 uCaps[8];        // people and things: x, z, radius, top
uniform int uCapN;

const float PI = 3.14159265;

float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
float stateOf(float id) {
  int i = int(id + 0.5);
  return texelFetch(uLightState, ivec2(i & 63, i >> 6), 0).r;
}
float lmTexel(ivec2 c) {
  c = ivec2(mod(vec2(c), uLMSize));
  vec4 t = texelFetch(uLightmap, c, 0);
  return t.y * stateOf(t.x) + t.w * stateOf(t.z);
}
float lightAt(vec2 xz) {
  vec2 f = xz * uLMPerMeter - 0.5;
  vec2 i = floor(f);
  vec2 w = f - i;
  ivec2 c = ivec2(i);
  float a = lmTexel(c), b = lmTexel(c + ivec2(1, 0));
  float d = lmTexel(c + ivec2(0, 1)), e = lmTexel(c + ivec2(1, 1));
  return mix(mix(a, b, w.x), mix(d, e, w.x), w.y);
}
vec3 applyFog(vec3 c) {
  float dist = length(vPos - uCamPos);
  return mix(c, uFogColor, 1.0 - exp(-dist * uFogDensity));
}
float sunAt(vec3 wp, vec3 n) {
  if (uSunOn == 0) return 0.0;
  vec4 sp = uSunVP * vec4(wp + n * 0.035, 1.0);
  vec3 c = sp.xyz * 0.5 + 0.5;
  if (c.z >= 1.0) return 0.0;
  float s = 0.0;
  const float tx = 1.0 / 2048.0;
  for (int i = -1; i <= 1; ++i)
    for (int j = -1; j <= 1; ++j) s += texture(uSunShadow, vec3(c.xy + vec2(i, j) * tx * 1.25, c.z - 0.0004));
  return s / 9.0;
}
float shadowAt(vec3 wp, vec3 n) {
  if (uShadowOn == 0) return 1.0;
  vec4 sp = uShadowVP * vec4(wp + n * 0.025, 1.0);
  if (sp.w <= 0.0) return 1.0;
  vec3 c = sp.xyz / sp.w * 0.5 + 0.5;
  if (c.z > 1.0 || c.x < 0.0 || c.y < 0.0 || c.x > 1.0 || c.y > 1.0) return 1.0;
  vec2 ts = 1.0 / vec2(textureSize(uShadow, 0));
  float s = 0.0;
  for (int y = -1; y <= 1; ++y)
    for (int x = -1; x <= 1; ++x) s += texture(uShadow, vec3(c.xy + vec2(x, y) * ts * 1.5, c.z - 0.00025));
  return s / 9.0;
}
float D_GGX(float NoH, float a) {
  float a2 = a * a;
  float d = NoH * NoH * (a2 - 1.0) + 1.0;
  return a2 / (PI * d * d);
}
float V_Smith(float NoV, float NoL, float a) {
  float k = a * 0.5;
  return 0.25 / ((NoV * (1.0 - k) + k) * (NoL * (1.0 - k) + k));
}
vec3 F_Schlick(vec3 f0, float VoH) { return f0 + (1.0 - f0) * pow(clamp(1.0 - VoH, 0.0, 1.0), 5.0); }  // clamp: pow(<0) is NaN

// ================================================================ ray tracing
const float TILE = 2.0;
int cellR(ivec2 c) { return int(texelFetch(uRTGrid, ivec2(mod(vec2(c), uGridSize)), 0).r * 255.0 + 0.5); }
int cellLight(ivec2 c) {
  vec4 t = texelFetch(uRTGrid, ivec2(mod(vec2(c), uGridSize)), 0);
  return (int(t.g * 255.0 + 0.5) | (int(t.b * 255.0 + 0.5) << 8)) - 1;
}
vec2 wrapD(vec2 d) { vec2 w = uGridSize * TILE; return d - w * floor(d / w + 0.5); }

// Shadow ray from A to B: walls, pillars, solid fill, and (optionally) people.
float rtVisible(vec3 A, vec3 B, bool caps) {
  vec2 a = A.xz, d = B.xz - A.xz;
  ivec2 c = ivec2(floor(a / TILE));
  ivec2 e = ivec2(floor((a + d) / TILE));
  ivec2 st = ivec2(d.x >= 0.0 ? 1 : -1, d.y >= 0.0 ? 1 : -1);
  vec2 nb = (vec2(c) + vec2(st.x > 0 ? 1.0 : 0.0, st.y > 0 ? 1.0 : 0.0)) * TILE;
  vec2 tMax = vec2(abs(d.x) < 1e-5 ? 1e9 : (nb.x - a.x) / d.x, abs(d.y) < 1e-5 ? 1e9 : (nb.y - a.y) / d.y);
  vec2 tDel = TILE / max(abs(d), vec2(1e-5));
  float len2 = max(dot(d, d), 1e-6);
  for (int i = 0; i < 20; ++i) {
    int r = cellR(c);
    if (i > 0 && (r & 8) != 0) return 0.0;
    if ((r & 4) != 0) {
      vec2 cc = (vec2(c) + 0.5) * TILE;
      float t = clamp(dot(cc - a, d) / len2, 0.0, 1.0);
      vec2 q = a + d * t - cc;
      if (dot(q, q) < 0.105) return 0.0;
    }
    if (c == e) break;
    if (tMax.x < tMax.y) {
      if (tMax.x > 1.0) break;
      if ((cellR(ivec2(st.x > 0 ? c.x : c.x - 1, c.y)) & 1) != 0) return 0.0;
      c.x += st.x; tMax.x += tDel.x;
    } else {
      if (tMax.y > 1.0) break;
      if ((cellR(ivec2(c.x, st.y > 0 ? c.y : c.y - 1)) & 2) != 0) return 0.0;
      c.y += st.y; tMax.y += tDel.y;
    }
  }
  if (caps) {
    for (int k = 0; k < 8; ++k) {
      if (k >= uCapN) break;
      vec4 cp = uCaps[k];
      vec2 o = a + wrapD(cp.xy - a);
      float t = clamp(dot(o - a, d) / len2, 0.0, 1.0);
      vec2 q = a + d * t - o;
      if (t > 0.03 && dot(q, q) < cp.z * cp.z && mix(A.y, B.y, t) < cp.w) return 0.0;
    }
  }
  return 1.0;
}

// Keep a baked-light lookup on this side of any wall it's next to: the lightmap and the bounce are
// blended between neighbouring texels, and right against a wall that blend reaches into the room on
// the other side (a bright line along the bottom and top of every wall in a dark hall).
vec2 wallSafe(vec2 q) {
  if (uRT != 1) return q;
  vec2 cf = q / TILE;
  ivec2 c = ivec2(floor(cf));
  vec2 f = cf - vec2(c);
  const float m = 0.2;  // (fraction of a 2 m tile: 40 cm)
  if (f.x > 1.0 - m && (cellR(c) & 1) != 0) q.x -= (f.x - (1.0 - m)) * TILE + 0.02;
  if (f.x < m && (cellR(c - ivec2(1, 0)) & 1) != 0) q.x += (m - f.x) * TILE + 0.02;
  if (f.y > 1.0 - m && (cellR(c) & 2) != 0) q.y -= (f.y - (1.0 - m)) * TILE + 0.02;
  if (f.y < m && (cellR(c - ivec2(0, 1)) & 2) != 0) q.y += (m - f.y) * TILE + 0.02;
  return q;
}

// Direct light from every fixture nearby: real direction, falloff, soft shadows off the panel,
// and a proper specular highlight per light.
vec3 rtDirect(vec3 P, vec3 N, vec3 Ng, vec3 V, float a, vec3 f0, float specK, bool skin, bool caps, out vec3 specOut) {
  vec3 diff = vec3(0.0);
  specOut = vec3(0.0);
  ivec2 c0 = ivec2(floor(P.xz / TILE));
  float hh = max(1.5, uWallH - 0.4);
  float norm = (1.0 + 0.18 * hh * hh) / (1.0 + 0.18 * 6.25);
  float fr = fract(uTime * 7.31);
  vec2 jit = vec2(hash(gl_FragCoord.xy + fr * 91.0), hash(gl_FragCoord.yx * 1.37 + fr * 57.0)) * 2.0 - 1.0;
  vec3 A = P + Ng * 0.04;
  float NoV = max(dot(N, V), 1e-3);
  float aa = max(a, 0.09);
  int found = 0;
  // nearest first: ring by ring outward, so the twelve lights used are the twelve closest
  for (int ring = 0; ring <= 4; ++ring) {
    if (found >= 12) break;
    for (int k = 0; k < 81; ++k) {
      int i = k % 9 - 4, j = k / 9 - 4;
      if (max(abs(i), abs(j)) != ring) continue;
      if (found >= 12) break;
      int li = cellLight(c0 + ivec2(i, j));
      if (li < 0) continue;
      vec4 l0 = texelFetch(uRTLights, ivec2(li, 0), 0);
      vec4 l1 = texelFetch(uRTLights, ivec2(li, 1), 0);
      if (l1.y > 1.5) continue;  // dead fixture
      float stt = stateOf(l1.x);
      if (stt < 0.01) continue;
      vec3 lp = vec3(0.0, uWallH - 0.03, 0.0);
      lp.xz = P.xz + wrapD(l0.xz - P.xz);
      vec3 toL = lp - P;
      float d2 = dot(toL, toL);
      float w = l0.w * 2.2 * norm / (1.0 + 0.18 * d2) * stt;
      if (w < 0.012) continue;
      vec3 l = toL * inversesqrt(d2);
      // a troffer throws its light downward: walls get bright arcs under each fixture and fall off
      // between them, the ceiling right beside it stays dim
      // (a flat diffuser is close to Lambertian: its brightness falls with the cosine off straight down,
      // so light pools under each fixture and dies off sideways down a hall)
      float cosE = clamp(l.y, 0.0, 1.0);
      w *= 0.06 + 0.94 * cosE * (0.6 + 0.4 * cosE);
      float NoL = dot(N, l);
      float lam = skin ? max((NoL + 0.4) / 1.4, 0.0) : max(NoL, 0.0);
      if (lam <= 0.0) continue;
      ++found;
      // soft shadows: aim at random points on the panel (the tape grain eats the noise)
      // the diffuser spreads the light wider than the tube: soft, wide penumbrae
      // stratified over the diffuser: one ray into each quarter of it (or two halves), jittered inside its cell,
      // so the penumbra is smooth instead of speckled
      vec2 ext = vec2(uPanel.x + 0.08, uPanel.y + 0.08);  // the diffuser itself: crisp shadows close to things, softer further off
      float vis = 0.0;
      int ns = w > 0.08 ? uRTSamples : 1;
      for (int q = 0; q < 4; ++q) {
        if (q >= ns) break;
        vec2 cell = ns >= 4 ? vec2(float(q & 1), float(q >> 1)) * 2.0 - 1.0 : (ns == 2 ? vec2(q == 0 ? -1.0 : 1.0, q == 0 ? -1.0 : 1.0) : vec2(0.0));
        vec2 jq = vec2(hash(jit + float(q) * 1.7), hash(jit.yx + float(q) * 2.9)) - 0.5;
        vec2 oo = (cell * 0.5 + jq * (ns == 1 ? 2.0 : 1.0)) * ext;
        vis += rtVisible(A, lp + vec3(oo.x, 0.0, oo.y), caps);
      }
      vis /= float(ns);
      if (vis <= 0.0) continue;
      float rad = w * vis;
      diff += vec3(rad * lam);
      vec3 H = normalize(l + V);
      float nl = max(NoL, 0.0);
      specOut += D_GGX(max(dot(N, H), 0.0), aa) * V_Smith(NoV, nl, aa) * F_Schlick(f0, max(dot(V, H), 0.0)) * (specK * nl * rad);
    }
  }
  return diff;
}

vec3 rtWallColor(vec3 h, vec3 n, float along) {
  vec3 alb = pow(textureLod(uRTWall, vec2(along / TILE, 1.0 - h.y / uWallH), 2.0).rgb, vec3(2.2));  // explicit LOD: no derivatives in divergent code
  float hfw = mix(0.32, 1.05, pow(clamp(h.y / uWallH, 0.0, 1.0), 1.4));
  return alb * uLightColor * lightAt(h.xz + n.xz * 0.3) * hfw;
}

// Reflection ray: walls, pillars, the ceiling and its fixtures, sky through skylights.
vec3 rtReflect(vec3 O, vec3 R, out float tHit) {
  vec2 a = O.xz, d = R.xz;
  ivec2 c = ivec2(floor(a / TILE));
  ivec2 st = ivec2(d.x >= 0.0 ? 1 : -1, d.y >= 0.0 ? 1 : -1);
  vec2 nb = (vec2(c) + vec2(st.x > 0 ? 1.0 : 0.0, st.y > 0 ? 1.0 : 0.0)) * TILE;
  vec2 tMax = vec2(abs(d.x) < 1e-5 ? 1e9 : (nb.x - a.x) / d.x, abs(d.y) < 1e-5 ? 1e9 : (nb.y - a.y) / d.y);
  vec2 tDel = TILE / max(abs(d), vec2(1e-5));
  float tc = R.y > 0.001 ? (uWallH - 0.012 - O.y) / R.y : 1e9;
  tHit = 40.0;
  for (int i = 0; i < 24; ++i) {
    int r = cellR(c);
    float tNext = min(tMax.x, tMax.y);
    if ((r & 4) != 0) {  // pillar in this tile
      vec2 cc = (vec2(c) + 0.5) * TILE;
      vec2 oc = a - cc;
      float b = dot(oc, d), dd = dot(d, d), cq = dot(oc, oc) - 0.36 * 0.36;
      float disc = b * b - dd * cq;
      if (disc > 0.0) {
        float t = (-b - sqrt(disc)) / dd;
        if (t > 0.0 && t < tNext && t < tc) {
          vec3 h = O + R * t;
          vec3 n = vec3(normalize(h.xz - cc), 0.0).xzy;
          tHit = t;
          return rtWallColor(h, n, atan(n.z, n.x) * 0.36 + h.x);
        }
      }
    }
    if (tc < tNext) {  // the ceiling
      vec3 h = O + R * tc;
      tHit = tc;
      if ((r & 16) != 0) return uLightColor * vec3(1.0, 0.97, 0.9) * 2.5;  // skylight
      int li = cellLight(c);
      if (li >= 0) {
        vec4 l0 = texelFetch(uRTLights, ivec2(li, 0), 0);
        vec4 l1 = texelFetch(uRTLights, ivec2(li, 1), 0);
        vec2 q = abs(wrapD(h.xz - l0.xz));
        if (q.x < uPanel.x && q.y < uPanel.y) return uLightColor * vec3(1.0, 1.04, 1.14) * (0.03 + 7.0 * stateOf(l1.x)) * (l1.y > 1.5 ? 0.0 : 1.0);
        if (q.x < uPanel.x + 0.04 && q.y < uPanel.y + 0.04) return vec3(0.02);  // the frame
      }
      vec3 alb = pow(textureLod(uRTCeil, h.xz / TILE, 2.0).rgb, vec3(2.2));
      return alb * uLightColor * lightAt(h.xz) * 0.26;
    }
    if (tNext > 40.0) break;
    if (tMax.x < tMax.y) {
      bool wall = (cellR(ivec2(st.x > 0 ? c.x : c.x - 1, c.y)) & 1) != 0;
      c.x += st.x;
      if (wall || (cellR(c) & 8) != 0) { vec3 h = O + R * tMax.x; tHit = tMax.x; return rtWallColor(h, vec3(-float(st.x), 0.0, 0.0), h.z); }
      tMax.x += tDel.x;
    } else {
      bool wall = (cellR(ivec2(c.x, st.y > 0 ? c.y : c.y - 1)) & 2) != 0;
      c.y += st.y;
      if (wall || (cellR(c) & 8) != 0) { vec3 h = O + R * tMax.y; tHit = tMax.y; return rtWallColor(h, vec3(0.0, 0.0, -float(st.y)), h.x); }
      tMax.y += tDel.y;
    }
  }
  return uFogColor;
}
vec3 rtReflectFogged(vec3 O, vec3 R) {
  float t;
  vec3 c = rtReflect(O, R, t);
  return mix(c, uFogColor, 1.0 - exp(-t * uFogDensity));
}

void main() {
  vec3 Ng = normalize(vNrm);
  vec4 tex = (uWallFull == 1 && uMat == 0) ? texture(uAlbedo, vec2(vUV.x * 0.5, 1.0 - clamp(vPos.y / uWallH, 0.002, 0.998)))
                                           : texture(uAlbedo, vUV * uUVScale);
  bool inPit = (uMat == 0 || uMat == 1) && vAux.y > 0.5 && vPos.y < 0.0;  // the sides and bottom of a hole in the floor (tagged when built)
  if (uMat == 0 && inPit) tex = vec4(textureLod(uAlbedo, vUV * uUVScale, 9.0).rgb * 0.92, 0.5);  // inside a pit: bare plaster, no paper

  if (uMat == 3) {  // fluorescent panel
    float s = stateOf(vAux.y);
    // no two tubes match: an old greenish one here, a warm replacement there, ends going dark
    float hid = fract(sin(vAux.y * 12.9898 + 4.1) * 43758.5453);
    vec3 tube = hid < 0.16 ? vec3(0.9, 1.05, 0.86) : (hid < 0.28 ? vec3(1.07, 0.96, 0.84) : (hid < 0.34 ? vec3(0.8, 0.8, 0.8) : vec3(1.0)));
    float ends = 0.82 + 0.18 * smoothstep(0.0, 0.12, min(vUV.y, 1.0 - vUV.y));
    // (vAux.x: how much of the lens's light reaches this part: 1 on the lens, less down a troffer's inner sides)
    vec3 e = uLightColor * vec3(1.0, 1.04, 1.14) * tube * ends * tex.r * (0.03 + 7.0 * s) * vAux.x;
    // switched off it isn't a black hole: milky plastic and white steel, lit by the room like the ceiling round it
    vec3 amb = vec3(0.7, 0.7, 0.68) * uLightColor * (0.015 + 0.16 * lightAt(vPos.xz)) * (0.75 + 0.25 * tex.r);
    e += amb * (1.0 - clamp(s, 0.0, 1.0));
    oColor = vec4(applyFog(e), 1.0);
    return;
  }
  if (uMat == 9) {  // water: animated normals, fresnel mirror of the ceiling, deep teal body
    vec2 p = vPos.xz;
    float t = uTime;
    vec3 n = normalize(vec3(
        sin(p.x * 3.1 + t * 1.3) * 0.022 + sin((p.x + p.y) * 5.7 - t * 1.9) * 0.012 + (texture(uGrime, p / 6.0 + t * 0.02).r - 0.5) * 0.06,
        1.0,
        cos(p.y * 2.7 - t * 1.1) * 0.022 + sin((p.x - p.y) * 6.3 + t * 2.3) * 0.012 + (texture(uGrime, p / 6.0 - t * 0.017).g - 0.5) * 0.06));
    // expanding rings from footsteps, splashes and whatever else is wading nearby
    float foam = 0.0;
    for (int k = 0; k < 8; ++k) {
      vec4 r = uRipple[k];
      if (r.w <= 0.0) continue;
      float age = t - r.z;
      if (age < 0.0 || age > 3.5) continue;
      vec2 dv = p - r.xy;
      float dd = length(dv);
      float front = age * 1.4;
      float ring = sin((dd - front) * 15.0) * exp(-abs(dd - front) * 3.5) * exp(-age * 1.1) * r.w;
      n.xz += (dd > 0.001 ? dv / dd : vec2(0.0)) * ring * 0.35;
      foam += max(ring, 0.0) * 0.35;
    }
    n = normalize(n);
    vec3 V = normalize(uCamPos - vPos);
    float fres = 0.02 + 0.98 * pow(clamp(1.0 - dot(n, V), 0.0, 1.0), 5.0);
    vec3 R = reflect(-V, n);
    vec3 cp = vPos + R * ((uWallH - vPos.y) / max(R.y, 0.08));
    float Lc = lightAt(cp.xz);
    float Lh = lightAt(p);
    vec3 refl = uLightColor * vec3(0.8, 0.95, 1.0) * (Lc * 0.3 + pow(max(Lc - 0.6, 0.0), 2.0) * 1.2 + pow(max(Lc - 0.9, 0.0), 1.5) * 2.5);
    if (uRT == 1) refl = rtReflectFogged(vPos + vec3(0.0, 0.01, 0.0), R) * vec3(0.85, 0.97, 1.0);  // traced: walls, pillars, fixtures
    fres *= 0.7;
    // looking straight down you see the tiles; at a glance it's all teal
    vec3 body = mix(vec3(0.02, 0.24, 0.28), vec3(0.01, 0.12, 0.16), clamp(1.0 - V.y, 0.0, 1.0)) * (0.25 + Lh * 0.75);
    vec3 col = mix(body, refl, fres);
    vec3 Lu = vec3(0.0, 1.0, 0.0);
    vec3 H = normalize(Lu + V);
    col += uLightColor * Lh * pow(max(dot(n, H), 0.0), 220.0) * 2.5;
    if (uFlash > 0.0) {
      vec3 l = normalize(uFlashPos - vPos);
      float spot = smoothstep(0.80, 0.955, dot(-l, uFlashDir));
      col += vec3(1.0, 0.95, 0.86) * uFlash * spot * pow(max(dot(n, normalize(l + V)), 0.0), 180.0) * 3.0;
    }
    col += vec3(0.75, 0.85, 0.9) * foam * (0.3 + Lh);
    float sunAlpha = 1.0;
    if (uSunOn == 1) {
      // sunlit water goes clear and bright green, and throws glints
      float sv = sunAt(vPos, vec3(0.0, 1.0, 0.0));
      vec3 Hs = normalize(uSunDir + V);
      col += uSunColor * sv * (pow(max(dot(n, Hs), 0.0), 600.0) * 6.0 + vec3(0.07, 0.22, 0.17) * 0.4);
      sunAlpha = 1.0 - 0.45 * sv;
    }
    // tiny glints where the surface catches a fixture
    float gl = texture(uGrime, p * 1.7 + vec2(t * 0.11, -t * 0.07)).b * texture(uGrime, p * 2.3 - vec2(t * 0.09, t * 0.13)).r;
    col += uLightColor * Lh * smoothstep(0.47, 0.5, gl) * 0.25;
    if (any(isnan(col)) || any(isinf(col))) col = vec3(0.0);
    oColor = vec4(applyFog(col), mix(0.64, 0.97, max(fres * 1.3, clamp(1.0 - V.y, 0.0, 1.0) * 0.6)) * sunAlpha);
    return;
  }
  if (uMat == 10) {  // windows and doors to the night outside: self-lit image
    if (tex.a < 0.02) discard;  // round cut-outs (slide holes, tunnel mouths); other screens keep detail in alpha
    vec3 c = tex.rgb * tex.rgb * (0.04 + uEmissive) + tex.rgb * lightAt(vPos.xz) * 0.08;
    oColor = vec4(applyFog(c), 1.0);
    return;
  }
  if (uMat == 6) {  // the thin place: inside the blue tape the wall goes soft, a darkness that breathes
    float edge = smoothstep(0.0, 0.3, min(min(vUV.x, 1.0 - vUV.x), min(vUV.y, 1.0 - vUV.y)));
    vec2 q = vUV * vec2(3.0, 6.0);
    float swirl = texture(uGrime, q * 0.21 + vec2(uTime * 0.013, -uTime * 0.02)).r * texture(uGrime, q * 0.13 - vec2(uTime * 0.01, uTime * 0.017)).g;
    vec3 c = vec3(0.015, 0.016, 0.02) * (0.6 + swirl);
    oColor = vec4(applyFog(c), edge * uGlitch * (0.65 + 0.7 * swirl));
    return;
  }

  vec3 albedo;
  float rough = uRough;
  float specK = 1.0;
  vec3 emissive = vec3(0.0);
  float ao = vAux.x;
  bool skin = false;

  float outAlpha = 1.0;
  float clothAmt = 0.0, hairAmt = 0.0;  // people: fabric sheen, hair sheen
  float modelH = -1.0;  // sculpted models: fine surface relief (pores, grain, dents) in metres
  if (uMat == 8) {  // spray paint
    vec2 duv = vec2(uFlipU == 1 ? 1.0 - vUV.x : vUV.x, vUV.y);
    outAlpha = texture(uAlbedo, duv).a * 0.92;
    if (outAlpha < 0.01) discard;
    albedo = uTint.x < 0.0 ? pow(texture(uAlbedo, duv).rgb, vec3(2.2)) : uTint;  // negative tint: full-colour decal (the mural)
    rough = 0.55;
  } else if (uMat == 5) {  // sculpted model: region colours + bind-space detail
    int r = int(vAux.y + 0.5);
    vec4 rc = uRegion[r];
    vec3 g = texture(uGrime, vBind.xy * 2.1 + vBind.z * 1.3).rgb;
    vec3 g2 = texture(uGrime, vBind.zy * 5.3).rgb;
    albedo = rc.rgb * (0.84 + 0.32 * g.g) * mix(1.0, 0.86, g2.b);  // wear and grime, not granite
    vec3 g3 = texture(uGrime, vBind.xy * 9.0 + vBind.z * 4.3).rgb;
    vec3 g4 = texture(uGrime, vBind.zx * 23.0 + vBind.y * 7.1).rgb;
    modelH = g.g * 0.0011 + g3.r * 0.0007 + g4.g * 0.00035;
    albedo *= 0.92 + 0.16 * g3.g;
    if (uHuman == 3) { albedo = rc.rgb * (0.96 + 0.08 * g.g); modelH *= 0.25; }  // painted drywall and door casing: flat paint, not stone
    emissive = rc.rgb * rc.a;
    float sp = uSpecR[r];
    rough = clamp(0.85 - sp * 0.42, 0.12, 0.95);
    specK = 0.4 + sp;
    skin = (r == 0);
    if (uHuman == 0 && sp >= 0.75 && rc.a <= 0.0) {
      // painted steel and glossy plastic (lockers, coolers, fixtures): smooth paint, a few scuffs, not stone
      albedo = rc.rgb * (0.95 + 0.1 * g.g) * mix(1.0, 0.9, smoothstep(0.6, 0.8, g4.r));
      modelH *= 0.18;
    }
    if (uHuman == 1 || uHuman == 2) {
      // ---- people: real materials instead of one flat colour per part
      vec3 bp = vBind;  // bind-pose position, metres (feet at 0, crown ~1.8; a child's ~1.25)
      bool kid = uHuman == 2;  // the children have their own faces (creatures.cpp kid::head)
      float mpp = length(fwidth(vPos));
      float nearD = 1.0 - smoothstep(0.0015, 0.006, mpp);
      if (r == 0) {
        // skin: even, not blotchy; blood close under it in the cheeks, nose, ears, lips and knuckles
        albedo = rc.rgb * (0.94 + 0.12 * g.g) * mix(1.0, 0.92, g2.b * 0.5);
        float cheek, nose, ear, lips, hands, under, stubble, tz;
        if (kid) {  // rosy round cheeks, no stubble, no bags under the eyes
          cheek = exp(-pow(length(vec2(abs(bp.x) - 0.036, bp.y - 1.097)) / 0.022, 2.0)) * step(bp.z, -0.05) * 1.6;
          nose = exp(-pow(length(bp - vec3(0.0, 1.109, -0.09)) / 0.015, 2.0));
          ear = exp(-pow(length(vec2(abs(bp.x) - 0.071, bp.y - 1.131)) / 0.022, 2.0)) * step(0.05, abs(bp.x));
          lips = exp(-pow(length(vec2(bp.x / 1.7, bp.y - 1.0794)) / 0.0095, 2.0)) * step(bp.z, -0.077);
          hands = smoothstep(0.62, 0.58, bp.y) * smoothstep(0.47, 0.5, bp.y) * step(0.125, abs(bp.x));
          under = exp(-pow(length(vec2(abs(bp.x) - 0.0265, bp.y - 1.125)) / 0.012, 2.0)) * step(bp.z, -0.06) * 0.3;
          stubble = 0.0;
          tz = smoothstep(1.16, 1.19, bp.y) * exp(-pow(bp.x / 0.03, 2.0)) * step(bp.z, -0.05) * 0.6;
        } else {
          cheek = exp(-pow(length(vec2(abs(bp.x) - 0.05, bp.y - 1.675)) / 0.024, 2.0)) * step(bp.z, -0.06);
          nose = exp(-pow(length(bp - vec3(0.0, 1.674, -0.122)) / 0.02, 2.0));
          ear = exp(-pow(length(vec2(abs(bp.x) - 0.085, bp.y - 1.69)) / 0.026, 2.0)) * step(0.06, abs(bp.x));
          lips = exp(-pow(length(vec2(bp.x / 1.7, bp.y - 1.648)) / 0.011, 2.0)) * step(bp.z, -0.098);
          hands = smoothstep(0.97, 0.9, bp.y) * smoothstep(0.7, 0.78, bp.y) * step(0.2, abs(bp.x));
          under = exp(-pow(length(vec2(abs(bp.x) - 0.034, bp.y - 1.697)) / 0.016, 2.0)) * step(bp.z, -0.08);
          stubble = smoothstep(1.66, 1.63, bp.y) * smoothstep(1.6, 1.62, bp.y) * step(bp.z, -0.03);
          tz = smoothstep(1.66, 1.7, bp.y) * exp(-pow(bp.x / 0.035, 2.0)) * step(bp.z, -0.05);
        }
        float flush = clamp(cheek * 0.3 + nose * 0.3 + ear * 0.45 + hands * 0.25, 0.0, 1.0);
        albedo *= mix(vec3(1.0), vec3(1.13, 0.86, 0.82), flush);
        albedo = mix(albedo, albedo * vec3(0.88, 0.66, 0.64), lips * 0.6);
        albedo *= mix(vec3(1.0), vec3(0.9, 0.85, 0.86), under * 0.35);  // a little shadow-violet under the eyes
        stubble *= 1.0 - lips;
        albedo *= 1.0 - stubble * 0.06 * texture(uGrime, bp.xy * 40.0).r;
        // oily T-zone: forehead and down the nose catch a soft highlight
        rough = mix(0.55, 0.33, tz);
        specK = 0.45 + 0.5 * tz;
        modelH += (texture(uGrime, bp.xy * 31.0 + bp.z * 17.0).g - 0.5) * 0.00025 * nearD;  // pores
      } else if (r == 7 && bp.y > (kid ? 1.1 : 1.65)) {
        // the whites of the eyes: not paper white, a little pink at the corners, wet
        albedo = vec3(0.74, 0.69, 0.64);
        rough = 0.06; specK = 2.4;
      } else if (r == 1 && (kid ? (bp.y > 1.124 && bp.y < 1.15 && bp.z < -0.068 && abs(bp.x) < 0.041 && abs(bp.x) > 0.012)
                                 : (bp.y > 1.69 && bp.y < 1.725 && bp.z < -0.098 && abs(bp.x) < 0.05 && abs(bp.x) > 0.015))) {
        // iris and pupil, glossy, so the room's lights show in them
        float d = kid ? length(vec2(abs(bp.x) - 0.0265, bp.y - 1.137)) : length(vec2(abs(bp.x) - 0.033, bp.y - 1.708));
        albedo = mix(vec3(0.004), mix(vec3(0.16, 0.1, 0.05), vec3(0.08, 0.05, 0.03), smoothstep(0.003, 0.0065, d)), smoothstep(0.0022, 0.003, d));
        rough = 0.04; specK = 3.0;
      } else if (r == 1) {
        // hair: strands, lighter tips, a soft sheen
        float strand = texture(uGrime, vec2(bp.x * 70.0 + bp.z * 30.0, bp.y * 5.0 + bp.z * 3.0)).r;
        albedo = rc.rgb * (0.7 + 0.6 * strand);
        rough = 0.42; specK = 0.9;
        hairAmt = 1.0;
        modelH += (strand - 0.5) * 0.0006 * nearD;
      } else if (r == 2 || r == 3 || r == 5) {
        // fabric: a fine weave up close, lint, a soft sheen at a glance, and the colour gone at the creases
        float weave = texture(uGrime, bp.xy * 58.0 + bp.z * 21.0).g;
        albedo = rc.rgb * (0.92 + 0.16 * mix(0.5, weave, nearD)) * mix(1.0, 0.88, g2.b * 0.6);
        bool denim = r == 3 && rc.b > rc.r * 1.35 && rc.b > 0.12;
        if (denim) {
          // jeans: diagonal twill, white weft showing through, worn pale on the thighs and knees
          float tw = fract((bp.y * 1.0 + bp.x * 0.45 + bp.z * 0.45) * 160.0);
          float twill = mix(0.5, smoothstep(0.35, 0.5, tw) * smoothstep(0.85, 0.65, tw), nearD);
          float thighY = kid ? 0.45 : 0.72, kneeY = kid ? 0.33 : 0.52, ws = kid ? 0.62 : 1.0;
          float worn = exp(-pow((bp.y - thighY) / (0.14 * ws), 2.0)) * step(bp.z, -0.01) + exp(-pow((bp.y - kneeY) / (0.05 * ws), 2.0)) * 0.8 * step(bp.z, -0.02);
          worn *= 0.6 + 0.4 * texture(uGrime, bp.xy * 6.0).r;
          albedo = mix(albedo, albedo * 1.3 + vec3(0.02, 0.025, 0.035), clamp(worn, 0.0, 1.0) * 0.45);
          albedo *= 0.9 + 0.2 * twill;
        }
        rough = 0.88; specK = 0.25;
        clothAmt = 1.0;
        modelH += (weave - 0.5) * 0.00018 * nearD;
      } else if (r == 4 && kid) {  // grip socks: knit, a little grey on the soles
        float knit = texture(uGrime, vec2(bp.x * 90.0 + bp.z * 40.0, bp.y * 150.0)).g;
        albedo = rc.rgb * (0.84 + 0.26 * mix(0.5, knit, nearD)) * mix(0.62, 1.0, smoothstep(0.004, 0.02, bp.y));
        rough = 0.92; specK = 0.2;
        clothAmt = 1.0;
      } else if (r == 4) {  // shoes: scuffed
        albedo *= 0.85 + 0.3 * texture(uGrime, bp.xz * 22.0).g;
      }
    }
  } else if (uMat == 7) {  // trim palette: baseboard, metal, outlet plate, vent, slot
    int k = int(vAux.y + 0.5);
    vec3 pal[11] = vec3[11](vec3(0.30, 0.25, 0.15), vec3(0.50, 0.50, 0.48), vec3(0.70, 0.67, 0.56), vec3(0.06, 0.06, 0.06),
                          vec3(0.01), vec3(0.22, 0.11, 0.06), vec3(0.42, 0.22, 0.10),
                          vec3(0.55, 0.035, 0.03),   // 7 fire-alarm red
                          vec3(0.62, 0.62, 0.6),     // 8 chrome (sprinkler heads)
                          vec3(0.82, 0.81, 0.77),    // 9 smoke-detector white
                          vec3(0.6, 0.47, 0.22));    // 10 honey oak (the rail along the wall)
    albedo = pal[clamp(k, 0, 10)];
    if (k == 10) albedo *= 0.85 + 0.3 * texture(uGrime, vec2((vPos.x + vPos.z) * 3.0, vPos.y * 40.0)).g;  // grain
    if (k == 5) albedo *= 0.7 + 0.6 * texture(uGrime, vPos.xz * 0.7 + vPos.y).r;
    rough = (k == 1 || k == 8) ? 0.3 : (k == 6 || k == 10 ? 0.32 : (k == 7 ? 0.35 : 0.6));
    specK = (k == 1 || k == 6 || k == 8) ? 1.5 : (k == 7 || k == 10 ? 0.9 : 0.6);
  } else {
    albedo = pow(tex.rgb, vec3(2.2)) * uTint;
  }

  float damp = 0.0;
  float detailH = 0.0;        // extra close-up relief added to the bump
  vec2 pileDir = vec2(0.0);   // carpet: which way the pile has been brushed
  float pileAmt = 0.0;
  if (uMat == 1) {
    vec4 g = texture(uGrime, vPos.xz / 12.0);
    damp = smoothstep(0.55, 0.78, g.r) * uGrimeAmt;
    // a damp patch dries from the edge in: a brown tide line round it, a grey-green bloom inside
    float tideD = smoothstep(0.5, 0.55, g.r) * (1.0 - smoothstep(0.56, 0.63, g.r)) * uGrimeAmt;
    albedo = mix(albedo, albedo * vec3(0.72, 0.62, 0.45), tideD * 0.6);
    albedo *= mix(vec3(1.0), vec3(0.9, 0.95, 0.84), damp);
    albedo *= mix(1.0, 0.55, damp);
    if (vPos.y > -0.3 && uRough > 0.88 && dot(uAmbient, uAmbient) < 1e-4) {  // a pile carpet (not tile, wood or concrete)
      // up close: tufts and single fibres, a little colour variation between them, matted flat where it's wet
      float mpp = length(fwidth(vPos.xz));
      float nearD = 1.0 - smoothstep(0.003, 0.016, mpp);
      vec4 f1 = texture(uGrime, vPos.xz * 3.3);
      vec4 f2 = texture(uGrime, vPos.xz * 12.7 + vec2(0.31, 0.77));
      float tuft = f1.g * 0.55 + f2.r * 0.45;
      albedo *= mix(1.0, 0.8 + 0.4 * tuft, nearD * (1.0 - damp * 0.7));
      albedo *= mix(vec3(1.0), vec3(1.0 + (f2.b - 0.5) * 0.06, 1.0, 1.0 - (f2.b - 0.5) * 0.06), nearD);
      detailH = (tuft - 0.5) * 0.3 * (1.0 - smoothstep(0.0012, 0.0035, mpp)) * (1.0 - damp);
      // the pile lies one way here and another there: vacuum stripes, the paths people walk
      vec2 q = vPos.xz / 7.0;
      vec2 pd = vec2(texture(uGrime, q).g - 0.5, texture(uGrime, q + vec2(0.5, 0.21)).b - 0.5);
      float stripe = sin(dot(vPos.xz, vec2(0.62, 0.78)) * 2.2 + texture(uGrime, vPos.xz / 15.0).r * 4.0);
      pileDir = normalize(pd + vec2(0.62, 0.78) * stripe * 0.22 + 1e-4);
      // (close up only: further off the brushing averages out, and as a pattern it turns into bands)
      pileAmt = (1.0 - damp * 0.8) * (1.0 - smoothstep(3.0, 9.0, length(vPos - uCamPos)));
    }
    albedo *= mix(1.0, 0.9 + 0.2 * g.g, uGrimeAmt);
    // worn lanes down the middle of the halls: pile crushed flat, a little paler and greyer
    float wearV = texture(uWear, vPos.xz / uGISize).r * (0.75 + 0.5 * texture(uGrime, vPos.xz / 1.7).g);
    albedo = mix(albedo, albedo * vec3(1.06, 1.04, 0.98) + vec3(0.01), clamp(wearV, 0.0, 1.0) * 0.5);  // (subtle: crushed pile, not paint)
    // old stains: blotches a shade darker with a darker tide line round them
    float stv = texture(uGrime, vPos.xz / 4.7 + vec2(0.37, 0.11)).b;
    float gs = max(uGrimeAmt, 0.35);
    float stain = smoothstep(0.68, 0.71, stv), tide = smoothstep(0.655, 0.675, stv) * (1.0 - smoothstep(0.675, 0.7, stv));
    albedo *= (1.0 - 0.22 * stain * gs) * (1.0 - 0.3 * tide * gs);
    damp = max(damp, wearV * 0.25);
    rough = mix(uRough, 0.5, damp);
    if (uWetFloor > 0.0) {  // puddles: dark, glassy, mirror the lights
      float pud = smoothstep(0.45, 0.7, g.r) * uWetFloor;
      rough = mix(rough, 0.03, pud);
      albedo *= mix(1.0, 0.45, pud);
      damp = max(damp, pud);
    }
    if (uPoolOn == 1 && vPos.y < -0.2) {  // caustics on a pool floor
      float c1 = texture(uGrime, vPos.xz / 3.0 + vec2(uTime * 0.03, uTime * 0.017)).r;
      float c2 = texture(uGrime, vPos.xz / 3.0 * 1.3 - vec2(uTime * 0.021, uTime * 0.027)).r;
      float caus = pow(1.0 - abs(c1 - c2) * 3.0, 6.0);
      albedo *= vec3(0.55, 0.85, 0.95);
      albedo += vec3(0.6, 0.9, 1.0) * max(caus, 0.0) * 0.3;
    }
  } else if (uMat == 0) {
    vec4 g = texture(uGrime, vec2(vPos.x + vPos.z, vPos.y * 0.6) / 12.0);
    albedo *= mix(1.0, mix(0.62, 1.0, smoothstep(0.0, 0.5, vPos.y)), uGrimeAmt);
    float drip = smoothstep(0.6, 0.8, texture(uGrime, vec2((vPos.x + vPos.z) * 0.375, vPos.y * 0.03)).r) * uGrimeAmt;
    albedo *= mix(1.0, 0.8, drip * smoothstep(uWallH * 0.4, uWallH, vPos.y));
    {  // here and there a leak has run down from the ceiling: a brown streak with a darker edge
      float wx = (vPos.x + vPos.z) * 0.9;
      float col0 = floor(wx);
      float lk = hash(vec2(col0, 41.0));
      if (lk < 0.09 * (0.4 + uGrimeAmt)) {
        float len = uWallH * (0.25 + 0.5 * hash(vec2(col0, 7.0)));
        float fx = fract(wx) - 0.5;
        float wid = 0.12 + 0.18 * hash(vec2(col0, 3.0)) - 0.08 * (uWallH - vPos.y) / max(len, 0.1);
        wid += (texture(uGrime, vec2(wx * 0.7, vPos.y * 0.35)).r - 0.5) * 0.12;
        float down = smoothstep(uWallH - len, uWallH - len * 0.6, vPos.y);
        float inS = smoothstep(wid, wid - 0.04, abs(fx)) * down;
        float edge = smoothstep(wid - 0.05, wid - 0.015, abs(fx)) * smoothstep(wid + 0.005, wid - 0.01, abs(fx)) * down;
        albedo *= mix(vec3(1.0), vec3(0.8, 0.66, 0.45), inS * 0.35 + edge * 0.45);
      }
    }
    albedo *= mix(1.0, 0.92 + 0.16 * g.g, uGrimeAmt);
    rough = mix(uRough, 0.55, drip);
    {  // up close: paper fibre and print grain, so a wall you're standing at doesn't go flat
      vec2 wq = vec2(vPos.x + vPos.z, vPos.y);
      float mpp = length(fwidth(wq));
      float nearD = 1.0 - smoothstep(0.002, 0.012, mpp);
      vec4 f = texture(uGrime, wq * 7.3 + vec2(0.13, 0.57));
      albedo *= mix(1.0, 0.93 + 0.14 * f.g, nearD);
      detailH = (f.r - 0.5) * 0.1 * (1.0 - smoothstep(0.0008, 0.0025, mpp));
      // dirt gathers along the bottom of the wall, where the vacuum and the mop never reach
      float foot = 1.0 - smoothstep(0.0, 0.35 + 0.25 * g.b, vPos.y);
      albedo *= mix(1.0, 0.84, foot * (0.3 + 0.7 * uGrimeAmt));
    }
  } else if (uMat == 2) {
    vec4 g = texture(uGrime, vPos.xz / 6.0);
    albedo *= mix(1.0, 0.7, smoothstep(0.62, 0.8, g.r) * uGrimeAmt);
    float mpp = length(fwidth(vPos.xz));
    float nearD = 1.0 - smoothstep(0.003, 0.014, mpp);
    vec4 f = texture(uGrime, vPos.xz * 6.1);
    albedo *= mix(1.0, 0.9 + 0.2 * f.g, nearD);  // the fissured mineral board, up close
    if (uCeilTiles == 1) {
      // Every tile is its own board: a few were replaced and are whiter, some have yellowed, and a
      // leak above leaves a brown ring stain that stops dead at the T-bar.
      vec2 tc = vUV * uUVScale * vec2(2.0, 1.0);
      vec2 tid = floor(tc), tl = fract(tc);
      float h1 = hash(tid + 17.3), h2 = hash(tid * 1.7 + 4.1), h3 = hash(tid * 2.3 + 9.7);
      if (h1 < 0.06) albedo *= vec3(1.07, 1.08, 1.14);          // a newer replacement tile
      else albedo *= mix(vec3(1.0), vec3(1.0, 0.96, 0.86), h2 * 0.6);  // yellowed with age
      if (h3 < 0.14 * (0.4 + uGrimeAmt)) {
        vec2 c = vec2(0.25 + 0.5 * hash(tid + 3.3), 0.2 + 0.6 * hash(tid + 5.5));
        float n = texture(uGrime, tl * vec2(0.6, 1.2) * 0.9 + tid * 0.37).r;
        float r = length((tl - c) * vec2(0.6, 1.2)) + (n - 0.5) * 0.12;
        float R = 0.12 + 0.2 * hash(tid + 8.8);
        float inside = smoothstep(R, R - 0.03, r);
        float ring = smoothstep(R - 0.035, R - 0.012, r) * smoothstep(R + 0.006, R - 0.006, r);
        float ring2 = smoothstep(R * 0.6 - 0.02, R * 0.6, r) * smoothstep(R * 0.6 + 0.012, R * 0.6, r);
        vec3 tea = vec3(0.72, 0.52, 0.3);
        albedo *= mix(vec3(1.0), tea, min(inside * 0.5 + ring * 0.8 + ring2 * 0.4, 1.0));
        detailH -= inside * 0.08;  // the board sags a little where it got wet
      }
    }
    detailH = (f.r - 0.5) * 0.2 * (1.0 - smoothstep(0.0012, 0.0035, mpp));
  }

  vec3 N = Ng;
  if (modelH >= 0.0) {  // the same surface-gradient bump, from the model's own relief
    vec3 dpdx = dFdx(vPos), dpdy = dFdy(vPos);
    float dhx = dFdx(modelH), dhy = dFdy(modelH);
    vec3 r1 = cross(dpdy, Ng), r2 = cross(Ng, dpdx);
    float det = dot(dpdx, r1);
    vec3 grad = sign(det) * (dhx * r1 + dhy * r2);
    vec3 nb = abs(det) * Ng - grad;
    if (dot(nb, nb) > 1e-12) N = normalize(nb);
  } else if (uBump > 0.0) {
    float h = tex.a + detailH;
    vec3 dpdx = dFdx(vPos), dpdy = dFdy(vPos);
    float dhx = dFdx(h), dhy = dFdy(h);
    vec3 r1 = cross(dpdy, Ng), r2 = cross(Ng, dpdx);
    float det = dot(dpdx, r1);
    vec3 grad = sign(det) * (dhx * r1 + dhy * r2);
    // (on a floor seen far off and edge-on the relief turns into bands where the texture steps down
    // a mip level: fade it out with distance there, it's below what you'd see anyway)
    float bumpFar = (uMat == 1) ? 1.0 - smoothstep(3.0, 8.0, length(vPos - uCamPos)) * smoothstep(0.35, 0.05, abs(dot(normalize(uCamPos - vPos), Ng))) : 1.0;
    vec3 nb = abs(det) * Ng - uBump * (1.0 - damp * 0.8) * bumpFar * grad;
    if (dot(nb, nb) > 1e-12) N = normalize(nb);
  }

  vec3 V = normalize(uCamPos - vPos);
  float NoV = max(dot(N, V), 1e-3);
  vec3 f0 = vec3(0.04);
  float a = rough * rough;

  // Ceiling fixtures: baked visibility + live state, light arriving from above.
  // where to look up the baked light: off a wall, step out from it; for things that face up or down
  // (trim, baseboard tops, the ceiling and floor along a wall) step toward the viewer, who is always on
  // the near side of the wall, so nothing picks up the light of the room behind it
  vec2 toCam = uCamPos.xz - vPos.xz;
  vec2 sideOff = abs(Ng.y) > 0.5 ? toCam * (0.3 / max(length(toCam), 0.3)) : Ng.xz;
  // (four taps a hand apart: each lightmap texel keeps only its two strongest fixtures, and where the
  // pair changes the light steps; averaging over a small patch blends those seams out)
  vec2 lq = wallSafe(vPos.xz + sideOff * 0.3);
  float L = 0.25 * (lightAt(lq + vec2(0.17, 0.11)) + lightAt(lq + vec2(-0.11, 0.17)) + lightAt(lq + vec2(-0.17, -0.11)) + lightAt(lq + vec2(0.11, -0.17)));
  float hf = 1.0;
  if (uMat == 0 || uMat == 7 || (uMat == 8 && Ng.y < 0.5)) hf = mix(0.32, 1.05, pow(clamp(vPos.y / uWallH, 0.0, 1.0), 1.4));
  else if (uMat == 2) hf = 0.26;
  else if (uMat == 4 || uMat == 5) hf = mix(0.45, 1.0, clamp(vPos.y / uWallH, 0.0, 1.0)) * (0.65 + 0.35 * max(N.y, 0.0));
  vec3 lightCol = uLightColor;
  float shade = (uMat == 0) ? (0.82 + 0.18 * dot(N, Ng)) : 1.0;
  bool rtLit = uRT == 1 && uMat != 2 && uMat != 3;
  vec3 col;
  vec3 rtSpec = vec3(0.0);
  float gloss = (uMat == 1 && vPos.y > -0.3) ? clamp(1.0 - rough * 1.3, 0.0, 1.0) : 0.0;
  if (rtLit) {
    // Traced direct light from the fixtures; the lightmap stays on as bounce light.
    vec3 dRT = rtDirect(vPos, N, Ng, V, a, f0, specK, skin, uMat != 5, rtSpec);
    // direct light traced; the bounce from the lightmap, tinted by the walls it bounced off
    col = albedo * lightCol * (dRT * mix(1.0, ao, 0.4) + uBounce * (L * 0.42 * hf * ao)) * shade;
    col += rtSpec * lightCol * (1.0 - gloss * 0.75);
    if (gloss > 0.02) {  // traced reflections on glossy and wet floors
      vec2 jr = (vec2(hash(gl_FragCoord.xy * 0.71 + fract(uTime) * 13.0), hash(gl_FragCoord.yx * 1.13 + fract(uTime * 1.3) * 7.0)) - 0.5) * rough * 0.45;
      vec3 Rr = normalize(reflect(-V, N) + vec3(jr.x, 0.0, jr.y));
      float F = F_Schlick(vec3(0.04), NoV).x;
      col += rtReflectFogged(vPos + Ng * 0.01, Rr) * F * gloss;
    }
  } else {
    col = albedo * lightCol * L * hf * shade * ao;
  }
  col += albedo * vec3(0.010, 0.009, 0.007) * ao * uAmbFloor;
  if (uGIScale > 0.0) {  // bounce light: off the floor up onto the ceiling, round corners, down the halls
    float gi = texture(uIndirect, wallSafe(vPos.xz + sideOff * 0.35) / uGISize).r;
    gi = gi / (1.0 + 1.2 * gi) * (1.0 - 0.6 * smoothstep(0.3, 1.6, L * hf));  // bounce matters most where the direct light doesn't reach
    float up = uMat == 2 ? 0.9 : (0.55 + 0.25 * (1.0 - abs(N.y)) + 0.2 * max(-N.y, 0.0));
    col += albedo * lightCol * uBounce * gi * up * ao * uGIScale;
  }
  col += albedo * uAmbient * (0.55 + 0.45 * N.y) * ao;  // open sky overhead
  if (uPoolOn == 1 && (uMat == 0 || uMat == 2 || uMat == 3 || uMat == 7)) {
    // caustics: light thrown up off moving water onto the ceiling and the walls around it
    float pm = texture(uPoolMask, (vPos.xz + Ng.xz * 0.6) / uPoolSize).r;
    if (pm > 0.01) {
      vec2 cp = vPos.xz + vec2(vPos.y * 0.37, -vPos.y * 0.21);
      float c1 = texture(uGrime, cp / 2.4 + vec2(uTime * 0.035, uTime * 0.021)).r;
      float c2 = texture(uGrime, cp / 2.4 * 1.31 - vec2(uTime * 0.026, uTime * 0.033)).r;
      float caus = pow(max(1.0 - abs(c1 - c2) * 4.0, 0.0), 10.0);
      float w = (uMat == 2 || uMat == 3) ? 1.0 : smoothstep(0.0, uWallH, vPos.y) * 0.8 + 0.2;
      col += albedo * lightCol * vec3(0.6, 0.9, 1.0) * caus * pm * (0.1 + L) * 0.14 * w;
    }
  }
  if (!rtLit) {  // overhead sheen: damp carpet, skin, metal
    vec3 Lu = normalize(vec3(0.15, 1.0, 0.1));
    vec3 H = normalize(Lu + V);
    float NoL = max(dot(N, Lu), 0.0);
    float aa = max(a, 0.08);
    vec3 spec = D_GGX(max(dot(N, H), 0.0), aa) * V_Smith(NoV, NoL, aa) * F_Schlick(f0, max(dot(V, H), 0.0));
    col += spec * NoL * lightCol * L * hf * ao * 0.35 * specK;
  }

  if (clothAmt > 0.0 || hairAmt > 0.0) {
    // cotton and wool scatter light at grazing angles: a soft pale rim round every sleeve and leg;
    // hair gets a broader sheen along the strands
    float graze = pow(1.0 - NoV, 3.0);
    vec3 lin = lightCol * (L * hf + 0.08) * ao;
    col += sqrt(max(albedo, 0.0)) * lin * graze * 0.12 * clothAmt;
    col += mix(albedo, vec3(0.5), 0.5) * lin * pow(max(dot(N, normalize(V + vec3(0.0, 1.0, 0.0))), 0.0), 12.0) * 0.12 * hairAmt;
  }
  if (skin && (uHuman == 1 || uHuman == 2)) {
    // light goes into skin and comes back out redder: the shadow side glows warm, edges go soft
    float back = max(-dot(N, normalize(vec3(0.15, 1.0, 0.1))), 0.0);
    col += albedo * vec3(0.9, 0.28, 0.18) * lightCol * L * hf * ao * (0.05 + 0.08 * back);
  }
  if (pileAmt > 0.0) {
    // pile carpet catches the light by angle: looking along the pile it's paler and soft-sheened,
    // against it darker; at a glance down a hall the whole floor goes velvety
    vec2 vx = normalize(V.xz + 1e-4);
    float along = dot(vx, pileDir);
    float graze = pow(1.0 - NoV, 2.5);
    col *= mix(1.0, 0.95 + 0.1 * (0.5 + 0.5 * along), pileAmt);
    col += sqrt(max(albedo, 0.0)) * lightCol * L * hf * ao * graze * (0.1 + 0.08 * along) * pileAmt;
  }
  if (uFlash > 0.0) {  // flashlight with shadow map
    vec3 toL = uFlashPos - vPos;
    float d = length(toL);
    vec3 l = toL / max(d, 1e-4);
    float cosA = dot(-l, uFlashDir);
    float spot = smoothstep(0.80, 0.955, cosA);
    float hot = smoothstep(0.965, 0.997, cosA) * 0.6;
    float ring = 0.95 + 0.05 * sin(acos(clamp(cosA, -1.0, 1.0)) * 40.0);
    float att = 1.0 / (1.0 + 0.30 * d + 0.10 * d * d);
    float sh = (spot > 0.0) ? shadowAt(vPos, Ng) : 0.0;
    vec3 rad = vec3(1.0, 0.95, 0.86) * uFlash * (spot * ring + hot) * att * sh;
    float NoL = max(dot(N, l), 0.0);
    float wrap = skin ? max((dot(N, l) + 0.45) / 1.45, 0.0) : NoL;
    vec3 H = normalize(l + V);
    vec3 F = F_Schlick(f0, max(dot(V, H), 0.0));
    vec3 spec = D_GGX(max(dot(N, H), 0.0), a) * V_Smith(NoV, NoL, a) * F * specK;
    col += albedo * rad * wrap * 1.7 * mix(1.0, ao, 0.5) + spec * rad * NoL;
    if (skin) col += albedo * vec3(0.9, 0.3, 0.2) * rad * max(-dot(N, l), 0.0) * 0.15;
  }

  if (uSunOn == 1) {  // sunlight through the skylights, with real shadows
    float NoLs = dot(N, uSunDir);
    if (NoLs > 0.0) {
      float vis = sunAt(vPos, Ng);
      if (vis > 0.0) {
        if (uPoolOn == 1 && vPos.y < -0.2) {  // under the water: the light arrives broken into caustics
          float c1 = texture(uGrime, vPos.xz / 1.6 + vec2(uTime * 0.05, uTime * 0.031)).r;
          float c2 = texture(uGrime, vPos.xz / 1.6 * 1.33 - vec2(uTime * 0.037, uTime * 0.045)).r;
          vis *= 0.45 + 2.2 * pow(max(1.0 - abs(c1 - c2) * 3.0, 0.0), 5.0);
        }
        vec3 Hs = normalize(uSunDir + V);
        vec3 Fs = F_Schlick(f0, max(dot(V, Hs), 0.0));
        vec3 specS = D_GGX(max(dot(N, Hs), 0.0), a) * V_Smith(NoV, NoLs, a) * Fs * specK;
        col += (albedo * NoLs * (skin ? 1.0 : 1.0) + specS * NoLs) * uSunColor * vis;
      }
    }
  }
  col += (uMat == 8 ? uTint : albedo) * uEmissive + emissive;
  // Down a pit (not a pool) the light from the ceiling dies fast: the bottom is nearly black.
  if (inPit && uMat != 9) col *= mix(1.0, 0.1, smoothstep(0.0, 0.3, -vPos.y)) * exp(vPos.y * 0.7);  // in shadow just under the lip, then darker and darker
  if (any(isnan(col)) || any(isinf(col))) col = vec3(0.0);  // one bad pixel must never bloom across the screen
  oColor = vec4(applyFog(col), outAlpha);
}
)";

static const char* kFullVS = R"(#version 330 core
out vec2 vUV;
void main() {
  vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
  vUV = p;
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
)";

static const char* kSsaoFS = R"(#version 330 core
in vec2 vUV;
out vec4 oColor;
uniform sampler2D uDepth;
uniform mat4 uProj;
uniform mat4 uInvProj;
uniform vec2 uFullRes;
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
vec3 viewPos(vec2 uv) {
  float d = texture(uDepth, uv).r;
  vec4 p = uInvProj * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
  return p.xyz / p.w;
}
void main() {
  float d0 = texture(uDepth, vUV).r;
  if (d0 >= 1.0) { oColor = vec4(1.0); return; }
  vec3 P = viewPos(vUV);
  vec2 t = 1.0 / uFullRes;
  vec3 l = viewPos(vUV - vec2(t.x, 0)), r = viewPos(vUV + vec2(t.x, 0));
  vec3 dn = viewPos(vUV - vec2(0, t.y)), up = viewPos(vUV + vec2(0, t.y));
  vec3 dx = abs(r.z - P.z) < abs(P.z - l.z) ? r - P : P - l;
  vec3 dy = abs(up.z - P.z) < abs(P.z - dn.z) ? up - P : P - dn;
  vec3 N = normalize(cross(dx, dy));
  if (dot(N, -P) < 0.0) N = -N;
  float rot = hash(gl_FragCoord.xy) * 6.2831;
  vec3 T = normalize(cross(N, abs(N.y) < 0.9 ? vec3(0, 1, 0) : vec3(1, 0, 0)));
  vec3 B = cross(N, T);
  const float radius = 0.5;
  const int S = 12;
  float occ = 0.0;
  for (int i = 0; i < S; ++i) {
    float fi = float(i) + 0.5;
    float ang = fi * 2.399 + rot;
    float z = fract(fi * 0.618 + hash(gl_FragCoord.yx));
    float rr = sqrt(1.0 - z * z);
    vec3 h = T * cos(ang) * rr + B * sin(ang) * rr + N * z;
    float sc = mix(0.15, 1.0, (fi / float(S)) * (fi / float(S)));
    vec3 s = P + h * radius * sc;
    vec4 c = uProj * vec4(s, 1.0);
    vec2 suv = c.xy / c.w * 0.5 + 0.5;
    if (suv.x < 0.0 || suv.y < 0.0 || suv.x > 1.0 || suv.y > 1.0) continue;
    float sz = viewPos(suv).z;
    float range = smoothstep(0.0, 1.0, radius / max(abs(P.z - sz), 1e-3));
    occ += (sz >= s.z + 0.025 * (1.0 + 0.35 * -P.z) ? 1.0 : 0.0) * range;  // bias grows with distance: no banding on surfaces seen edge-on
  }
  float ao = pow(clamp(1.0 - occ / float(S), 0.0, 1.0), 1.5);
  // further off, the depth buffer is too coarse to tell a flat floor seen edge-on from a crease: it
  // comes out as stripes across the floor. The baked corner shading covers the distance instead.
  ao = mix(ao, 1.0, smoothstep(3.5, 9.0, -P.z) * (0.35 + 0.65 * smoothstep(0.6, 0.9, abs(dot(N, normalize(-P))) < 0.35 ? 1.0 : 0.0)));
  ao = mix(ao, 1.0, smoothstep(4.0, 12.0, -P.z));
  oColor = vec4(ao, ao, ao, 1.0);
}
)";

static const char* kVolFS = R"(#version 330 core
in vec2 vUV;
out vec4 oColor;
uniform sampler2D uDepth;
uniform sampler2DShadow uShadow;
uniform sampler2D uLightmap;
uniform sampler2D uLightState;
uniform int uShadowOn;
uniform mat4 uInvViewProj;
uniform mat4 uShadowVP;
uniform vec3 uCamPos;
uniform vec3 uFlashPos;
uniform vec3 uFlashDir;
uniform float uFlash;
uniform vec2 uLMSize;
uniform float uLMPerMeter;
uniform float uTime;
uniform float uWallH;
uniform vec3 uLightColor;
uniform sampler2DShadow uSunShadow;
uniform int uSunOn;
uniform mat4 uSunVP;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
float sunVis(vec3 wp) {
  vec4 sp = uSunVP * vec4(wp, 1.0);
  vec3 c = sp.xyz * 0.5 + 0.5;
  if (c.x < 0.0 || c.y < 0.0 || c.x > 1.0 || c.y > 1.0 || c.z > 1.0) return 0.0;
  return texture(uSunShadow, vec3(c.xy, c.z - 0.0006));
}
float stateOf(float id) { int i = int(id + 0.5); return texelFetch(uLightState, ivec2(i & 63, i >> 6), 0).r; }
float lmT(ivec2 c) {
  c = ivec2(mod(vec2(c), uLMSize));
  vec4 t = texelFetch(uLightmap, c, 0);
  return t.y * stateOf(t.x) + t.w * stateOf(t.z);
}
float lightAt(vec2 xz) {  // (bilinear: no blocks in the haze)
  vec2 f = xz * uLMPerMeter - 0.5;
  vec2 i = floor(f), wq = f - i;
  ivec2 c = ivec2(i);
  return mix(mix(lmT(c), lmT(c + ivec2(1, 0)), wq.x), mix(lmT(c + ivec2(0, 1)), lmT(c + ivec2(1, 1)), wq.x), wq.y);
}
float shadowAt(vec3 wp) {
  if (uShadowOn == 0) return 1.0;
  vec4 sp = uShadowVP * vec4(wp, 1.0);
  if (sp.w <= 0.0) return 0.0;
  vec3 c = sp.xyz / sp.w * 0.5 + 0.5;
  if (c.x < 0.0 || c.y < 0.0 || c.x > 1.0 || c.y > 1.0 || c.z > 1.0) return 0.0;
  return texture(uShadow, vec3(c.xy, c.z - 0.0005));
}
void main() {
  float d = texture(uDepth, vUV).r;
  vec4 w = uInvViewProj * vec4(vUV * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
  vec3 wp = w.xyz / w.w;
  vec3 ray = wp - uCamPos;
  float len = min(length(ray), 22.0);
  vec3 dir = normalize(ray);
  const int N = 28;
  float stepLen = len / float(N);
  float jitter = hash(gl_FragCoord.xy + fract(uTime) * 61.0);
  float beam = 0.0, haze = 0.0, sun = 0.0;
  float cosS = dot(uSunDir, dir);
  const float gs = 0.55;
  float phaseS = (1.0 - gs * gs) / pow(1.0 + gs * gs - 2.0 * gs * cosS, 1.5) + 0.25;
  const float g = 0.35;
  for (int i = 0; i < N; ++i) {
    vec3 x = uCamPos + dir * (float(i) + jitter) * stepLen;
    float dust = 0.75 + 0.25 * sin(x.x * 2.7 + uTime * 0.2) * sin(x.z * 3.1 - uTime * 0.15) * sin(x.y * 4.3 + uTime * 0.1);
    if (uFlash > 0.0) {
      vec3 toL = uFlashPos - x;
      float dl = length(toL);
      vec3 l = toL / max(dl, 1e-3);
      float cone = smoothstep(0.80, 0.94, dot(-l, uFlashDir));
      if (cone > 0.0) {
        float att = 1.0 / (1.0 + 0.25 * dl + 0.08 * dl * dl);
        float cosT = dot(l, dir);
        float phase = (1.0 - g * g) / pow(1.0 + g * g - 2.0 * g * cosT, 1.5);
        beam += cone * att * shadowAt(x) * phase * dust;
      }
    }
    haze += lightAt(x.xz) * (0.35 + 0.65 * smoothstep(uWallH * 0.4, uWallH, x.y)) * dust * smoothstep(-1.0, 0.0, x.y);  // no lit haze down a hole
    if (uSunOn == 1) sun += sunVis(x) * dust;
  }
  vec3 c = vec3(1.0, 0.95, 0.86) * beam * uFlash * 0.010 + uLightColor * haze * 0.0045 + uSunColor * sun * phaseS * 0.0035;
  oColor = vec4(c * stepLen, 1.0);
}
)";

static const char* kCompFS = R"(#version 330 core
in vec2 vUV;
out vec4 oColor;
uniform sampler2D uScene;
uniform sampler2D uAO;
uniform sampler2D uVol;
uniform int uUseAO;
uniform int uUseVol;
uniform vec2 uHalfTexel;
uniform sampler2D uDepth;
uniform mat4 uInvVP, uVP, uPrevVP;
uniform vec3 uCamPos;
uniform float uGloss, uMotion;
uniform vec2 uTexel;
uniform int uSSR;
vec3 worldAt(vec2 uv, float d) { vec4 p = uInvVP * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0); return p.xyz / p.w; }
float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
void main() {
  vec3 c = texture(uScene, vUV).rgb;
  float d = texture(uDepth, vUV).r;
  vec3 P = worldAt(vUV, d);
  // Camera motion blur: reproject this pixel into last frame and smear along the difference.
  if (uMotion > 0.0 && d < 1.0) {
    vec4 pc = uPrevVP * vec4(P, 1.0);
    vec2 prevUV = pc.xy / pc.w * 0.5 + 0.5;
    vec2 vel = (vUV - prevUV) * uMotion;
    float vl = length(vel);
    if (vl > 0.0015) {
      vel *= min(1.0, 0.05 / vl);
      vec3 acc = c;
      float j = ign(gl_FragCoord.xy);
      for (int i = 1; i < 8; ++i) acc += texture(uScene, vUV - vel * ((float(i) + j) / 8.0 - 0.5)).rgb;
      c = acc / 8.0;
    }
  }
  // Screen-space reflections on glossy floors (planar, so a short world-space march works well).
  if (uSSR == 1 && uGloss > 0.0 && d < 1.0 && P.y < 0.06 && P.y > -0.7) {  // floors and pool bottoms, not the courtyard far below
    vec3 Px = worldAt(vUV + vec2(uTexel.x, 0.0), texture(uDepth, vUV + vec2(uTexel.x, 0.0)).r);
    vec3 Py = worldAt(vUV + vec2(0.0, uTexel.y), texture(uDepth, vUV + vec2(0.0, uTexel.y)).r);
    vec3 N = normalize(cross(Px - P, Py - P));
    if (N.y < 0.0) N = -N;
    if (N.y > 0.93) {
      vec3 V = normalize(P - uCamPos);
      float cosT = max(-V.y, 0.0);
      float fres = 0.04 + 0.96 * pow(1.0 - cosT, 5.0);
      float j = ign(gl_FragCoord.xy + 17.0);
      vec3 R = reflect(V, vec3(0.0, 1.0, 0.0));
      // rough floors scatter the reflection a little
      R = normalize(R + vec3(j - 0.5, 0.0, ign(gl_FragCoord.yx) - 0.5) * (1.0 - uGloss) * 0.18);
      float t = 0.08 + j * 0.12;
      vec3 hit = vec3(0.0);
      float found = 0.0;
      for (int i = 0; i < 28; ++i) {
        vec3 Q = P + R * t;
        vec4 qc = uVP * vec4(Q, 1.0);
        if (qc.w <= 0.0) break;
        vec3 qn = qc.xyz / qc.w;
        vec2 quv = qn.xy * 0.5 + 0.5;
        if (quv.x < 0.0 || quv.x > 1.0 || quv.y < 0.0 || quv.y > 1.0) break;
        float sd = texture(uDepth, quv).r;
        float qd = qn.z * 0.5 + 0.5;
        if (qd > sd) {
          vec3 S = worldAt(quv, sd);
          if (distance(S, Q) < 0.25 + t * 0.12) {
            vec2 e = min(quv, 1.0 - quv);
            float edge = smoothstep(0.0, 0.08, min(e.x, e.y));
            hit = texture(uScene, quv).rgb;
            found = edge * (1.0 - smoothstep(14.0, 24.0, t));
          }
          break;
        }
        t *= 1.16;
        t += 0.05;
      }
      float k = found * mix(fres, 1.0, 0.25) * uGloss;
      c = mix(c, hit, clamp(k, 0.0, 0.85));
    }
  }
  if (uUseAO == 1) {
    float ao = 0.0;
    for (int y = -1; y <= 1; ++y)
      for (int x = -1; x <= 1; ++x) ao += texture(uAO, vUV + vec2(x, y) * uHalfTexel).r;
    c *= mix(1.0, ao / 9.0, 0.8);
  }
  if (uUseVol == 1) {
    vec3 v = texture(uVol, vUV).rgb * 0.5;
    v += texture(uVol, vUV + vec2(uHalfTexel.x, 0)).rgb * 0.125 + texture(uVol, vUV - vec2(uHalfTexel.x, 0)).rgb * 0.125;
    v += texture(uVol, vUV + vec2(0, uHalfTexel.y)).rgb * 0.125 + texture(uVol, vUV - vec2(0, uHalfTexel.y)).rgb * 0.125;
    c += v;
  }
  oColor = vec4(c, 1.0);
}
)";

static const char* kDownFS = R"(#version 330 core
in vec2 vUV;
out vec4 oColor;
uniform sampler2D uSrc;
uniform vec2 uTexel;
uniform int uPrefilter;
vec3 s(vec2 o) { return texture(uSrc, vUV + o * uTexel).rgb; }
void main() {
  vec3 a = s(vec2(-2, 2)), b = s(vec2(0, 2)), c = s(vec2(2, 2));
  vec3 d = s(vec2(-2, 0)), e = s(vec2(0, 0)), f = s(vec2(2, 0));
  vec3 g = s(vec2(-2, -2)), h = s(vec2(0, -2)), i = s(vec2(2, -2));
  vec3 j = s(vec2(-1, 1)), k = s(vec2(1, 1)), l = s(vec2(-1, -1)), m = s(vec2(1, -1));
  vec3 r = e * 0.125 + (a + c + g + i) * 0.03125 + (b + d + f + h) * 0.0625 + (j + k + l + m) * 0.125;
  if (uPrefilter == 1) {
    float br = max(r.r, max(r.g, r.b));
    float knee = 0.5, thr = 1.0;
    float soft = clamp(br - thr + knee, 0.0, 2.0 * knee);
    soft = soft * soft / (4.0 * knee + 1e-4);
    r *= max(soft, br - thr) / max(br, 1e-4);
  }
  oColor = vec4(r, 1.0);
}
)";

static const char* kUpFS = R"(#version 330 core
in vec2 vUV;
out vec4 oColor;
uniform sampler2D uSrc;
uniform vec2 uTexel;
void main() {
  vec3 r = vec3(0.0);
  r += texture(uSrc, vUV + vec2(-1, 1) * uTexel).rgb;
  r += texture(uSrc, vUV + vec2(0, 1) * uTexel).rgb * 2.0;
  r += texture(uSrc, vUV + vec2(1, 1) * uTexel).rgb;
  r += texture(uSrc, vUV + vec2(-1, 0) * uTexel).rgb * 2.0;
  r += texture(uSrc, vUV).rgb * 4.0;
  r += texture(uSrc, vUV + vec2(1, 0) * uTexel).rgb * 2.0;
  r += texture(uSrc, vUV + vec2(-1, -1) * uTexel).rgb;
  r += texture(uSrc, vUV + vec2(0, -1) * uTexel).rgb * 2.0;
  r += texture(uSrc, vUV + vec2(1, -1) * uTexel).rgb;
  oColor = vec4(r / 16.0, 1.0);
}
)";

static const char* kTonemapFS = R"(#version 330 core
in vec2 vUV;
out vec4 oColor;
uniform sampler2D uScene;
uniform sampler2D uBloom;
uniform float uTime;
uniform float uExposure;
uniform float uBloomAmt;
uniform float uStatic;
uniform float uFear;
uniform float uNight;
uniform float uFocus;
uniform int uVHS;
uniform float uWet;
uniform vec3 uGradeGain, uGradeLift;
uniform sampler2D uTape;
uniform int uTapeOn;
uniform float uFrameX0, uFrameW;  // the picture's place on screen (4:3 with bars, or all of it)
uniform float uPan;               // how fast the picture is panning sideways (interlace combing)
uniform float uBanding;           // filming under fluorescent tubes: a faint dark band rolls up the frame
uniform float uJolt;              // the camera just got knocked: vertical hold slips, a tracking band tears across
uniform float uScar, uScarY;      // after it hit the floor: a scratch on the tape, one line that never goes away
uniform sampler2D uPrev;          // last frame's picture (CCD lag in low light)
uniform float uLag;
uniform float uTapeWear, uTapeSeed; // how worn this stretch of tape is
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
vec3 aces(vec3 x) {
  const mat3 i = mat3(0.59719, 0.07600, 0.02840, 0.35458, 0.90834, 0.13383, 0.04823, 0.01566, 0.83777);
  const mat3 o = mat3(1.60475, -0.10208, -0.00327, -0.53108, 1.10813, -0.07276, -0.07367, -0.00605, 1.07602);
  x = i * x;
  vec3 a = x * (x + 0.0245786) - 0.000090537;
  vec3 b = x * (0.983729 * x + 0.4329510) + 0.238081;
  return clamp(o * (a / b), 0.0, 1.0);
}
vec3 sceneAt(vec2 uv, float ca) {
  vec2 dir = uv - 0.5;
  return vec3(texture(uScene, uv + dir * ca).r, texture(uScene, uv).g, texture(uScene, uv - dir * ca).b);
}
// VHS is ~330 lines of luma across the frame and ~240 tall: smear the picture down to that.
vec3 vhsSample(vec2 uv, float ca) {
  vec2 px = vec2(1.0 / 500.0, 1.0 / 380.0);  // DV-soft, not smeared
  vec3 acc = vec3(0.0);
  float ws = 0.0;
  for (int i = -3; i <= 3; ++i)
    for (int j = -1; j <= 1; ++j) {
      float w = exp(-float(i * i) / 4.0 - float(j * j) / 0.9);
      acc += sceneAt(uv + vec2(float(i) * px.x * 0.55, float(j) * px.y * 0.6), ca) * w;
      ws += w;
    }
  return acc / ws;
}
// Rounded CRT/viewfinder corners: 1 inside the picture, 0 in the black surround.
float crtMask(vec2 uv) {
  vec2 q = abs(uv - 0.5) * 2.0;
  vec2 r = max(q - (1.0 - 0.07), 0.0) / 0.07;
  float corner = 1.0 - smoothstep(0.82, 1.0, length(r));
  float edge = smoothstep(1.0, 0.992, q.x) * smoothstep(1.0, 0.988, q.y);
  return corner * edge;
}
void main() {
  vec2 fuv = vec2((vUV.x - uFrameX0) / uFrameW, vUV.y);  // 0..1 across the picture
  if (fuv.x < 0.0 || fuv.x > 1.0) { oColor = vec4(0.0); return; }  // the black bars
  vec2 uv = fuv;
  vec2 cc = uv - 0.5;
  float r2 = dot(cc * vec2(1.0, 0.75), cc * vec2(1.0, 0.75));
  if (uVHS == 1) uv = 0.5 + cc * (0.995 + 0.02 * r2);  // captured video: barely any lens curve, square corners
  else uv = 0.5 + cc * (1.0 - 0.03 + 0.06 * dot(cc, cc));
  float mask = 1.0;  // (no rounded TV corners: this is the tape, not a TV showing it)
  if (uVHS == 1) {
    // head-switching noise: the bottom few lines of every VHS frame tear sideways
    float hs = smoothstep(0.018, 0.0, uv.y);
    uv.x += hs * (0.004 + 0.008 * hash(vec2(floor(uv.y * 300.0), floor(uTime * 30.0))));
    float line = floor(uv.y * 240.0);
    uv.x += (hash(vec2(line, floor(uTime * 30.0))) - 0.5) * 0.00035;
    float band = fract(uTime * 0.045);
    uv.x += smoothstep(0.02, 0.0, abs(uv.y - band)) * (hash(vec2(line, uTime)) - 0.5) * 0.005;
  }
  if (uVHS == 1 && uTapeWear > 0.0) {
    // worn tape: the top few lines bend sideways ("flagging"), and now and then the whole picture
    // wavers for a second where the tape was creased
    float flag = smoothstep(0.93, 1.0, uv.y);
    uv.x += flag * flag * uTapeWear * 0.012 * (0.6 + 0.4 * sin(uTime * 2.3 + uTapeSeed));
    float crease = smoothstep(0.985, 1.0, sin(uTime * 0.21 + uTapeSeed * 3.0) * 0.5 + 0.5) * uTapeWear;
    uv.x += crease * sin(uv.y * 38.0 + uTime * 9.0) * 0.0035;
  }
  float joltBand = 0.0, joltBlank = 0.0;
  if (uVHS == 1 && uJolt > 0.002) {
    // the transport got shaken: the picture jumps a few lines, skews, and a tracking band of torn,
    // noisy lines sweeps through it for a few fields
    float fr = floor(uTime * 30.0);
    float j2 = uJolt * uJolt;
    uv.y += j2 * 0.05 * (hash(vec2(fr, 3.1)) - 0.25);
    if (uv.y > 1.0 || uv.y < 0.0) joltBlank = 1.0;  // the vertical blanking bar rolls into view
    float by = hash(vec2(floor(fr * 0.5), 7.7));
    float bh = 0.025 + 0.07 * uJolt;
    joltBand = smoothstep(bh, 0.0, abs(uv.y - by)) * uJolt;
    uv.x += joltBand * (hash(vec2(floor(uv.y * 240.0), fr)) - 0.5) * 0.09;
    uv.x += (uv.y - 0.5) * uJolt * 0.014 * (hash(vec2(fr, 1.0)) - 0.5);
  }
  if (uVHS == 1 && uScar > 0.0) {  // the lines just under the scratch are dragged sideways a hair
    float below = uScarY - uv.y;
    uv.x += uScar * 0.003 * smoothstep(0.0, 0.002, below) * smoothstep(0.012, 0.003, below) * (0.6 + 0.4 * hash(vec2(floor(uTime * 15.0), 2.0)));
  }
  if (uWet > 0.001) {  // water droplets on the lens refract what's behind them
    vec2 g = uv * vec2(9.0, 16.0);
    vec2 cell = floor(g);
    vec2 f = fract(g) - 0.5;
    float h = hash(cell);
    vec2 c = vec2(hash(cell + 3.1), hash(cell + 7.7)) - 0.5;
    float rad = 0.12 + 0.25 * h;
    float dd = length(f - c * 0.5);
    float drop = smoothstep(rad, rad * 0.6, dd) * step(0.45, h) * smoothstep(0.0, 0.2, uWet - h * 0.6);
    uv += (f - c * 0.5) * drop * 0.035;
    float streak = smoothstep(0.03, 0.0, abs(f.x - c.x * 0.5)) * step(0.85, h) * uWet;
    uv.y += streak * 0.01;
  }
  float tear = uStatic + uFear * 0.12;
  uv.x += tear * (hash(vec2(floor(uv.y * 160.0), floor(uTime * 40.0))) - 0.5) * 0.06;
  if (uVHS == 1 && abs(uPan) > 0.0005) {  // interlaced video: on a fast pan every other line is a field behind
    float field = mod(floor(vUV.y * 480.0), 2.0);
    uv.x -= field * uPan;
  }
  uv.x = uFrameX0 + uv.x * uFrameW;  // back to the screen to sample the picture
  float ca = 0.0008 + (uVHS == 1 ? 0.0006 + 0.006 * r2 : 0.0) + uFear * 0.006;  // fringing grows toward the edges
  vec3 col = uVHS == 1 ? vhsSample(uv, ca) : sceneAt(uv, ca);
  if (uFocus > 0.002) {  // the autofocus hunting: a soft disc blur that comes and goes
    vec3 acc = col;
    float rr = uFocus * 0.006;
    for (int k = 0; k < 10; ++k) {
      float a = float(k) * 0.6283 + 0.3;
      acc += texture(uScene, uv + vec2(cos(a), sin(a) * 1.77) * rr * (k % 2 == 0 ? 1.0 : 0.55)).rgb;
    }
    col = mix(col, acc / 11.0, clamp(uFocus * 1.8, 0.0, 1.0));
  }
  if (uVHS == 1) {
    // VHS chroma is smeared and late: keep the sharp luma, take colour from a blurry copy shifted right
    vec3 cb = vec3(0.0);
    for (int k = 0; k < 6; ++k) cb += texture(uScene, uv - vec2(0.0011 * float(k) + 0.0012, 0.0)).rgb;
    cb /= 6.0;
    float ls = dot(col, vec3(0.299, 0.587, 0.114)), lb = dot(cb, vec3(0.299, 0.587, 0.114));
    col = max(vec3(ls) + (cb - vec3(lb)), 0.0);
    // a faint ghost of every edge a little to the right (tape echo)
    col += (texture(uScene, uv - vec2(0.005, 0.0)).rgb - col) * 0.035;
  }
  col += texture(uBloom, uv).rgb * uBloomAmt;
  {  // lens ghosts: the tubes reflect between the camcorder's lens elements, mirrored through the
     // centre as soft round discs (the shape of the iris), faint green and violet
    vec2 gc = fuv - 0.5;
    vec3 gh = vec3(0.0);
    for (int g = 0; g < 2; ++g) {
      float sc = g == 0 ? -0.6 : -1.35;
      vec3 tint = g == 0 ? vec3(0.35, 0.8, 0.55) : vec3(0.6, 0.45, 0.85) * 0.5;
      vec2 gp = 0.5 + gc * sc;
      vec3 acc = vec3(0.0);
      for (int k = 0; k < 9; ++k) {
        float a = float(k) * 0.698;
        vec2 o = k == 8 ? vec2(0.0) : vec2(cos(a), sin(a) * 1.33) * (0.03 + 0.03 * float(g));
        vec2 q = gp + o;
        float inb = step(0.02, q.x) * step(q.x, 0.98) * step(0.02, q.y) * step(q.y, 0.98);
        acc += max(texture(uBloom, vec2(uFrameX0 + clamp(q.x, 0.0, 1.0) * uFrameW, clamp(q.y, 0.0, 1.0))).rgb - 0.3, 0.0) * inb;
      }
      gh += acc / 9.0 * tint;
    }
    col += gh * uBloomAmt * 0.9;
  }
  // anamorphic streaks off the brightest lights
  vec3 streak = vec3(0.0);
  for (int k = 1; k <= 8; ++k) {
    float o = float(k) * 0.014;
    float w = 1.0 - float(k) / 9.0;
    streak += (texture(uBloom, uv + vec2(o, 0.0)).rgb + texture(uBloom, uv - vec2(o, 0.0)).rgb) * w;
  }
  if (uVHS == 1) {
    // a CCD camcorder doesn't streak sideways: very bright lights bleed a faint vertical smear down the sensor
    vec3 smear = vec3(0.0);
    for (int k = -10; k <= 10; ++k) smear += texture(uBloom, vec2(uv.x, clamp(uv.y + float(k) * 0.045, 0.0, 1.0))).rgb;
    col += max(smear / 21.0 - 0.18, 0.0) * vec3(1.0, 0.97, 0.9) * uBloomAmt * 0.9;
  } else {
    col += max(streak - 0.25, 0.0) * vec3(0.45, 0.62, 1.0) * uBloomAmt * 0.22;
  }
  col *= uExposure;
  if (uNight > 0.0) {  // NightShot: the infrared picture, monochrome green, gain cranked up
    float lum = dot(col, vec3(0.2126, 0.7152, 0.0722));
    lum = lum * 3.0 + 0.012;
    col = mix(col, vec3(0.30, 1.0, 0.40) * lum, uNight);
  }
  if (uVHS == 1) {
    // A video camera, not a film curve: linear-ish up to a knee, then the highlights clip hard to
    // white (every tube blows out), shadows go to noise instead of rolling off softly.
    const float k = 0.78;
    vec3 over = max(col - k, 0.0);
    col = min(col, vec3(k)) + (1.0 - k) * (1.0 - exp(-over / (1.0 - k)));  // monotonic knee, clips to white
    col = clamp(col, 0.0, 1.0);
  } else {
    col = aces(col);
  }
  // per-level film grade (the lift fades out at true black: a dark hall stays black, not grey)
  col = clamp(col * uGradeGain + uGradeLift * (1.0 - col) * smoothstep(0.0, 0.06, dot(col, vec3(0.3, 0.59, 0.11))), 0.0, 1.0);
  float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
  col = mix(col, col * vec3(1.03, 1.0, 0.92), smoothstep(0.3, 1.0, l));
  col += vec3(0.009, 0.008, 0.002) * (1.0 - l) * smoothstep(0.0, 0.05, l);
  if (uVHS == 1) {
    // Found-footage grade: crushed blacks, hot sickly yellow-green, oversaturated mids.
    // a cheap camcorder, honestly graded: slightly warm highlights, slightly cool shadows, a touch of extra colour
    // a 2000s handycam: soft, warm, a little flat in the colour, blacks that sink
    float l2 = dot(col, vec3(0.2126, 0.7152, 0.0722));
    // on a worn stretch the colour fades in and out
    float fadeC = smoothstep(0.6, 0.95, 0.5 + 0.5 * sin(uTime * 0.31 + uTapeSeed) + (hash(vec2(floor(uTime * 0.7), uTapeSeed)) - 0.5) * 0.25) * uTapeWear;
    col = mix(vec3(l2), col, 0.97 * (1.0 - 0.75 * clamp(uJolt * 1.3, 0.0, 1.0)) * (1.0 - 0.6 * fadeC));             // consumer tape: a bit washed (the colour drops out when it's knocked)
    col *= mix(vec3(0.985, 1.0, 0.97), vec3(1.03, 1.0, 0.92), smoothstep(0.04, 0.55, l2));      // auto white balance under tubes
    col = max(col, 0.0);
  } else {
    col = mix(vec3(l), col, 0.92);
  }
  col = pow(col, vec3(1.0 / 2.2));
  if (uVHS == 1) col = 0.018 + col * 0.97;  // video black level: blacks sit just above black
  vec2 dir = fuv - 0.5;
  float vig = smoothstep(0.95, 0.25, length(dir * vec2(1.12, 1.0)));
  col *= uVHS == 1 ? mix(0.78 - uFear * 0.1, 1.0, vig) : mix(0.3 - uFear * 0.08, 1.0, vig);
  // (after the vignette: the OSD is burned on top, it doesn't sit in the lens shadow)
  if (uTapeOn == 1) {
    // The camcorder OSD is on the tape too: same lens, same jitter, smeared sideways,
    // colour fringed (red late, cyan early), glowing a little.
    vec2 tx = vec2(1.0 / 330.0, 0.0);
    float a = 0.0, r = 0.0, b = 0.0, glow = 0.0;
    vec3 tc = vec3(0.0);
    for (int k = -2; k <= 2; ++k) {
      float w = exp(-float(k * k) / 2.2);
      vec4 t = texture(uTape, uv + tx * float(k) * 0.3);
      a += t.a * w; tc += t.rgb * w;  // tape layer is premultiplied
    }
    a /= 3.37; tc /= 3.37;
    r = texture(uTape, uv - tx * 0.9).a;
    b = texture(uTape, uv + tx * 0.7).a;
    for (int k = -3; k <= 3; ++k) glow += texture(uTape, uv + tx * float(k) * 2.2 + vec2(0.0, float(abs(k) % 2) * 0.004)).a;
    glow /= 7.0;
    vec3 txt = a > 0.001 ? tc / a : vec3(1.0);
    col = mix(col, txt * vec3(0.98, 0.98, 0.94), clamp(a * 1.05, 0.0, 1.0));
    col.r += max(r - a, 0.0) * 0.25;
    col.gb += max(b - a, 0.0) * vec2(0.2, 0.25);
    col += vec3(0.9, 0.95, 1.0) * glow * 0.06;
  }
  if (joltBand > 0.001) {  // inside the tracking band: white dashes along the lines, fine snow between
    float row = floor(fuv.y * 240.0), fr = floor(uTime * 60.0);
    float seg = floor(fuv.x * 28.0 + hash(vec2(row, fr)) * 28.0);
    float dash = step(0.72, hash(vec2(seg, row + fr * 7.0)));
    float sn = hash(vec2(floor(fuv.x * 640.0), row + fr));
    col = mix(col, vec3(0.25 + 0.6 * sn), joltBand * 0.18);
    col = mix(col, vec3(0.92), joltBand * dash * 0.55);
  }
  if (joltBlank > 0.0) col = vec3(0.012);
  if (uScar > 0.0) {  // the scratch: one thin line of dropout, sparkling, a little brighter where it's worst
    float d = abs(fuv.y - uScarY) * 480.0;
    float ln = smoothstep(1.5, 0.0, d);
    float sp = hash(vec2(floor(fuv.x * 260.0), floor(uTime * 30.0)));
    float worse = 0.55 + 0.45 * sin(fuv.x * 9.0 + uScarY * 40.0);
    col = mix(col, vec3(0.7 + 0.3 * sp), ln * uScar * (0.25 + 0.5 * sp) * worse);
  }
  if (uBanding > 0.0) col *= 1.0 - uBanding * (0.5 + 0.5 * sin(fuv.y * 6.2832 * 1.3 - uTime * 0.9));
  if (uFear > 0.0) {
    float lf = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(col, vec3(lf) * vec3(1.1, 0.85, 0.8), uFear * 0.5);
  }
  col *= mask;
  if (uLag > 0.0 && fuv.x > 0.0) {
    // In the dark the camera slows its shutter and cranks the gain: anything moving smears, and
    // bright things leave a short comet tail behind them.
    vec3 pv = texture(uPrev, vUV).rgb;
    float lc = dot(col, vec3(0.299, 0.587, 0.114)), lp = dot(pv, vec3(0.299, 0.587, 0.114));
    float k = uLag * (1.0 - smoothstep(0.08, 0.5, lc));
    col = mix(col, pv, k * (lp > lc ? 0.85 : 0.55));
  }
  oColor = vec4(col, dot(col, vec3(0.299, 0.587, 0.114)));
}
)";

static const char* kFxaaFS = R"(#version 330 core
in vec2 vUV;
out vec4 oColor;
uniform sampler2D uSrc;
uniform vec2 uRes;
uniform int uFxaa;
uniform int uVHS;
uniform float uTime;
uniform float uGrain;
uniform float uStatic;
uniform float uFade;
uniform float uTapeWear;
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
vec3 fxaa(vec2 uv) {
  vec2 t = 1.0 / uRes;
  float lNW = texture(uSrc, uv + vec2(-1, -1) * t).a, lNE = texture(uSrc, uv + vec2(1, -1) * t).a;
  float lSW = texture(uSrc, uv + vec2(-1, 1) * t).a, lSE = texture(uSrc, uv + vec2(1, 1) * t).a;
  vec4 m = texture(uSrc, uv);
  float lM = m.a;
  float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
  float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
  if (lMax - lMin < max(0.0312, lMax * 0.125)) return m.rgb;
  vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), ((lNW + lSW) - (lNE + lSE)));
  float red = max((lNW + lNE + lSW + lSE) * 0.03125, 1.0 / 128.0);
  float rcp = 1.0 / (min(abs(dir.x), abs(dir.y)) + red);
  dir = clamp(dir * rcp, vec2(-8.0), vec2(8.0)) * t;
  vec3 a = 0.5 * (texture(uSrc, uv + dir * (1.0 / 3.0 - 0.5)).rgb + texture(uSrc, uv + dir * (2.0 / 3.0 - 0.5)).rgb);
  vec3 b = a * 0.5 + 0.25 * (texture(uSrc, uv + dir * -0.5).rgb + texture(uSrc, uv + dir * 0.5).rgb);
  float lb = dot(b, vec3(0.299, 0.587, 0.114));
  return (lb < lMin || lb > lMax) ? a : b;
}
void main() {
  vec3 col = (uFxaa == 1 && uVHS == 0) ? fxaa(vUV) : texture(uSrc, vUV).rgb;
  if (uVHS == 0) {  // light unsharp mask: crisper edges after FXAA
    vec2 t = 1.0 / uRes;
    vec3 blur = (texture(uSrc, vUV + vec2(t.x, 0)).rgb + texture(uSrc, vUV - vec2(t.x, 0)).rgb +
                 texture(uSrc, vUV + vec2(0, t.y)).rgb + texture(uSrc, vUV - vec2(0, t.y)).rgb) * 0.25;
    col = max(col + (col - blur) * 0.35, 0.0);
  }
  float live = 1.0;
  if (uVHS == 1) {
    // the camera's edge enhancement ("peaking"): luma only, sideways, a thin bright/dark halo on every edge
    vec2 t = 1.0 / uRes;
    vec3 bh = (texture(uSrc, vUV + vec2(t.x * 1.6, 0)).rgb + texture(uSrc, vUV - vec2(t.x * 1.6, 0)).rgb) * 0.5;
    float dl = dot(col - bh, vec3(0.299, 0.587, 0.114));
    col = max(col + vec3(dl) * 0.6, 0.0);
    float l = dot(col, vec3(0.299, 0.587, 0.114));
    live = smoothstep(0.0, 0.02, l + texture(uSrc, vUV + vec2(0.003, 0.0)).a);  // the black surround stays black
    col *= 0.99 + 0.01 * sin(vUV.y * 480.0 * 6.2832);  // the faintest interlace lines
    // tape noise runs along the scan lines: short sideways streaks of luma snow, one field at a time,
    // and the colour noise comes in long soft smudges (VHS chroma has a tenth of the bandwidth)
    float fr = floor(uTime * 59.94);
    float line = floor(vUV.y * 480.0);
    float sx = vUV.x * 330.0;
    float n0 = hash(vec2(floor(sx), line + fr * 487.0)), n1 = hash(vec2(floor(sx) + 1.0, line + fr * 487.0));
    float n = mix(n0, n1, smoothstep(0.0, 1.0, fract(sx))) - 0.5;
    col += n * (0.009 + 0.016 * (1.0 - l)) * live;  // more in the shadows, where the gain is up
    float cx = vUV.x * 42.0;
    vec2 c0 = vec2(hash(vec2(floor(cx), line * 0.5 + fr * 31.0)), hash(vec2(floor(cx) + 17.0, line * 0.5 + fr * 31.0)));
    vec2 c1 = vec2(hash(vec2(floor(cx) + 1.0, line * 0.5 + fr * 31.0)), hash(vec2(floor(cx) + 18.0, line * 0.5 + fr * 31.0)));
    vec2 cn = mix(c0, c1, smoothstep(0.0, 1.0, fract(cx))) - 0.5;  // (U, V)
    float shadowC = 1.0 - smoothstep(0.05, 0.5, l);
    col += vec3(cn.y * 0.9, -cn.x * 0.25 - cn.y * 0.45, cn.x * 1.1) * 0.016 * shadowC * live;
    // the odd white dropout streak
    float row = floor(vUV.y * uRes.y / 2.0);
    float drop = step(0.9996 - 0.0016 * uTapeWear, hash(vec2(row, floor(uTime * 24.0))));
    col += drop * smoothstep(0.0, 0.3, hash(vec2(floor(vUV.x * 40.0), row))) * 0.35 * live;
  }
  col += (hash(vUV * uRes + fract(uTime * 7.13) * 100.0) - 0.5) * uGrain * live;
  {  // colour noise in the shadows, like a small sensor with the gain turned up
    float l = dot(col, vec3(0.299, 0.587, 0.114));
    vec2 q = vUV * uRes + fract(uTime * 3.7) * 57.0;
    vec3 cn = vec3(hash(q + 1.3), hash(q + 7.1), hash(q + 3.7)) - 0.5;
    col += cn * uGrain * 0.8 * (1.0 - smoothstep(0.0, 0.45, l)) * live;
  }
  float s = hash(floor(vUV * uRes / 2.0) + floor(uTime * 60.0));
  col = mix(col, vec3(s), clamp(uStatic, 0.0, 1.0));
  col *= 1.0 - uFade;
  oColor = vec4(col, 1.0);
}
)";

static const char* kUiVS = R"(#version 330 core
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aUV;
layout(location = 2) in vec4 aCol;
uniform vec2 uScreen;
out vec2 vUV;
out vec4 vCol;
void main() {
  vUV = aUV;
  vCol = aCol;
  gl_Position = vec4(aPos.x / uScreen.x * 2.0 - 1.0, 1.0 - aPos.y / uScreen.y * 2.0, 0.0, 1.0);
}
)";

static const char* kUiFS = R"(#version 330 core
in vec2 vUV;
in vec4 vCol;
out vec4 oColor;
uniform sampler2D uFont;
uniform int uImage;
void main() {
  if (uImage == 1) { oColor = texture(uFont, vUV) * vCol; return; }
  float a = vUV.x < 0.0 ? 1.0 : texture(uFont, vUV).r;
  oColor = vec4(vCol.rgb, vCol.a * a);
}
)";

// ================================================================ helpers

static GLuint compile(GLenum type, const char* src, std::string& err) {
  GLuint s = glCreateShader(type);
  glShaderSource(s, 1, &src, nullptr);
  glCompileShader(s);
  GLint ok = 0;
  glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
  if (!ok) {
    char log[4096];
    glGetShaderInfoLog(s, sizeof log, nullptr, log);
    err += log;
    glDeleteShader(s);
    return 0;
  }
  return s;
}

bool Shader::build(const char* vs, const char* fs, std::string& err) {
  GLuint v = compile(GL_VERTEX_SHADER, vs, err), f = compile(GL_FRAGMENT_SHADER, fs, err);
  if (!v || !f) return false;
  prog = glCreateProgram();
  glAttachShader(prog, v);
  glAttachShader(prog, f);
  glLinkProgram(prog);
  glDeleteShader(v);
  glDeleteShader(f);
  GLint ok = 0;
  glGetProgramiv(prog, GL_LINK_STATUS, &ok);
  if (!ok) {
    char log[4096];
    glGetProgramInfoLog(prog, sizeof log, nullptr, log);
    err += log;
    return false;
  }
  return true;
}

GLint Shader::loc(const char* name) {
  auto it = locs.find(name);
  if (it != locs.end()) return it->second;
  GLint l = glGetUniformLocation(prog, name);
  locs[name] = l;
  return l;
}

void GpuMesh::upload(const Mesh& m) {
  if (!vao) { glGenVertexArrays(1, &vao); glGenBuffers(1, &vbo); glGenBuffers(1, &ibo); }
  glBindVertexArray(vao);
  glBindBuffer(GL_ARRAY_BUFFER, vbo);
  glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(m.v.size() * sizeof(float)), m.v.data(), GL_STATIC_DRAW);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
  glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(m.idx.size() * sizeof(uint32_t)), m.idx.data(), GL_STATIC_DRAW);
  const GLsizei stride = m.stride * sizeof(float);
  glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
  glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
  glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
  glEnableVertexAttribArray(3); glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, stride, (void*)(8 * sizeof(float)));
  if (m.stride >= 14) { glEnableVertexAttribArray(4); glVertexAttribPointer(4, 4, GL_FLOAT, GL_FALSE, stride, (void*)(10 * sizeof(float))); }
  glBindVertexArray(0);
  count = (GLsizei)m.idx.size();
}

void GpuMesh::draw() const {
  if (!count) return;
  glBindVertexArray(vao);
  glDrawElements(GL_TRIANGLES, count, GL_UNSIGNED_INT, nullptr);
}

void GpuMesh::destroy() {
  if (vao) { glDeleteVertexArrays(1, &vao); glDeleteBuffers(1, &vbo); glDeleteBuffers(1, &ibo); }
  vao = vbo = ibo = 0;
  count = 0;
}

GLuint makeTexture(const Image& img, bool mipmaps, bool repeat) {
  GLuint t;
  glGenTextures(1, &t);
  glBindTexture(GL_TEXTURE_2D, t);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, img.w, img.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, img.px.data());
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, repeat ? GL_REPEAT : GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, repeat ? GL_REPEAT : GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, mipmaps ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR);
  if (mipmaps) {
    glGenerateMipmap(GL_TEXTURE_2D);
    if (gAniso > 1.0f) glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY, gAniso);
  }
  return t;
}

static mat4 inverse(const mat4& m) {
  const float* a = m.m;
  float inv[16];
  inv[0] = a[5]*a[10]*a[15] - a[5]*a[11]*a[14] - a[9]*a[6]*a[15] + a[9]*a[7]*a[14] + a[13]*a[6]*a[11] - a[13]*a[7]*a[10];
  inv[4] = -a[4]*a[10]*a[15] + a[4]*a[11]*a[14] + a[8]*a[6]*a[15] - a[8]*a[7]*a[14] - a[12]*a[6]*a[11] + a[12]*a[7]*a[10];
  inv[8] = a[4]*a[9]*a[15] - a[4]*a[11]*a[13] - a[8]*a[5]*a[15] + a[8]*a[7]*a[13] + a[12]*a[5]*a[11] - a[12]*a[7]*a[9];
  inv[12] = -a[4]*a[9]*a[14] + a[4]*a[10]*a[13] + a[8]*a[5]*a[14] - a[8]*a[6]*a[13] - a[12]*a[5]*a[10] + a[12]*a[6]*a[9];
  inv[1] = -a[1]*a[10]*a[15] + a[1]*a[11]*a[14] + a[9]*a[2]*a[15] - a[9]*a[3]*a[14] - a[13]*a[2]*a[11] + a[13]*a[3]*a[10];
  inv[5] = a[0]*a[10]*a[15] - a[0]*a[11]*a[14] - a[8]*a[2]*a[15] + a[8]*a[3]*a[14] + a[12]*a[2]*a[11] - a[12]*a[3]*a[10];
  inv[9] = -a[0]*a[9]*a[15] + a[0]*a[11]*a[13] + a[8]*a[1]*a[15] - a[8]*a[3]*a[13] - a[12]*a[1]*a[11] + a[12]*a[3]*a[9];
  inv[13] = a[0]*a[9]*a[14] - a[0]*a[10]*a[13] - a[8]*a[1]*a[14] + a[8]*a[2]*a[13] + a[12]*a[1]*a[10] - a[12]*a[2]*a[9];
  inv[2] = a[1]*a[6]*a[15] - a[1]*a[7]*a[14] - a[5]*a[2]*a[15] + a[5]*a[3]*a[14] + a[13]*a[2]*a[7] - a[13]*a[3]*a[6];
  inv[6] = -a[0]*a[6]*a[15] + a[0]*a[7]*a[14] + a[4]*a[2]*a[15] - a[4]*a[3]*a[14] - a[12]*a[2]*a[7] + a[12]*a[3]*a[6];
  inv[10] = a[0]*a[5]*a[15] - a[0]*a[7]*a[13] - a[4]*a[1]*a[15] + a[4]*a[3]*a[13] + a[12]*a[1]*a[7] - a[12]*a[3]*a[5];
  inv[14] = -a[0]*a[5]*a[14] + a[0]*a[6]*a[13] + a[4]*a[1]*a[14] - a[4]*a[2]*a[13] - a[12]*a[1]*a[6] + a[12]*a[2]*a[5];
  inv[3] = -a[1]*a[6]*a[11] + a[1]*a[7]*a[10] + a[5]*a[2]*a[11] - a[5]*a[3]*a[10] - a[9]*a[2]*a[7] + a[9]*a[3]*a[6];
  inv[7] = a[0]*a[6]*a[11] - a[0]*a[7]*a[10] - a[4]*a[2]*a[11] + a[4]*a[3]*a[10] + a[8]*a[2]*a[7] - a[8]*a[3]*a[6];
  inv[11] = -a[0]*a[5]*a[11] + a[0]*a[7]*a[9] + a[4]*a[1]*a[11] - a[4]*a[3]*a[9] - a[8]*a[1]*a[7] + a[8]*a[3]*a[5];
  inv[15] = a[0]*a[5]*a[10] - a[0]*a[6]*a[9] - a[4]*a[1]*a[10] + a[4]*a[2]*a[9] + a[8]*a[1]*a[6] - a[8]*a[2]*a[5];
  float det = a[0] * inv[0] + a[1] * inv[4] + a[2] * inv[8] + a[3] * inv[12];
  mat4 r{};
  float id = std::fabs(det) > 1e-20f ? 1.0f / det : 0.0f;
  for (int i = 0; i < 16; ++i) r.m[i] = inv[i] * id;
  return r;
}

// ================================================================ renderer

bool Renderer::init(std::string& err) {
  if (gl::hasExtension("GL_EXT_texture_filter_anisotropic") || gl::hasExtension("GL_ARB_texture_filter_anisotropic")) {
    GLint maxA = 1;
    glGetIntegerv(0x84FF /* GL_MAX_TEXTURE_MAX_ANISOTROPY */, &maxA);
    if (std::getenv("BR9_NOANISO")) maxA = 1;  // (testing: software GL bands with it)
    gAniso = maxAniso = (float)std::min(maxA, 16);
  }
  glGetError();
  struct { Shader* s; const char* vs; const char* fs; const char* name; } progs[] = {
      {&world, kWorldVS, kWorldFS, "world"},     {&shadow, kWorldVS, kShadowFS, "shadow"},     {&ssao_, kFullVS, kSsaoFS, "ssao"},
      {&vol_, kFullVS, kVolFS, "volumetric"},    {&comp_, kFullVS, kCompFS, "composite"},      {&down_, kFullVS, kDownFS, "bloom down"},
      {&up_, kFullVS, kUpFS, "bloom up"},        {&tonemap_, kFullVS, kTonemapFS, "tonemap"}, {&fxaa_, kFullVS, kFxaaFS, "fxaa"},
      {&ui_, kUiVS, kUiFS, "ui"}};
  for (auto& p : progs)
    if (!p.s->build(p.vs, p.fs, err)) { err = std::string(p.name) + " shader: " + err; return false; }

  glGenVertexArrays(1, &emptyVao_);

  std::vector<uint8_t> font(128 * 64, 0);
  for (int c = 0; c < 128; ++c)
    for (int row = 0; row < 8; ++row)
      for (int col = 0; col < 8; ++col)
        if (font8x8_basic[c][row] & (1 << col)) font[((c / 16) * 8 + row) * 128 + (c % 16) * 8 + col] = 255;
  glGenTextures(1, &fontTex_);
  glBindTexture(GL_TEXTURE_2D, fontTex_);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, 128, 64, 0, GL_RED, GL_UNSIGNED_BYTE, font.data());
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

  glGenVertexArrays(1, &uiVao_);
  glGenBuffers(1, &uiVbo_);
  glBindVertexArray(uiVao_);
  glBindBuffer(GL_ARRAY_BUFFER, uiVbo_);
  const GLsizei stride = 8 * sizeof(float);
  glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride, (void*)0);
  glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)(2 * sizeof(float)));
  glEnableVertexAttribArray(2); glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, stride, (void*)(4 * sizeof(float)));
  glBindVertexArray(0);
  return true;
}

Renderer::Target Renderer::makeTarget(int w, int h, GLenum ifmt, GLenum fmt, GLenum type, bool linear) {
  Target t;
  t.w = std::max(w, 1); t.h = std::max(h, 1);
  glGenTextures(1, &t.tex);
  glBindTexture(GL_TEXTURE_2D, t.tex);
  glTexImage2D(GL_TEXTURE_2D, 0, ifmt, t.w, t.h, 0, fmt, type, nullptr);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, linear ? GL_LINEAR : GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, linear ? GL_LINEAR : GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glGenFramebuffers(1, &t.fbo);
  glBindFramebuffer(GL_FRAMEBUFFER, t.fbo);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, t.tex, 0);
  if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE && ifmt == GL_RGBA16F) {
    glBindTexture(GL_TEXTURE_2D, t.tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, t.w, t.h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
  }
  glBindFramebuffer(GL_FRAMEBUFFER, 0);
  return t;
}

void Renderer::freeTarget(Target& t) {
  if (t.fbo) glDeleteFramebuffers(1, &t.fbo);
  if (t.tex) glDeleteTextures(1, &t.tex);
  t = Target();
}

void Renderer::bindTarget(const Target& t) {
  glBindFramebuffer(GL_FRAMEBUFFER, t.fbo);
  glViewport(0, 0, t.w, t.h);
}

void Renderer::fullscreen() {
  glBindVertexArray(emptyVao_);
  glDrawArrays(GL_TRIANGLES, 0, 3);
}

void Renderer::destroyTargets() {
  if (sceneFbo_) glDeleteFramebuffers(1, &sceneFbo_);
  if (sceneColor_) glDeleteTextures(1, &sceneColor_);
  if (sceneDepth_) glDeleteTextures(1, &sceneDepth_);
  sceneFbo_ = sceneColor_ = sceneDepth_ = 0;
  freeTarget(ao_); freeTarget(vol_t_); freeTarget(comp_t_); freeTarget(ldr_); freeTarget(ldrPrev_); freeTarget(tape_);
  for (auto& b : bloom_) freeTarget(b);
  bloom_.clear();
}

void Renderer::rebuildShadow() {
  if (shadowFbo_) glDeleteFramebuffers(1, &shadowFbo_);
  if (shadowTex) glDeleteTextures(1, &shadowTex);
  shadowFbo_ = shadowTex = 0;
  shadowSize_ = quality.shadowSize;
  if (!shadowSize_) return;
  glGenTextures(1, &shadowTex);
  glBindTexture(GL_TEXTURE_2D, shadowTex);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, shadowSize_, shadowSize_, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
  const float border[4] = {1, 1, 1, 1};
  glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, border);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
  glGenFramebuffers(1, &shadowFbo_);
  glBindFramebuffer(GL_FRAMEBUFFER, shadowFbo_);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, shadowTex, 0);
  glDrawBuffer(GL_NONE);
  glReadBuffer(GL_NONE);
  if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
    std::fprintf(stderr, "[br9] shadow map unsupported, disabling\n");
    glDeleteFramebuffers(1, &shadowFbo_);
    glDeleteTextures(1, &shadowTex);
    shadowFbo_ = shadowTex = 0;
    shadowSize_ = 0;
  }
  glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

bool Renderer::beginSunShadow(const mat4& lightVP) {
  if (!sunFbo_) {
    glGenTextures(1, &sunTex);
    glBindTexture(GL_TEXTURE_2D, sunTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, kSunSize, kSunSize, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
    const float border[4] = {0, 0, 0, 0};  // outside the map: in shade
    glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, border);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
    glGenFramebuffers(1, &sunFbo_);
    glBindFramebuffer(GL_FRAMEBUFFER, sunFbo_);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, sunTex, 0);
    glDrawBuffer(GL_NONE);
    glReadBuffer(GL_NONE);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
      glBindFramebuffer(GL_FRAMEBUFFER, 0);
      return false;
    }
  }
  glBindFramebuffer(GL_FRAMEBUFFER, sunFbo_);
  glViewport(0, 0, kSunSize, kSunSize);
  glClear(GL_DEPTH_BUFFER_BIT);
  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LESS);
  glDisable(GL_CULL_FACE);
  glEnable(GL_POLYGON_OFFSET_FILL);
  glPolygonOffset(2.0f, 4.0f);
  shadow.use();
  shadow.set("uViewProj", lightVP);
  shadow.set("uModel", mat4::identity());
  shadow.set("uSkinned", 0);
  return true;
}

void Renderer::setQuality(int q) {
  quality = qualityPreset(q);
  rebuildShadow();
  resize(winW, winH);
}

void Renderer::resize(int w, int h) {
  winW = std::max(w, 1); winH = std::max(h, 1);
  rtW = std::max(1, (int)(winW * quality.renderScale));
  rtH = std::max(1, (int)(winH * quality.renderScale));
  destroyTargets();

  glGenTextures(1, &sceneColor_);
  glBindTexture(GL_TEXTURE_2D, sceneColor_);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, rtW, rtH, 0, GL_RGBA, GL_HALF_FLOAT, nullptr);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glGenTextures(1, &sceneDepth_);
  glBindTexture(GL_TEXTURE_2D, sceneDepth_);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, rtW, rtH, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glGenFramebuffers(1, &sceneFbo_);
  glBindFramebuffer(GL_FRAMEBUFFER, sceneFbo_);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, sceneColor_, 0);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, sceneDepth_, 0);
  if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
    glBindTexture(GL_TEXTURE_2D, sceneColor_);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, rtW, rtH, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    std::fprintf(stderr, "[br9] HDR target unsupported, using 8-bit\n");
  }
  glBindFramebuffer(GL_FRAMEBUFFER, 0);

  int hw = std::max(1, rtW / 2), hh = std::max(1, rtH / 2);
  ao_ = makeTarget(hw, hh, GL_R8, GL_RED, GL_UNSIGNED_BYTE, true);
  vol_t_ = makeTarget(hw, hh, GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, true);
  comp_t_ = makeTarget(rtW, rtH, GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, true);
  ldr_ = makeTarget(winW, winH, GL_RGBA8, GL_RGBA, GL_UNSIGNED_BYTE, true);
  ldrPrev_ = makeTarget(winW, winH, GL_RGBA8, GL_RGBA, GL_UNSIGNED_BYTE, true);
  hadPrevLdr_ = false;
  tape_ = makeTarget(winW, winH, GL_RGBA8, GL_RGBA, GL_UNSIGNED_BYTE, true);
  int bw = rtW, bh = rtH;
  for (int i = 0; i < 6; ++i) {
    bw = std::max(1, bw / 2); bh = std::max(1, bh / 2);
    bloom_.push_back(makeTarget(bw, bh, GL_RGBA16F, GL_RGBA, GL_HALF_FLOAT, true));
  }
}

bool Renderer::beginShadow(const mat4& lightVP) {
  if (!shadowFbo_) return false;
  glBindFramebuffer(GL_FRAMEBUFFER, shadowFbo_);
  glViewport(0, 0, shadowSize_, shadowSize_);
  glClear(GL_DEPTH_BUFFER_BIT);
  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LESS);
  glDisable(GL_CULL_FACE);
  glEnable(GL_POLYGON_OFFSET_FILL);
  glPolygonOffset(1.5f, 3.0f);
  shadow.use();
  shadow.set("uViewProj", lightVP);
  shadow.set("uModel", mat4::identity());
  shadow.set("uSkinned", 0);
  return true;
}

void Renderer::endShadow() {
  glDisable(GL_POLYGON_OFFSET_FILL);
  glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void Renderer::beginScene() {
  glBindFramebuffer(GL_FRAMEBUFFER, sceneFbo_);
  glViewport(0, 0, rtW, rtH);
  glClearColor(0, 0, 0, 1);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LEQUAL);
  glEnable(GL_CULL_FACE);
  glCullFace(GL_BACK);
  glDisable(GL_BLEND);
}

void Renderer::endScene() { glBindFramebuffer(GL_FRAMEBUFFER, 0); }

void Renderer::present(const PostParams& p) {
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_CULL_FACE);
  glDisable(GL_BLEND);
  auto tex = [](int unit, GLuint t) { glActiveTexture(GL_TEXTURE0 + unit); glBindTexture(GL_TEXTURE_2D, t); };
  mat4 vp = p.proj * p.view;

  if (quality.ssao) {
    bindTarget(ao_);
    ssao_.use();
    tex(0, sceneDepth_);
    ssao_.set("uDepth", 0);
    ssao_.set("uProj", p.proj);
    ssao_.set("uInvProj", inverse(p.proj));
    ssao_.set("uFullRes", (float)rtW, (float)rtH);
    fullscreen();
  }
  if (quality.volumetrics) {
    bindTarget(vol_t_);
    vol_.use();
    tex(0, sceneDepth_);
    tex(1, shadowTex);
    tex(2, p.lightmap);
    tex(3, p.lightState);
    vol_.set("uDepth", 0);
    vol_.set("uShadow", 1);
    vol_.set("uLightmap", 2);
    vol_.set("uLightState", 3);
    vol_.set("uShadowOn", shadowTex ? 1 : 0);
    vol_.set("uInvViewProj", inverse(vp));
    vol_.set("uShadowVP", p.shadowVP);
    vol_.set("uCamPos", p.camPos);
    vol_.set("uFlashPos", p.flashPos);
    vol_.set("uFlashDir", p.flashDir);
    vol_.set("uFlash", p.flash);
    vol_.set("uLMSize", p.lmW, p.lmH);
    vol_.set("uLMPerMeter", p.lmPerMeter);
    vol_.set("uTime", p.time);
    vol_.set("uWallH", p.wallH);
    vol_.set("uLightColor", p.lightColor);
    tex(4, sunTex);
    vol_.set("uSunShadow", 4);
    vol_.set("uSunOn", (p.sunOn && sunTex) ? 1 : 0);
    vol_.set("uSunVP", p.sunVP);
    vol_.set("uSunDir", p.sunDir);
    vol_.set("uSunColor", p.sunColor);
    fullscreen();
  }
  bindTarget(comp_t_);
  comp_.use();
  tex(0, sceneColor_);
  tex(1, ao_.tex);
  tex(2, vol_t_.tex);
  comp_.set("uScene", 0);
  comp_.set("uAO", 1);
  comp_.set("uVol", 2);
  comp_.set("uUseAO", quality.ssao ? 1 : 0);
  comp_.set("uUseVol", quality.volumetrics && !std::getenv("BR9_NOVOL") ? 1 : 0);
  comp_.set("uHalfTexel", 1.0f / ao_.w, 1.0f / ao_.h);
  tex(3, sceneDepth_);
  comp_.set("uDepth", 3);
  comp_.set("uInvVP", inverse(vp));
  comp_.set("uVP", vp);
  comp_.set("uPrevVP", p.hasPrev ? p.prevViewProj : vp);
  comp_.set("uCamPos", p.camPos);
  comp_.set("uGloss", p.floorGloss);
  comp_.set("uMotion", p.hasPrev ? p.motion : 0.0f);
  comp_.set("uTexel", 1.0f / rtW, 1.0f / rtH);
  comp_.set("uSSR", quality.ssao ? 1 : 0);
  fullscreen();

  if (quality.bloom) {
    down_.use();
    down_.set("uSrc", 0);
    GLuint src = comp_t_.tex;
    int sw = comp_t_.w, sh = comp_t_.h;
    for (size_t i = 0; i < bloom_.size(); ++i) {
      bindTarget(bloom_[i]);
      tex(0, src);
      down_.set("uTexel", 1.0f / sw, 1.0f / sh);
      down_.set("uPrefilter", i == 0 ? 1 : 0);
      fullscreen();
      src = bloom_[i].tex; sw = bloom_[i].w; sh = bloom_[i].h;
    }
    up_.use();
    up_.set("uSrc", 0);
    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ONE);
    for (int i = (int)bloom_.size() - 1; i > 0; --i) {
      bindTarget(bloom_[i - 1]);
      tex(0, bloom_[i].tex);
      up_.set("uTexel", 1.0f / bloom_[i].w, 1.0f / bloom_[i].h);
      fullscreen();
    }
    glDisable(GL_BLEND);
  }

  bindTarget(ldr_);
  tonemap_.use();
  tex(0, comp_t_.tex);
  tex(1, bloom_.empty() ? comp_t_.tex : bloom_[0].tex);
  tonemap_.set("uScene", 0);
  tonemap_.set("uBloom", 1);
  tonemap_.set("uTime", p.time);
  tonemap_.set("uExposure", p.exposure);
  tonemap_.set("uBloomAmt", quality.bloom ? (p.vhs ? 0.09f : 0.08f) * p.bloom : 0.0f);  // a cheap lens glows round the tubes
  tonemap_.set("uStatic", p.staticAmt);
  tonemap_.set("uFear", p.fear);
  tonemap_.set("uNight", p.night);
  tonemap_.set("uFocus", p.focus);
  {
    float fw = p.frame43 ? std::min(1.0f, (winH * 4.0f / 3.0f) / (float)winW) : 1.0f;
    tonemap_.set("uFrameX0", (1.0f - fw) * 0.5f);
    tonemap_.set("uFrameW", fw);
  }
  tonemap_.set("uPan", p.pan);
  tonemap_.set("uBanding", p.vhs ? p.banding : 0.0f);
  tonemap_.set("uJolt", p.vhs ? p.jolt : 0.0f);
  tonemap_.set("uScar", p.scar);
  tonemap_.set("uScarY", p.scarY);
  tonemap_.set("uVHS", p.vhs ? 1 : 0);
  tonemap_.set("uWet", p.wet);
  tonemap_.set("uGradeGain", p.gradeGain);
  tonemap_.set("uGradeLift", p.gradeLift);
  tex(3, ldrPrev_.tex);
  tonemap_.set("uPrev", 3);
  tonemap_.set("uLag", (p.vhs && p.hasPrev && hadPrevLdr_) ? p.lag : 0.0f);
  tonemap_.set("uTapeWear", p.vhs ? p.tapeWear : 0.0f);
  tonemap_.set("uTapeSeed", p.tapeSeed);
  tex(2, tape_.tex);
  tonemap_.set("uTape", 2);
  tonemap_.set("uTapeOn", tapeUsed_ ? 1 : 0);
  tapeUsed_ = false;
  fullscreen();

  glBindFramebuffer(GL_FRAMEBUFFER, 0);
  glViewport(0, 0, winW, winH);
  fxaa_.use();
  tex(0, ldr_.tex);
  fxaa_.set("uSrc", 0);
  fxaa_.set("uRes", (float)winW, (float)winH);
  fxaa_.set("uFxaa", quality.fxaa ? 1 : 0);
  fxaa_.set("uVHS", p.vhs ? 1 : 0);
  fxaa_.set("uTime", p.time);
  fxaa_.set("uGrain", p.grain);
  fxaa_.set("uStatic", p.staticAmt);
  fxaa_.set("uFade", p.fade);
  fxaa_.set("uTapeWear", p.vhs ? p.tapeWear : 0.0f);
  fullscreen();
  glActiveTexture(GL_TEXTURE0);
  std::swap(ldr_, ldrPrev_);  // this frame is next frame's "last frame"
  hadPrevLdr_ = true;
}

void Renderer::beginUI() { uiVerts_.clear(); }

void Renderer::sprites(GLuint tex, const std::vector<float>& v) {
  if (v.empty()) return;
  endUI();  // keep draw order
  glBindFramebuffer(GL_FRAMEBUFFER, uiFbo_);
  glViewport(uiOffX, 0, winW, winH);
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_CULL_FACE);
  glEnable(GL_BLEND);
  glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
  ui_.use();
  ui_.set("uScreen", (float)winW, (float)winH);
  ui_.set("uFont", 0);
  ui_.set("uImage", 1);
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, tex);
  glBindVertexArray(uiVao_);
  glBindBuffer(GL_ARRAY_BUFFER, uiVbo_);
  glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(v.size() * sizeof(float)), v.data(), GL_STREAM_DRAW);
  glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(v.size() / 8));
  ui_.set("uImage", 0);
  glDisable(GL_BLEND);
}

void Renderer::beginTapeUI() {
  endUI();
  uiFbo_ = tape_.fbo;
  glBindFramebuffer(GL_FRAMEBUFFER, uiFbo_);
  glViewport(0, 0, winW, winH);
  glClearColor(0, 0, 0, 0);
  glClear(GL_COLOR_BUFFER_BIT);
}

void Renderer::endTapeUI() {
  endUI();
  uiFbo_ = 0;
  tapeUsed_ = true;
  glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

static void pushQuad(std::vector<float>& v, float x0, float y0, float x1, float y1, float u0, float v0, float u1, float v1,
                     float r, float g, float b, float a) {
  float q[6][4] = {{x0, y0, u0, v0}, {x1, y0, u1, v0}, {x1, y1, u1, v1}, {x0, y0, u0, v0}, {x1, y1, u1, v1}, {x0, y1, u0, v1}};
  for (auto& p : q) v.insert(v.end(), {p[0], p[1], p[2], p[3], r, g, b, a});
}

void Renderer::rect(float x, float y, float w, float h, float r, float g, float b, float a) {
  pushQuad(uiVerts_, x, y, x + w, y + h, -1, -1, -1, -1, r, g, b, a);
}

void Renderer::text(const std::string& s, float x, float y, float scale, float r, float g, float b, float a) {
  float cx = x, sz = 8.0f * scale;
  for (unsigned char c : s) {
    if (c == '\n') { cx = x; y += sz * 1.5f; continue; }
    if (c >= 128) c = '?';
    float u0 = (c % 16) * 8 / 128.0f, v0 = (c / 16) * 8 / 64.0f;
    if (c != ' ') pushQuad(uiVerts_, cx, y, cx + sz, y + sz, u0, v0, u0 + 8 / 128.0f, v0 + 8 / 64.0f, r, g, b, a);
    cx += sz;
  }
}

void Renderer::endUI() {
  if (uiVerts_.empty()) return;
  glBindFramebuffer(GL_FRAMEBUFFER, uiFbo_);
  glViewport(uiOffX, 0, winW, winH);
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_CULL_FACE);
  glEnable(GL_BLEND);
  glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);  // keeps tape alpha honest
  ui_.use();
  ui_.set("uScreen", (float)winW, (float)winH);
  ui_.set("uFont", 0);
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, fontTex_);
  glBindVertexArray(uiVao_);
  glBindBuffer(GL_ARRAY_BUFFER, uiVbo_);
  glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(uiVerts_.size() * sizeof(float)), uiVerts_.data(), GL_STREAM_DRAW);
  ui_.set("uImage", 0);
  glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(uiVerts_.size() / 8));
  glDisable(GL_BLEND);
  uiVerts_.clear();
}

void Renderer::image(GLuint tex, float x, float y, float w, float h, float a) {
  endUI();  // keep draw order: everything queued so far goes first
  std::vector<float> v;
  pushQuad(v, x, y, x + w, y + h, 0, 0, 1, 1, 1, 1, 1, a);
  glBindFramebuffer(GL_FRAMEBUFFER, uiFbo_);
  glViewport(uiOffX, 0, winW, winH);
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_CULL_FACE);
  glEnable(GL_BLEND);
  glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);  // keeps tape alpha honest
  ui_.use();
  ui_.set("uScreen", (float)winW, (float)winH);
  ui_.set("uFont", 0);
  ui_.set("uImage", 1);
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, tex);
  glBindVertexArray(uiVao_);
  glBindBuffer(GL_ARRAY_BUFFER, uiVbo_);
  glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(v.size() * sizeof(float)), v.data(), GL_STREAM_DRAW);
  glDrawArrays(GL_TRIANGLES, 0, 6);
  ui_.set("uImage", 0);
  glDisable(GL_BLEND);
}

bool Renderer::readPixels(std::vector<uint8_t>& rgb, int& w, int& h) {
  w = winW; h = winH;
  rgb.resize((size_t)w * h * 3);
  glBindFramebuffer(GL_FRAMEBUFFER, 0);
  glPixelStorei(GL_PACK_ALIGNMENT, 1);
  glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE, rgb.data());
  return glGetError() == GL_NO_ERROR;
}

void Renderer::shutdown() {
  destroyTargets();
  if (shadowFbo_) glDeleteFramebuffers(1, &shadowFbo_);
  if (shadowTex) glDeleteTextures(1, &shadowTex);
  if (fontTex_) glDeleteTextures(1, &fontTex_);
  if (uiVbo_) glDeleteBuffers(1, &uiVbo_);
  if (uiVao_) glDeleteVertexArrays(1, &uiVao_);
  if (emptyVao_) glDeleteVertexArrays(1, &emptyVao_);
}
