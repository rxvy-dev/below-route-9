// Ray tracing support. The Backrooms are a tile grid with walls on tile edges, so the world
// shader can trace real rays through it (2D DDA plus heights) without RT hardware:
//   - a grid texture: per tile, which edges have walls, pillars, solid fill, open sky, and
//     which ceiling fixture hangs there
//   - a light table: every fixture's position, brightness, live-state id and kind
//   - capsules for the people and things walking around, so they cast shadows too
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>

#include "game.h"

void Game::buildRTTextures() {
  const int W = level_.W, H = level_.H;
  std::vector<uint8_t> g((size_t)W * H * 4, 0);
  for (int z = 0; z < H; ++z)
    for (int x = 0; x < W; ++x) {
      int i = level_.idx(x, z);
      int r = 0;
      if (level_.eWall[i] == 1) r |= 1;   // wall on the east edge (visible walls only)
      if (level_.sWall[i] == 1) r |= 2;   // wall on the south edge
      if (level_.pillar[i]) r |= 4;
      if (!level_.solid.empty() && level_.solid[i]) r |= 8;
      if ((!level_.zone.empty() && level_.zone[i] == 3) || level_.isSky(x, z)) r |= 16;  // open to the sky
      if (!level_.pool.empty() && level_.pool[i]) r |= 32;
      int li = level_.lightAtTile.empty() ? 0 : level_.lightAtTile[i] + 1;
      uint8_t* p = &g[(size_t)i * 4];
      p[0] = (uint8_t)r;
      p[1] = (uint8_t)(li & 255);
      p[2] = (uint8_t)((li >> 8) & 255);
      p[3] = 0;
    }
  auto make = [](GLuint& tex) {
    if (!tex) glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  };
  make(texRTGrid_);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, W, H, 0, GL_RGBA, GL_UNSIGNED_BYTE, g.data());
  int n = std::max(1, (int)level_.lights.size());
  std::vector<float> t((size_t)n * 2 * 4, 0.0f);
  for (int i = 0; i < (int)level_.lights.size(); ++i) {
    const Light& L = level_.lights[i];
    float* a = &t[(size_t)i * 4];
    a[0] = L.pos.x; a[1] = L.pos.y; a[2] = L.pos.z; a[3] = L.intensity;
    float* b = &t[((size_t)n + i) * 4];
    b[0] = (float)L.id; b[1] = (float)L.kind;
  }
  make(texRTLights_);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F, n, 2, 0, GL_RGBA, GL_FLOAT, t.data());
  glBindTexture(GL_TEXTURE_2D, 0);
}

void Game::rtBind(Shader& S, vec3 cam) {
  bool on = settings.rt && texRTGrid_ && levelIndex_ != kChoiceLevel && !level_.theme.outdoor && !std::getenv("BR9_NORT");
  S.set("uRT", on ? 1 : 0);
  S.set("uRTSamples", settings.quality >= 2 ? 4 : 2);  // smooth soft shadows on high, cheaper below
  if (!on) return;
  glActiveTexture(GL_TEXTURE0 + 8); glBindTexture(GL_TEXTURE_2D, texRTGrid_);
  glActiveTexture(GL_TEXTURE0 + 9); glBindTexture(GL_TEXTURE_2D, texRTLights_);
  glActiveTexture(GL_TEXTURE0 + 10); glBindTexture(GL_TEXTURE_2D, texWall_ ? texWall_ : texWhite_);
  glActiveTexture(GL_TEXTURE0 + 11); glBindTexture(GL_TEXTURE_2D, texCeil_ ? texCeil_ : texWhite_);
  glActiveTexture(GL_TEXTURE0);
  S.set("uRTGrid", 8);
  S.set("uRTLights", 9);
  S.set("uRTWall", 10);
  S.set("uRTCeil", 11);
  S.set("uGridSize", (float)level_.W, (float)level_.H);
  S.set("uPanel", level_.theme.panelW * 0.5f, level_.theme.panelL * 0.5f);
  // People and things near you, as capsules: x, z, radius, height.
  vec4 caps[8];
  int n = 0;
  auto add = [&](vec3 p, float r, float h) {
    if (n >= 8) return;
    vec3 q = near(p, cam);
    vec3 d = q - cam;
    if (d.x * d.x + d.z * d.z > 18.0f * 18.0f) return;
    caps[n++] = {q.x, q.z, r, q.y + h};
  };
  auto heightOf = [](int kind) {
    switch (kind) {
      case CR_TENANT: return 2.6f;
      case CR_HOUND: return 1.0f;
      case CR_GRIN: return 2.1f;
      case CR_STILT: return 3.4f;
      default: return 1.8f;
    }
  };
  for (const Stalker& s : stalkers_) if (s.active()) add(s.pos, s.kind == CR_HOUND ? 0.4f : 0.3f, heightOf(s.kind));
  for (const Grin& g : grins_) add(g.pos, 0.3f, 2.1f);
  for (const Npc& c : customers_) add(c.pos, 0.27f, 1.75f);
  if (rayLevel_ == levelIndex_ && rayState_ <= 1) add(rayPos_, 0.35f, 0.5f);
  S.set("uCapN", n);
  for (int i = 0; i < n; ++i) {
    char nm[16];
    std::snprintf(nm, sizeof nm, "uCaps[%d]", i);
    S.set(nm, caps[i]);
  }
}
