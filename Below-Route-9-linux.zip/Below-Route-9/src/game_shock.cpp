// Things that should not happen: the phone in the wall, the clerk across the water,
// the thing wearing Ray, the locker that's already occupied, and the tape.
#include "game.h"
#include <cmath>
#include <cstdio>
#include <fstream>

namespace {
const vec4 kDanaLook[4] = {{0.7f, 0.52f, 0.42f, 0}, {0.16f, 0.09f, 0.05f, 0}, {0.55f, 0.07f, 0.06f, 0}, {0.1f, 0.12f, 0.2f, 0}};
const vec4 kRayThing[4] = {{0.46f, 0.43f, 0.41f, 0}, {0.3f, 0.29f, 0.28f, 0}, {0.07f, 0.12f, 0.24f, 0}, {0.06f, 0.1f, 0.18f, 0}};
const char* kRayThingLines[] = {"Kid? It's me. Ray. I got out. Come here.", "Why are you walking away? It's me.",
                                "Kid. Kid. Kid. Kid. Kid.", "I'm not mad. Come here and look at me."};
}  // namespace

const vec4* Game::rayThingLook() const { return kRayThing; }

void Game::shockReset() {
  phoneState_ = 0;
  ghostState_ = 0;
  ghostT_ = ghostLook_ = 0;
  rayThingTalk_ = 12;
  huntDelay_ = -1;
  if (levelIndex_ == 1) {
    // A wall phone a little way down the real route, ringing.
    std::vector<int> d = level_.bfs(level_.startX, level_.startZ);
    std::vector<int> cands;
    for (int i = 0; i < level_.W * level_.H; ++i)
      if (d[i] >= 4 && d[i] <= 10 && !level_.pillar[i] && !level_.pool[i]) {
        int x = i % level_.W, z = i / level_.W;
        bool wall = false;
        for (int k = 0; k < 4; ++k) wall |= level_.blocked(x, z, k) && !level_.hasPillar(x + kDX[k], z + kDZ[k]);
        if (wall) cands.push_back(i);
      }
    if (!cands.empty()) {
      int c = cands[rng_.next() % cands.size()];
      int x = c % level_.W, z = c / level_.W;
      for (int k = 0; k < 4; ++k)
        if (level_.blocked(x, z, k) && !level_.hasPillar(x + kDX[k], z + kDZ[k])) {
          vec3 dir{(float)kDX[k], 0, (float)kDZ[k]};
          phonePos_ = level_.tileCenter(x, z, 1.45f) + dir * (Level::kTile * 0.5f - Level::kWallT * 0.5f - 0.05f);
          phoneNormal_ = dir * -1.0f;
          phoneState_ = 1;
          phoneRing_ = 0;
          break;
        }
    }
  }
}

bool Game::shockInteract() {
  if (phoneState_ != 1) return false;
  vec3 d = level_.delta(pos_, phonePos_);
  if (std::sqrt(d.x * d.x + d.z * d.z) > 1.7f) return false;
  phoneState_ = 2;
  phoneT_ = 0;
  lines_.clear();
  lineTime_ = 0;
  if (A_) A_->play(Sfx::Click, 0.7f);
  say("PHONE", "(static... a store radio, far away... easy listening...)", 3.2f);
  say("MOM (ON THE PHONE)", "Hi, yes, Route 9 Park? I can't find my kid. Nine, red shirt-", 2.8f);
  say("MOM (ON THE PHONE)", "...I can hear breathing. Who is this?", 2.8f);
  say("MOM (ON THE PHONE)", "Hold on, the lights are doing something. Honey? Is that you? Honey, the floor's-", 3.6f);
  say("???", "(It's your voice. It's tonight. It's still tonight.)", 3.4f);
  return true;
}

std::string Game::shockPrompt() const {
  if (phoneState_ != 1) return "";
  vec3 d = level_.delta(pos_, phonePos_);
  if (std::sqrt(d.x * d.x + d.z * d.z) > 1.7f) return "";
  return std::string(usingPad_ ? "[A]" : "[E]") + " ANSWER THE PHONE";
}

void Game::shockUpdate(float dt) {
  // The phone rings until you answer it. Then everything wakes up.
  if (phoneState_ == 1) {
    phoneRing_ -= dt;
    if (phoneRing_ <= 0) {
      phoneRing_ = 3.2f;
      vec3 to = level_.delta(pos_, phonePos_);
      float dist = std::sqrt(to.x * to.x + to.z * to.z);
      vec3 f = forward(), r{-f.z, 0, f.x};
      float pan = dist > 0.1f ? dot(to * (1.0f / dist), normalize(r)) : 0.0f;
      if (A_ && dist < 40) A_->play(Sfx::PhoneRing, clampf(1.4f / (1.0f + dist * 0.15f), 0.05f, 1.0f), pan, 1.9f);
    }
  } else if (phoneState_ == 2) {
    phoneT_ += dt;
    if (phoneT_ > 15.0f) {
      phoneState_ = 3;
      if (A_) { A_->play(Sfx::Slam, 0.9f); A_->play(Sfx::Brownout, 1.0f); }
      brownout_ = 1.0f;
      for (float& t : spawnAt_) t = std::min(t, playTime_);  // everything down here heard that
      huntDelay_ = 1.2f;
    }
  }
  if (huntDelay_ > 0) {
    huntDelay_ -= dt;
    if (huntDelay_ <= 0 && beginHunt(22.0f)) { toast_ = "IT HEARD THE PHONE. RUN."; toastTime_ = 3.0f; }
  }

  // Level 3: you, across the water.
  ghostRetry_ -= dt;
  if (levelIndex_ == 3 && ghostState_ == 0 && playTime_ > 35.0f && ghostRetry_ <= 0) {
    vec3 f = forward();
    vec3 fh = normalize(vec3{f.x, 0, f.z});
    for (float dd = 22.0f; dd >= 15.0f; dd -= 1.0f) {
      vec3 p = level_.wrap(pos_ + fh * dd);
      int tx, tz;
      level_.tileOf(p.x, p.z, tx, tz);
      if (level_.pool[level_.idx(tx, tz)] || !level_.lineOfSight(pos_.x, pos_.z, p.x, p.z)) continue;
      ghostPos_ = level_.tileCenter(tx, tz);
      ghostState_ = 1;
      ghostT_ = ghostLook_ = 0;
      break;
    }
  } else if (ghostState_ == 1) {
    ghostT_ += dt;
    vec3 to = level_.delta(pos_, ghostPos_);
    float dist = std::sqrt(to.x * to.x + to.z * to.z);
    vec3 f = forward();
    bool looking = dist > 0.1f && dot(normalize(vec3{to.x, 0, to.z}), normalize(vec3{f.x, 0, f.z})) > 0.96f &&
                   level_.lineOfSight(pos_.x, pos_.z, ghostPos_.x, ghostPos_.z);
    if (looking) ghostLook_ += dt;
    if (dist < 9.0f || ghostLook_ > 1.8f || ghostT_ > 12.0f) {
      ghostState_ = ghostLook_ > 0.3f || dist < 9.0f ? 2 : 0;
      if (ghostState_ == 2) {
        if (A_) A_->play(Sfx::Whoosh, 0.5f, 0, 1.6f);
        lines_.clear();
        lineTime_ = 0;
        say("YOU", "(...that was me. That was my shirt.)", 3.2f);
      } else {
        ghostRetry_ = 15.0f;  // you never saw her; she'll try again
      }
    }
  }

  // The thing wearing Ray talks to you before it runs.
  rayThingTalk_ -= dt;
  for (const Stalker& s : stalkers_) {
    if (s.kind != CR_HUMAN || !s.active()) continue;
    vec3 to = level_.delta(pos_, s.pos);
    float dist = std::sqrt(to.x * to.x + to.z * to.z);
    if (rayThingTalk_ <= 0 && dist < 24.0f && s.state != Stalker::Chase && lines_.empty()) {
      say("RAY?", kRayThingLines[rng_.next() % 4], 3.0f);
      rayThingTalk_ = rng_.range(9.0f, 14.0f);
    }
  }
}

void Game::shockDraw(Shader& S, vec3 cam) {
  if (phoneState_ >= 1 && phoneState_ <= 2) {
    S.set("uMat", MAT_PROP);
    S.set("uSkinned", 0);
    glBindTexture(GL_TEXTURE_2D, texWhite_);
    vec3 p = near(phonePos_, cam);
    float yaw = std::atan2(phoneNormal_.x, phoneNormal_.z);
    float shake = phoneState_ == 1 && std::fmod(time_, 3.2f) < 1.2f ? std::sin(time_ * 90.0f) * 0.004f : 0.0f;
    vec3 side = cross(vec3{0, 1, 0}, phoneNormal_);
    drawPart(translate(p) * rotY(yaw) * scale({0.3f, 0.46f, 0.1f}), {0.62f, 0.07f, 0.05f});                  // red payphone box
    drawPart(translate(p + phoneNormal_ * 0.055f + vec3{0, 0.04f, 0}) * rotY(yaw) * scale({0.12f, 0.16f, 0.02f}), {0.75f, 0.75f, 0.72f});  // keypad
    drawPart(translate(p + phoneNormal_ * 0.055f + vec3{0, 0.17f, 0}) * rotY(yaw) * scale({0.2f, 0.05f, 0.02f}), {0.9f, 0.88f, 0.8f}, 0.4f);  // card slot / label
    if (phoneState_ == 1)
      drawPart(translate(p + phoneNormal_ * 0.08f + side * (-0.11f + shake) + vec3{0, 0.0f, 0}) * rotY(yaw) * scale({0.06f, 0.3f, 0.06f}), {0.08f, 0.08f, 0.09f});  // the receiver, rattling
    drawPart(translate(p + vec3{0, 0.27f, 0} + phoneNormal_ * 0.06f) * scale({0.03f, 0.03f, 0.03f}), {1.0f, 0.2f, 0.1f},
             phoneState_ == 1 && std::fmod(time_, 0.6f) < 0.3f ? 3.0f : 0.2f);
  }
  if (ghostState_ == 1) {
    vec3 to = level_.delta(ghostPos_, pos_);
    Npc n;
    n.active = true;
    n.yaw = std::atan2(-to.x, -to.z);
    n.look = 0.25f * std::sin(time_ * 0.7f);
    for (int k = 0; k < 4; ++k) n.look4[k] = kDanaLook[k];
    n.outfit = hazmat_ ? 3 : 0;  // she's dressed like you are
    S.set("uMat", MAT_MODEL);
    glBindTexture(GL_TEXTURE_2D, texWhite_);
    vec3 p = near(ghostPos_, cam);
    p.y = level_.floorAt(ghostPos_.x, ghostPos_.z);
    drawNpc(S, n, p);
  }
}

bool Game::lockerScare(int prop) {
  if (lockerScareDone_ || levelIndex_ < 1 || anyChasing() || rng_.f01() > 0.22f) return false;
  lockerScareDone_ = true;
  const PropInstance& p = level_.props[prop];
  Grin g;
  g.pos = g.home = p.pos;
  g.active = true;
  g.alert = 1.0f;
  vec3 to = level_.delta(p.pos, pos_);
  g.yaw = std::atan2(-to.x, -to.z);
  grins_.push_back(g);
  scareGrin_ = (int)grins_.size() - 1;
  if (A_) { A_->play(Sfx::Giggle, 1.2f); A_->play(Sfx::ChaseSting, 1.0f); }
  toast_ = "SOMETHING WAS ALREADY IN THERE";
  toastTime_ = 3.0f;
  gotCaught(p.pos + vec3{0, 1.65f, 0});
  return true;
}

void Game::loadEndingFlag() {
  platform::KeyValueFile f;
  if (f.load(platform::dataDir() + "/tape.ini")) {
    endingSeen_ = f.geti("ending", 0);
    endingLeft_ = f.geti("left", 0) != 0;
  } else {
    endingSeen_ = 0;
  }
}

void Game::saveEndingFlag(int ending) {
  metaEnding(ending);
  if (!opt_.screenshot.empty()) return;
  platform::KeyValueFile f;
  f.seti("ending", ending);
  f.seti("left", leftRay_ && rayState_ != 2 ? 1 : 0);
  f.save(platform::dataDir() + "/tape.ini");
  endingSeen_ = ending;
  endingLeft_ = leftRay_ && rayState_ != 2;
}
