// The landing. Only the camcorder comes down: it cracks against the floor, bounces and lies on
// its side, still recording, looking down the longest stretch of floor it can see. Nothing
// moves for a while. Then footsteps come up behind it, a shadow leans over the lens, and it's
// lifted from behind and turned upright, still pointing the same way. Then you're playing.
#include <algorithm>
#include <cmath>

#include "audio.h"
#include "game.h"

namespace {
// timeline, seconds after hitting the floor
constexpr float kHit = 0.45f, kSettle = 0.78f, kReach = 5.0f, kLift = 5.8f, kDone = 6.55f;  // ~5 s on the floor
float wrapA(float a) { return std::remainder(a, 2.0f * kPi); }
float ease(float x) { x = std::clamp(x, 0.0f, 1.0f); return x * x * (3.0f - 2.0f * x); }
float span(float t, float a, float b) { return std::clamp((t - a) / (b - a), 0.0f, 1.0f); }
void orient(float yaw, float pitch, float roll, vec3& dir, vec3& up) {
  dir = {-std::sin(yaw) * std::cos(pitch), std::sin(pitch), -std::cos(yaw) * std::cos(pitch)};
  vec3 r = normalize(cross(dir, vec3{0, 1, 0}));
  vec3 u0 = cross(r, dir);
  up = u0 * std::cos(roll) + r * std::sin(roll);
}
}  // namespace

void Game::startDrop() {
  dropping_ = true;
  dropT_ = 0;
  dropCue_ = 0;
  vec3 p = pos_;
  level_.collide(p, 0.3f);
  dropBody_ = dropCam_ = dropKneel_ = p;
  // it ends up looking down the longest open stretch it can see
  float bestYaw = yaw_, bestRun = -1;
  for (int k = 0; k < 16; ++k) {
    float a = yaw_ + k * (kPi / 8.0f);
    vec3 f{-std::sin(a), 0, -std::cos(a)};
    float run = 0;
    while (run < 30.0f) {
      vec3 q = p + f * (run + 0.5f);
      if (!level_.lineOfSight(p.x, p.z, q.x, q.z, true)) break;
      run += 0.5f;
    }
    run += (k == 0) ? 1.0f : 0.0f;
    if (run > bestRun) { bestRun = run; bestYaw = a; }
  }
  dropBodyYaw_ = bestYaw;
  dropStartYaw_ = yaw_;
  if (A_) { A_->play(Sfx::Slam, 1.0f, 0, 0.75f); }
}

void Game::dropSkip() {
  if (dropping_ && dropT_ > 0.9f && dropT_ < kLift) dropT_ = kLift;
}

void Game::updateDrop(float dt) {
  dropT_ += dt;
  float t = dropT_;
  auto cue = [&](int i, float at, Sfx s, float g, float pitch) {
    if (t >= at && !(dropCue_ & (1 << i))) { dropCue_ |= 1 << i; if (A_) A_->play(s, g, 0, pitch); }
  };
  cue(0, kHit, Sfx::Clatter, 1.0f, 1.0f);
  cue(1, kSettle - 0.05f, Sfx::Clatter, 0.35f, 1.0f);
  // footsteps coming up behind it, slow, then closer
  cue(2, kReach - 1.9f, Sfx::Footstep, 0.18f, 0.85f);
  cue(3, kReach - 1.3f, Sfx::Footstep, 0.26f, 0.82f);
  cue(4, kReach - 0.75f, Sfx::Footstep, 0.36f, 0.86f);
  cue(5, kReach - 0.25f, Sfx::Footstep, 0.45f, 0.8f);
  cue(6, kLift + 0.05f, Sfx::Click, 0.6f, 1.0f);      // grabbed
  cue(7, kLift + 0.35f, Sfx::Grunt, 0.4f, 1.25f);     // a short breath, right behind the mic
  if (t >= kDone) {
    dropping_ = false;
    vec3 p = dropKneel_;
    level_.collide(p, 0.3f);
    resetPlayer(level_.wrap(p), dropBodyYaw_);
    screen_ = Screen::Playing;
    screenTime_ = 0;
    landDip_ = 0.2f;
    fear_ = 0.5f;
    hintTimer_ = 9.0f;
    hasPrevVP_ = false;
    if (wentBack_ && rayState_ != 2) { toast_ = "FIND RAY. BRING HIM HOME."; toastTime_ = 5.0f; }
    saveProgress();
  }
}

void Game::dropCamera(vec3& camPos, vec3& camDir, vec3& camUp, float& fov, PostParams& pp) {
  float t = dropT_;
  float floorY = level_.floorAt(dropCam_.x, dropCam_.z);
  float camFloorYaw = dropBodyYaw_;  // lying on its side, looking down the floor
  const float rollF = 1.38f, pitchF = 0.1f;
  vec3 dir, up;
  vec3 at;
  if (t < kSettle) {
    // knocked out of your hands: tumbling, hit, one bounce, still
    float u = std::min(1.0f, t / kHit);
    vec3 start = dropBody_ + vec3{0, 1.4f, 0};
    vec3 land = dropCam_ + vec3{0, 0.1f, 0};
    vec3 mid = level_.delta(start, land);
    at = start + mid * (t < kHit ? u * 0.9f : 0.9f + 0.1f * span(t, kHit, kSettle));
    float y = t < kHit ? 1.4f - 1.3f * u * u : 0.1f + 0.14f * std::sin(kPi * span(t, kHit, kSettle));
    at.y = floorY + y;
    float w = 1.0f - span(t, 0, kSettle);
    float yawT = dropStartYaw_ + wrapA(camFloorYaw - dropStartYaw_) * ease(span(t, 0, kSettle));
    float pitch = pitchF - 0.3f + std::sin(t * 17.0f) * 1.1f * w * w;
    float roll = rollF * ease(span(t, 0.1f, kSettle)) + std::sin(t * 13.0f) * 1.3f * w * w;
    orient(yawT, pitch, roll, dir, up);
    pp.staticAmt = std::max(pp.staticAmt, t > kHit && t < kHit + 0.12f ? 0.7f : 0.0f);
  } else if (t < kLift) {
    at = dropCam_;
    at.y = floorY + 0.1f;
    float wob = (t < kSettle + 0.25f) ? std::sin((t - kSettle) * 40.0f) * 0.05f * (1.0f - (t - kSettle) / 0.25f) : 0.0f;
    float nudge = t > kReach + 0.3f ? 0.03f * std::sin(t * 31.0f) * span(t, kReach + 0.3f, kLift) : 0.0f;  // something touching it
    orient(camFloorYaw, pitchF + wob, rollF + nudge, dir, up);
  } else {
    // lifted from behind and turned upright, still looking the same way
    float u = ease(span(t, kLift, kDone));
    vec3 floorP = dropCam_ + vec3{0, floorY + 0.1f, 0};
    vec3 f{-std::sin(camFloorYaw), 0, -std::cos(camFloorYaw)};
    at = floorP - f * (0.25f * std::sin(kPi * u));  // pulled back toward whoever has it, then out in front of them
    at.y = floorP.y + (1.45f) * (1.0f - (1.0f - u) * (1.0f - u));  // up fast, then settles
    float pitch = pitchF * (1.0f - u) - 0.35f * std::sin(kPi * u);
    float roll = rollF * (1.0f - ease(span(t, kLift, kLift + 0.55f))) + std::sin(t * 21.0f) * 0.05f * (1.0f - u);
    orient(camFloorYaw + 0.12f * std::sin(kPi * u), pitch, roll, dir, up);
    pp.staticAmt = std::max(pp.staticAmt, t < kLift + 0.08f ? 0.35f : 0.0f);
  }
  // a shadow leans over the lens from behind before it's picked up
  float cover = span(t, kReach - 0.1f, kLift) * (1.0f - span(t, kLift + 0.05f, kLift + 0.5f));
  pp.exposure = 1.05f * (1.0f - 0.55f * cover);
  camPos = at;
  camDir = dir;
  camUp = up;
  fov = 84.0f;
  pp.fear = 0.35f;
}

void Game::dropDraw(Shader& S, vec3 cam) {
  (void)S; (void)cam;  // nobody in the shot: just the camera, and whoever picks it up from behind
}

// The title card while the camcorder lies on the floor: big white letters with a heavy black
// outline, drawn onto the tape so they bend and smear with the picture.
void Game::dropHUD() {
  if (!dropping_) return;
  float t = dropT_;
  float a = std::clamp((t - 0.9f) / 0.35f, 0.0f, 1.0f) * std::clamp((4.9f - t) / 0.6f, 0.0f, 1.0f);
  float s = ui(), W = (float)R_->winW, H = (float)R_->winH;
  if (a > 0.0f) {
    bool first = levelIndex_ == 0 || (endless_ && depth_ == 1);
    std::string title = first ? "BELOW ROUTE 9" : level_.theme.name;
    // VCR OSD Mono, white, thin black outline and a soft shadow, a bit above centre (like the photo)
    float px = std::min(W * 0.068f, W * 0.72f / (0.6f * (float)title.size()));
    float tw = vcrWidth(title, px);
    vcrText(title, W * 0.5f - tw * 0.5f, H * 0.43f - px * 0.5f, px, 0.97f, 0.97f, 0.95f, a, px * 0.035f, px * 0.06f);
  }
  if (t > 1.2f && t < kLift) {
    std::string sk = usingPad_ ? "[A] PICK IT UP" : "[E] PICK IT UP";
    vt(sk, W * 0.5f - vw(sk, s) * 0.5f, H * 0.86f, s, 0.85f, 0.85f, 0.8f, 0.5f);
  }
}
