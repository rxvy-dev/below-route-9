#include "theme.h"
#include <algorithm>
#include <cstdio>

namespace {

// Keep note lines under 44 characters. See docs/LORE.md.
const std::vector<NoteText> kLobbyNotes = {
    {"TORN NOTEBOOK PAGE",
     "If you work nights at the Quik-Stop and\n"
     "you're reading this, you fell too.\n\n"
     "Don't panic. Panic is loud.\n\n"
     "The lights hum. When they stop humming,\n"
     "stop walking.\n\n"
     "                                   - T.K."},
    {"SURVEY MARKER S-0/114",
     "Camp 3. Left in a hurry. Sorry about that.\n\n"
     "Level 0 does not repeat. It only rhymes.\n"
     "Almond water (blue cap) is safe to drink.\n"
     "Every level has an edge. Walk it.\n"
     "The thin place is taped off in blue.\n"
     "When the green EXIT signs light up, run.\n\n"
     "Do not run unless it has already seen you."},
    {"MEMO - FACILITIES",
     "Tenants are reminded that the premises are\n"
     "occupied at all hours.\n\n"
     "Please keep noise to a minimum.\n\n"
     "Lighting faults will be addressed by the\n"
     "landlord personally.\n\n"
     "                              - MANAGEMENT"},
    {"TORN NOTEBOOK PAGE",
     "Day 9? The 'landlord' isn't a person.\n\n"
     "It's tall. It ducks under the ceiling.\n"
     "The lights go wrong around it, like it's\n"
     "drinking them.\n\n"
     "It found me by my footsteps. Walk slow.\n"
     "Crouch when the lights start to stutter."},
    {"SURVEY MARKER S-0/131",
     "Whoever finds this: the tall one was one\n"
     "of us. The first surveyor. Stayed too\n"
     "long mapping and now it maps us.\n\n"
     "Sometimes it just KNOWS where you are.\n"
     "When the alarm goes, don't hide. RUN.\n"
     "It gives up if you outlast it."},
    {"SURVEY MARKER S-0/140",
     "Something on all fours in the offices.\n"
     "No eyes. Doesn't need them.\n\n"
     "It clicks to hear the room. It hears\n"
     "running, breathing, everything.\n\n"
     "If it rushes you: STOP MOVING. Crouch.\n"
     "It only knows where you were."},
    {"TORN NOTEBOOK PAGE",
     "In the dark parts something smiles.\n"
     "Only teeth, and two lights for eyes.\n\n"
     "It sees the camera's infrared lamp.\nTurn NightShot off\n"
     "and it can't find you.\n\n"
     "Never look away from it. It only moves\n"
     "when nobody is watching."},
    {"TORN NOTEBOOK PAGE",
     "Somebody taped a door onto a wall out here,\n"
     "blue painter's tape, like a kid's drawing.\n"
     "The wall inside it hums. That's a thin place.\n\n"
     "Push through it and you fall somewhere\n"
     "else. I'm going down.\n\n"
     "If anyone from the store finds this,\n"
     "tell my mom I didn't quit.\n"
     "     - Theo Kerr, Quik-Stop #114, 10/24/96"},
};

const std::vector<NoteText> kHabitableNotes = {
    {"SURVEY MARKER S-1/002",
     "Level 1. Concrete, cold light, crates that\n"
     "nobody delivered. Safer than the Lobby.\n\n"
     "Mostly.\n\n"
     "Two of the crawlers live down here. They\n"
     "hunt in pairs. Walk, don't run."},
    {"SUPPLY MANIFEST (TORN)",
     "  ALMOND WATER ........ 40 CASES\n"
     "  BATTERIES (D) ....... 12 CASES\n"
     "  FLARES .............. 0\n"
     "  PERSONNEL ........... 0\n\n"
     "Received by: ________\n"
     "Received by: ________\n"
     "Received by: THEO KERR"},
    {"TORN NOTEBOOK PAGE",
     "The Survey wants me to stay and map.\n"
     "I told them I'm looking for the way home.\n\n"
     "Mercer laughed. She says there's no home,\n"
     "just further in.\n\n"
     "She's wrong. The walls stop somewhere."},
    {"SURVEY MARKER S-1/030",
     "Every watch down here stopped on the\n"
     "night its owner fell.\n\n"
     "Mine says OCT 24 1996. So does Mercer's.\n"
     "So does EVERYONE'S.\n\n"
     "We all fell on the same night.\n"
     "Some of us fell thirty years apart."},
    {"TORN NOTEBOOK PAGE",
     "A phone rang in the wall today. I picked\n"
     "it up. It was the store. It was ME, on\n"
     "my shift, asking who was breathing.\n\n"
     "Don't answer the phone.\n\n"
     "You're going to answer the phone."},
    {"SURVEY MARKER S-1/019",
     "Exit is always near the loudest static.\n\n"
     "Something always comes when you get close.\n"
     "Like it knows you're leaving.\n\n"
     "Save your stamina for the last stretch."},
};

const std::vector<NoteText> kPipeNotes = {
    {"SURVEY MARKER S-2/007",
     "Pipe Dreams. Hot, wet, loud.\n\n"
     "The pipes knock on their own. The steam\n"
     "covers your footsteps, a little.\n\n"
     "The tall one followed us down here.\n"
     "The corridors are narrow. Don't get boxed."},
    {"TORN NOTEBOOK PAGE",
     "Dana.\n\n"
     "I don't know how I know your name. We've\n"
     "never met. You weren't born when I fell.\n\n"
     "I wrote it on my hand so I'd remember,\n"
     "and every time I wake up there's more of\n"
     "you in these notes. Find Ray. Hurry."},
    {"TORN NOTEBOOK PAGE",
     "I can hear the hum from up there\n"
     "through the pipes. Like it's breathing.\n\n"
     "The store is right above us. It always\n"
     "was. The store IS the thin place.\n"
     "It just looks like a store."},
    {"MEMO - MAINTENANCE",
     "Pressure faults on lines 4 through 9 are\n"
     "NOT to be reported.\n\n"
     "Tenants are reminded that the boiler room\n"
     "is off limits.\n\n"
     "There is no boiler room.\n"
     "                              - MANAGEMENT"},
};

const std::vector<NoteText> kPoolNotes = {
    {"SURVEY LOG - UNIT 3",
     "Day 6 at Level 37. The water is warm and\n"
     "it's always noon through the skylights.\n\n"
     "Unit 4 says she's seen herself on the\n"
     "balconies in 188. Says she's older there.\n\n"
     "I'm going to lie down in the water for a\n"
     "minute. It's so quiet. Just a minute."},
    {"WATERLOGGED PAGE",
     "It's quiet here. It's so quiet.\n\n"
     "The water is warm. The light is warm.\n"
     "I could sleep here.\n\n"
     "Don't sleep here.\n\n"
     "                                   - T.K."},
    {"SURVEY MARKER S-?/???",
     "The Poolrooms. Nobody numbers them.\n\n"
     "Something walks the edges of the pools.\n"
     "Pale. Wet. It hears the splashing.\n\n"
     "Stay out of the water when it's close.\n"
     "Every step in the pool rings like a bell."},
    {"LAMINATED SIGN",
     "     POOL RULES\n\n"
     "  1. NO RUNNING\n"
     "  2. NO DIVING\n"
     "  3. NO LIFEGUARD ON DUTY\n"
     "  4. NO LIFEGUARD ON DUTY\n"
     "  5. THE LIFEGUARD IS ALWAYS ON DUTY"},
    {"WET NOTEBOOK PAGE",
     "I saw myself across the water tonight.\n\n"
     "She was wearing my work vest. My name\n"
     "tag. She waved.\n\n"
     "I didn't.\n\n"
     "The ones that go back up aren't always\n"
     "the ones that fell.            - T.K."},
};

const std::vector<NoteText> kDarkNotes = {
    {"SURVEY MARKER S-6/001",
     "Lights Out. Every fixture dead.\n\n"
     "The EXIT signs still glow down here.\n"
     "Follow the green. Save your batteries.\n\n"
     "The smiling ones live here. Lots of them.\n"
     "Lights off when you see teeth."},
    {"TORN NOTEBOOK PAGE",
     "I've stopped counting levels.\n\n"
     "Each one is further from home and I keep\n"
     "finding your name in the notes, Dana.\n"
     "Notes I didn't write.\n\n"
     "Keep the camera running. It remembers."},

    {"MEMO - MANAGEMENT",
     "The inspector is behind schedule.\n\n"
     "Please extend every courtesy.\n\n"
     "Please keep the lights off.\n\n"
     "                              - MANAGEMENT"},
};

const std::vector<NoteText> kCourtyardNotes = {
    {"HOTEL STATIONERY",
     "Every window has a light on in it\n"
     "sometimes. Never the same one twice.\n\n"
     "I counted 188 rooms. I've never found a\n"
     "door that opens into one.\n\n"
     "Someone in the third row waves at night."},
    {"SURVEY MARKER S-188/004",
     "The courtyard is real grass. It's wet.\n"
     "Nobody has ever reached it.\n\n"
     "The railing holds. Don't test it.\n"
     "The way out is through the corridors,\n"
     "not down."},
    {"TORN NOTEBOOK PAGE",
     "There's a window on the fourth floor\n"
     "with the Quik-Stop sign in it.\n\n"
     "I can see the counter. Someone behind\n"
     "it, ringing a customer up.\n\n"
     "It's still 1996 in that window.  - T.K."},
};

const std::vector<NoteText> kRunNotes = {
    {"SURVEY MARKER S-!/001",
     "Don't read this.\n\n"
     "RUN."},
    {"THE CLERK'S LAST PAGE",
     "I found the way up. I didn't take it.\n\n"
     "The store only stays open while someone\n"
     "is working the night shift down here.\n"
     "Somebody always has to be on the clock.\n\n"
     "I covered for thirty years, Dana.\n"
     "Tonight it's your shift.\n\n"
     "Clock out if you can.         - Theo"},
};

const std::vector<NoteText> kEndlessNotes = {
    {"SURVEY MARKER S-?/???",
     "We stopped numbering after Lights Out.\n\n"
     "The levels start over but they're wrong.\n"
     "Same shapes, wrong details.\n\n"
     "The EXIT signs still work. Trust the green."},
    {"TORN NOTEBOOK PAGE",
     "Further in. Always further in.\n\n"
     "I can hear the camera's motor in the\n"
     "walls now. Whirr. Click. Whirr.\n\n"
     "You're close. I can feel it.\n"
     "                                  - Theo"},
};

const std::vector<const char*> kCommonGraffiti = {"DON'T RUN", "LISTEN", "IT HEARS YOU", "KEEP GOING", "WE WERE HERE", "S-0", "IIII IIII II", "WHO TURNED OFF THE LIGHTS", "THEO WAS HERE", "NO EXIT", "DANA", "CLOCK OUT", "IT'S STILL 1996"};

Theme lobby() {
  Theme t;
  t.gradeGain = {1.05f, 1.0f, 0.84f}; t.gradeLift = {0.012f, 0.012f, 0.0f};
  t.title = "THE LOBBY";
  t.grime = 0.18f;  // clean: pale wallpaper, even carpet, the odd damp patch
  t.wall2 = Surf::DarkWallpaper; t.floor2 = Surf::DarkCarpet; t.ceiling2 = Surf::CeilingTiles;  // the old wing
  t.stilts = 1;
  t.notes = kLobbyNotes;
  t.graffiti = kCommonGraffiti;
  return t;
}

Theme habitable() {
  Theme t;
  t.gradeGain = {0.92f, 0.98f, 1.08f}; t.gradeLift = {0.0f, 0.006f, 0.016f};
  t.title = "HABITABLE ZONE";
  t.layout = Layout::Warehouse;
  t.wallH = 4.2f;
  t.braid = 0.75f;
  t.rooms = 22; t.hallways = 6;
  t.pillarChance = 0.9f;
  t.wall = Surf::Concrete; t.floor = Surf::ConcreteFloor; t.ceiling = Surf::CeilingConcrete;
  t.lightColor = {0.86f, 0.93f, 1.0f};
  t.lightIntensity = 1.35f;
  t.lightSpacing = 3;
  t.panelW = 0.25f; t.panelL = 1.5f;
  t.deadChance = 0.12f; t.flickerChance = 0.1f;
  t.darkZones = 3;
  t.fogColor = {0.010f, 0.012f, 0.015f};
  t.fogLit = {0.03f, 0.036f, 0.04f};
  t.fogDensity = 0.055f;  // the far end of every hall drowns in dark
  t.paint = {0.42f, 0.03f, 0.025f};
  t.tenants = 0; t.hounds = 2; t.grins = 1;
  t.firstSpawn = 30.0f;
  t.huntEvery = 110.0f;
  t.batteries = 8; t.waters = 7;
  t.chairs = 6; t.boxes = 60; t.coolers = 3;
  t.notes = kHabitableNotes;
  t.graffiti = {"WALK DONT RUN", "2 OF THEM", "CAMP 4 GONE", "LISTEN", "KEEP GOING", "IT CLICKS"};
  return t;
}

const std::vector<NoteText> kOfficeNotes = {
    {"EMPLOYEE HANDBOOK, P.4",
     "Every associate is a promise.\n\n"
     "  BE RESPONSIVE.\n"
     "  BE RESPECTFUL.\n"
     "  DELIVER GREAT CUSTOMER EXPERIENCES.\n\n"
     "Someone has written underneath, small:\n"
     "they never let us clock out"},
    {"SURVEY MARKER S-33/002",
     "Offices. Nobody's here. Coffee still warm.\n\n"
     "The corridors behind the doors are longer\n"
     "than the floor plan. We measured. Twice.\n\n"
     "Don't walk the dark ones without a light."},
    {"STICKY NOTE",
     "If you can read this you're still on\n"
     "the clock.\n\n"
     "The way out has a green sign over it.\n"
     "The signs only turn on when you're close.\n\n"
     "                              - T.K."},
};

const std::vector<NoteText> kPlayNotes = {
    {"RULES OF THE PLAYGROUND",
     "1. NO SHOES IN THE BALL PIT\n"
     "2. NO DIVING\n"
     "3. ONE AT A TIME ON THE SLIDES\n"
     "4. IF YOU HEAR SINGING, HIDE\n"
     "5. GROWN-UPS MUST BE ACCOMPANIED\n\n"
     "Rule 4 is handwritten."},
    {"SURVEY MARKER S-62/001",
     "Ball pit. Waist deep in places. Loud.\n"
     "Everything here can hear you move.\n\n"
     "Something swam under the balls past\n"
     "Unit 2's legs. We didn't see what."},
    {"CRAYON DRAWING",
     "A house. A sun. Four stick people.\n"
     "One of them is yellow and has no face.\n\n"
     "On the back: COME PLAY"},
};

const std::vector<NoteText> kSuburbNotes = {
    {"SURVEY MARKER S-9/001",
     "Outside. Actual sky. Grass.\n\n"
     "Every house is the same house. Same\n"
     "curtains. Same crack in the third step.\n\n"
     "Don't go in. They're not empty."},
    {"FOR SALE FLYER",
     "WELCOME HOME!\n"
     "3 BED, 2 BATH, FINISHED BASEMENT.\n"
     "QUIET NEIGHBOURS.\n\n"
     "Someone has circled 'basement' and\n"
     "written: the basement goes down"},
    {"TORN NOTEBOOK PAGE",
     "The hills go on and then they don't.\n"
     "Walk to the edge and you'll know.\n\n"
     "The house with the open door is the\n"
     "one. Blue tape on the frame.\n\n"
     "                              - T.K."},
};

// Level 1 is a parking garage now: rows of lettered concrete piers, a low ceiling full of
// sprinkler pipes, bare tubes, standing water that mirrors every light. Cars nobody came back for.
Theme parking() {
  Theme t;
  t.gradeGain = {0.94f, 0.98f, 1.04f}; t.gradeLift = {0.004f, 0.006f, 0.01f};
  t.title = "UNDERGROUND PARKING";
  t.special = Special::Parking;
  t.layout = Layout::Warehouse;
  t.wallH = 2.75f;
  t.braid = 0.94f;
  t.rooms = 30; t.hallways = 4;
  t.pillarChance = 1.0f;
  t.wall = Surf::Corrugated; t.floor = Surf::ParkingFloor; t.ceiling = Surf::CeilingConcrete;
  t.wall2 = Surf::Concrete;  // the piers
  t.lightColor = {0.9f, 0.96f, 1.0f};
  t.lightIntensity = 1.25f;
  t.lightSpacing = 2;
  t.panelW = 0.12f; t.panelL = 1.25f;  // bare tubes
  t.deadChance = 0.16f; t.flickerChance = 0.12f;
  t.darkZones = 4;
  t.fogColor = {0.012f, 0.013f, 0.015f};
  t.fogLit = {0.035f, 0.04f, 0.045f};
  t.fogDensity = 0.045f;
  t.wetFloor = 0.9f;
  t.grime = 1.0f;
  t.paint = {0.42f, 0.03f, 0.025f};
  t.tenants = 0; t.hounds = 2; t.grins = 1;
  t.firstSpawn = 35.0f;
  t.huntEvery = 110.0f;
  t.batteries = 8; t.waters = 6;
  t.chairs = 0; t.boxes = 18; t.coolers = 2;
  t.lockers = 6;
  t.notes = kHabitableNotes;
  t.graffiti = {"LEVEL P2", "KEEP LEFT", "2 OF THEM", "CAMP 4 GONE", "LISTEN", "IT CLICKS"};
  return t;
}

// An office the company left. Beige walls, dark carpet, a mural about customer service, and
// doors onto corridors that go on much further than the building does.
Theme countOnMe() {
  Theme t;
  t.gradeGain = {1.0f, 0.99f, 0.96f}; t.gradeLift = {0.006f, 0.006f, 0.006f};
  t.title = "COUNT ON ME";
  t.label = "LEVEL 33";
  t.special = Special::Office;
  t.layout = Layout::Halls;
  t.wallH = 2.8f;
  t.braid = 0.35f;
  t.rooms = 20; t.hallways = 14;
  t.pillarChance = 0.0f;
  t.wall = Surf::OfficeWall; t.floor = Surf::OfficeCarpet; t.ceiling = Surf::CeilingTiles;
  t.wall2 = Surf::Wallpaper; t.floor2 = Surf::Carpet; t.ceiling2 = Surf::CeilingTiles;  // where the Lobby is coming through
  t.lightColor = {0.95f, 0.96f, 1.0f};
  t.lightIntensity = 1.1f;
  t.lightSpacing = 2;
  t.panelW = 0.6f; t.panelL = 1.2f;
  t.deadChance = 0.3f; t.flickerChance = 0.1f;
  t.darkZones = 5;
  t.fogColor = {0.01f, 0.01f, 0.012f};
  t.fogLit = {0.04f, 0.04f, 0.045f};
  t.fogDensity = 0.06f;
  t.grime = 0.35f;
  t.tenants = 1; t.hounds = 0; t.grins = 1; t.stilts = 1;
  t.firstSpawn = 50.0f;
  t.huntEvery = 130.0f;
  t.batteries = 9; t.waters = 5;
  t.chairs = 16; t.boxes = 14; t.coolers = 2;
  t.lockers = 8;
  t.notes = kOfficeNotes;
  t.graffiti = {"COUNT ON ME", "BE RESPONSIVE", "THEY NEVER CLOSED", "WHO IS ON SHIFT"};
  return t;
}

// The Playplace: a dark hall filled with a sea of plastic balls, giant hourglass pillars and
// spiral slides that start in the ceiling.
Theme playplace() {
  Theme t;
  t.gradeGain = {0.96f, 0.98f, 1.06f}; t.gradeLift = {0.004f, 0.006f, 0.012f};
  t.title = "THE PLAYPLACE";
  t.label = "LEVEL 62";
  t.special = Special::Playplace;
  t.layout = Layout::Warehouse;
  t.wallH = 3.0f;
  t.braid = 1.0f;
  t.rooms = 34; t.hallways = 2;
  t.pillarChance = 0.0f;
  t.wall = Surf::PlayWall; t.floor = Surf::BallPit; t.ceiling = Surf::PlayCeiling;
  t.lightColor = {0.86f, 0.9f, 1.0f};
  t.lightIntensity = 1.15f;
  t.lightSpacing = 3;
  t.panelW = 0.4f; t.panelL = 0.4f;
  t.deadChance = 0.25f; t.flickerChance = 0.1f;
  t.darkZones = 6;
  t.fogColor = {0.006f, 0.007f, 0.01f};
  t.fogLit = {0.02f, 0.022f, 0.03f};
  t.fogDensity = 0.065f;
  t.grime = 0.2f;
  t.tenants = 0; t.hounds = 0; t.grins = 2; t.partygoers = 2;
  t.firstSpawn = 45.0f;
  t.huntEvery = 120.0f;
  t.batteries = 9; t.waters = 4;
  t.chairs = 0; t.boxes = 0; t.coolers = 0;
  t.lockers = 4;
  t.camp = false;
  t.notes = kPlayNotes;
  t.graffiti = {"NO SHOES", "WHERE ARE THE KIDS", "DON'T DIVE", "COME PLAY"};
  return t;
}

// Level 9: rolling green hills to the horizon, the same house over and over, a sky that's a
// little too blue. One of the houses has its door open.
Theme suburbs() {
  Theme t;
  t.gradeGain = {1.0f, 1.0f, 1.0f}; t.gradeLift = {0.01f, 0.012f, 0.016f};
  t.title = "THE SUBURBS";
  t.label = "LEVEL 9";
  t.special = Special::Suburbs;
  t.layout = Layout::Warehouse;
  t.wallH = 3.0f;
  t.braid = 1.0f;
  t.rooms = 40; t.hallways = 0;
  t.pillarChance = 0.0f;
  t.outdoor = true;
  t.openEdge = true;
  t.terrain = 3.2f;
  t.floor = Surf::Grass; t.wall = Surf::Plaster; t.ceiling = Surf::PlayCeiling;
  t.lightIntensity = 0.0f;
  t.deadChance = 1.0f; t.flickerChance = 0;
  t.darkZones = 0;
  t.sun = 3.2f;
  t.sunDir = {-0.55f, 0.75f, -0.35f};
  t.sunColor = {1.0f, 0.95f, 0.85f};
  t.ambient = {0.28f, 0.34f, 0.42f};
  t.fogColor = {0.5f, 0.64f, 0.86f};
  t.fogLit = {0, 0, 0};
  t.fogDensity = 0.0065f;
  t.grime = 0.0f;
  t.tenants = 0; t.hounds = 1; t.grins = 0; t.stilts = 1;
  t.firstSpawn = 60.0f;
  t.huntEvery = 140.0f;
  t.batteries = 4; t.waters = 6;
  t.chairs = 0; t.boxes = 0; t.coolers = 0;
  t.lockers = 0; t.anomalies = 0;
  t.camp = false;
  t.humGain = 0.0f;
  t.notes = kSuburbNotes;
  t.graffiti = {"WELCOME HOME"};
  return t;
}

Theme pipes() {
  Theme t;
  t.gradeGain = {1.08f, 0.94f, 0.82f}; t.gradeLift = {0.016f, 0.006f, 0.0f};
  t.title = "PIPE DREAMS";
  t.layout = Layout::Tunnels;
  t.wallH = 2.5f;
  t.braid = 0.22f;
  t.rooms = 6; t.hallways = 14;
  t.pillarChance = 0.0f;
  t.wall = Surf::Brick; t.floor = Surf::ConcreteFloor; t.ceiling = Surf::CeilingConcrete;
  t.wall2 = Surf::Concrete; t.floor2 = Surf::ConcreteFloor; t.ceiling2 = Surf::CeilingConcrete;
  t.lightColor = {1.0f, 0.55f, 0.25f};
  t.lightIntensity = 1.05f;
  t.lightSpacing = 2;
  t.panelW = 0.22f; t.panelL = 0.22f;
  t.deadChance = 0.22f; t.flickerChance = 0.3f;
  t.darkZones = 4;
  t.fogColor = {0.014f, 0.008f, 0.004f};
  t.fogLit = {0.06f, 0.03f, 0.012f};
  t.fogDensity = 0.07f;
  t.paint = {0.85f, 0.85f, 0.8f};
  t.pipes = true;
  t.tenants = 1; t.hounds = 1; t.grins = 1;
  t.firstSpawn = 25.0f;
  t.huntEvery = 95.0f;
  t.batteries = 9; t.waters = 4;
  t.chairs = 0; t.boxes = 10; t.coolers = 0;
  t.camp = false;
  t.humGain = 1.4f;
  t.notes = kPipeNotes;
  t.graffiti = {"HOT", "DON'T TOUCH", "KEEP MOVING", "IT FOLLOWED US", "LINE 6", "NOT SAFE"};
  return t;
}

Theme pools() {
  Theme t;
  t.gradeGain = {1.05f, 1.0f, 0.9f}; t.gradeLift = {0.012f, 0.01f, 0.004f};
  t.title = "THE POOLROOMS";
  t.label = "LEVEL 37";
  t.layout = Layout::Pools;
  t.wallH = 3.8f;
  t.braid = 0.82f;
  t.rooms = 20; t.hallways = 5;
  t.pillarChance = 0.6f;
  t.roundPillars = true;
  t.wall = Surf::PoolTile; t.floor = Surf::PoolTile; t.ceiling = Surf::PoolTile;
  t.wall2 = Surf::PoolTile; t.floor2 = Surf::PoolMosaic; t.ceiling2 = Surf::PoolTile;
  t.lightColor = {1.0f, 0.93f, 0.8f};
  t.lightIntensity = 0.5f;
  t.lightSpacing = 3;
  t.panelW = 1.6f; t.panelL = 0.35f;
  t.deadChance = 0.15f; t.flickerChance = 0.02f;
  t.darkZones = 0;
  t.sun = 6.5f;
  t.sunDir = {-0.95f, 1.0f, -0.42f};
  t.sunColor = {1.0f, 0.84f, 0.6f};
  t.fogColor = {0.07f, 0.065f, 0.055f};
  t.fogLit = {0.12f, 0.11f, 0.09f};
  t.fogDensity = 0.028f;
  t.paint = {0.72f, 0.05f, 0.035f};  // Survey red: grey arrows vanished against cream tile and wet glare
  t.paintGlow = 0.35f;
  t.pools = true;
  t.grime = 0.25f;
  t.tenants = 1; t.hounds = 0; t.grins = 0;
  t.lifeguard = true;
  t.firstSpawn = 35.0f;
  t.huntEvery = 130.0f;
  t.batteries = 4; t.waters = 4;
  t.chairs = 0; t.boxes = 0; t.coolers = 0;
  t.camp = false;
  t.humGain = 0.3f; t.waterGain = 1.0f;
  t.notes = kPoolNotes;
  t.graffiti = {"NO RUNNING", "STAY DRY", "IT HEARS SPLASHING", "SO QUIET", "DONT SLEEP"};
  return t;
}

Theme lightsOut() {
  Theme t;
  t.gradeGain = {0.86f, 0.94f, 1.1f}; t.gradeLift = {0.0f, 0.004f, 0.018f};
  t.title = "LIGHTS OUT";
  t.label = "LEVEL 6";
  t.layout = Layout::Halls;
  t.braid = 0.5f;
  t.wall = Surf::DarkWallpaper; t.floor = Surf::DarkCarpet; t.ceiling = Surf::CeilingTiles;
  t.wall2 = Surf::Concrete; t.floor2 = Surf::ConcreteFloor; t.ceiling2 = Surf::CeilingConcrete;
  t.deadChance = 0.9f; t.flickerChance = 0.06f;
  t.darkZones = 0;
  t.lightIntensity = 0.8f;
  t.fogColor = {0.004f, 0.004f, 0.004f};
  t.fogLit = {0.03f, 0.025f, 0.015f};
  t.fogDensity = 0.06f;
  t.paint = {0.25f, 0.85f, 0.35f};
  t.paintGlow = 1.6f;
  t.tenants = 1; t.hounds = 0; t.grins = 4;
  t.firstSpawn = 45.0f;
  t.huntEvery = 140.0f;
  t.batteries = 14; t.waters = 4;
  t.chairs = 18; t.boxes = 12; t.coolers = 2;
  t.camp = false;
  t.humGain = 0.2f;
  t.notes = kDarkNotes;
  t.graffiti = {"LIGHTS OFF", "LOOK AT IT", "TEETH", "FOLLOW THE GREEN", "SAVE BATTERY"};
  return t;
}

Theme courtyard() {
  Theme t;
  t.gradeGain = {1.0f, 0.97f, 1.05f}; t.gradeLift = {0.01f, 0.006f, 0.016f};
  t.title = "THE COURTYARD OF WINDOWS";
  t.label = "LEVEL 188";
  t.layout = Layout::Halls;
  t.courtyard = 10;
  t.wallH = 2.9f;
  t.braid = 0.55f;
  t.wall = Surf::Plaster; t.floor = Surf::HotelCarpet; t.ceiling = Surf::Plaster;
  t.wall2 = Surf::Wallpaper; t.floor2 = Surf::DarkCarpet; t.ceiling2 = Surf::Plaster;
  t.lightColor = {0.96f, 0.93f, 1.0f};
  t.lightIntensity = 0.95f;
  t.panelW = 0.45f; t.panelL = 0.45f;
  t.deadChance = 0.04f; t.flickerChance = 0.05f;
  t.darkZones = 2;
  t.fogColor = {0.02f, 0.018f, 0.024f};
  t.fogLit = {0.07f, 0.064f, 0.08f};
  t.fogDensity = 0.022f;
  t.paint = {0.45f, 0.04f, 0.04f};
  t.grime = 0.3f;
  t.tenants = 1; t.hounds = 0; t.grins = 1;
  t.firstSpawn = 50.0f;
  t.huntEvery = 150.0f;
  t.batteries = 6; t.waters = 4;
  t.chairs = 10; t.boxes = 4; t.coolers = 0;
  t.camp = false;
  t.lockers = 8; t.anomalies = 8;
  t.humGain = 0.25f;
  t.notes = kCourtyardNotes;
  t.graffiti = {"WHO IS IN THE WINDOWS", "DONT LOOK UP", "ROOM 188", "NO DOORS", "SOMEONE WAVED"};
  return t;
}

const std::vector<NoteText> kPartyNotes = {
    {"BIRTHDAY CARD",
     "HAPPY BIRTHDAY!!!\n\n"
     "We're SO glad you could make it.\n"
     "Everyone's been waiting for you.\n\n"
     "Don't leave early. Nobody leaves early.\n\n"
     "                 =)"},
    {"SURVEY MARKER S-FUN",
     "Do not go to the party.\n\n"
     "When the music starts, get under a table\n"
     "and stay under it until the singing stops.\n"
     "They're slow. They don't look under things.\n\n"
     "Unit 2 went to the party. Unit 2 is still\n"
     "at the party."},
    {"TORN NOTEBOOK PAGE",
     "There's a cake on every table and the\n"
     "candles are always lit and they never\n"
     "burn down.\n\n"
     "One of them waved at me. It was wearing\n"
     "a name tag. HELLO MY NAME IS THEO.\n\n"
     "                                   - T.K."},
};

Theme party() {
  Theme t;
  t.gradeGain = {1.08f, 0.98f, 0.9f}; t.gradeLift = {0.014f, 0.006f, 0.0f};
  t.title = "THE PARTY";
  t.label = "LEVEL FUN =)";
  t.layout = Layout::Office;
  t.party = true;
  t.wallH = 3.0f;
  t.braid = 0.7f;
  t.rooms = 26; t.hallways = 8;
  t.pillarChance = 0.0f;
  t.wall = Surf::PartyWall; t.floor = Surf::PartyCarpet; t.ceiling = Surf::PartyCeiling;
  t.wall2 = Surf::PartyWall2; t.floor2 = Surf::PartyCarpet; t.ceiling2 = Surf::PartyCeiling;
  t.lightColor = {1.0f, 0.86f, 0.7f};
  t.lightIntensity = 1.05f;
  t.lightSpacing = 3;
  t.panelW = 0.6f; t.panelL = 0.6f;
  t.deadChance = 0.06f; t.flickerChance = 0.04f;
  t.darkZones = 1;
  t.fogColor = {0.06f, 0.025f, 0.012f};
  t.fogLit = {0.14f, 0.06f, 0.03f};
  t.fogDensity = 0.03f;
  t.paint = {0.95f, 0.85f, 0.2f};
  t.grime = 0.15f;
  t.tenants = 0; t.hounds = 0; t.grins = 0;
  t.partygoers = 3;
  t.firstSpawn = 20.0f;
  t.huntEvery = 0.0f;
  t.batteries = 3; t.waters = 4;
  t.chairs = 6; t.boxes = 0; t.coolers = 0;
  t.camp = false;
  t.lockers = 0; t.anomalies = 3;
  t.humGain = 0.35f;
  t.notes = kPartyNotes;
  t.graffiti = {"HAPPY BIRTHDAY", "=)", "JOIN THE PARTY", "YOU'RE INVITED", "PARTY TIME!", "DON'T LEAVE EARLY", "HIDE", "WELCOME BACK DANA"};
  return t;
}

Theme runForYourLife() {
  Theme t;
  t.gradeGain = {1.08f, 0.9f, 0.88f}; t.gradeLift = {0.02f, 0.0f, 0.0f};
  t.title = "RUN FOR YOUR LIFE";
  t.label = "LEVEL !";
  t.layout = Layout::Halls;
  t.braid = 0.35f;
  t.hallways = 18;
  t.wall = Surf::Concrete; t.floor = Surf::ConcreteFloor; t.ceiling = Surf::CeilingConcrete;
  t.wall2 = Surf::Tile; t.floor2 = Surf::Vinyl; t.ceiling2 = Surf::CeilingTiles;
  t.lightColor = {1.0f, 0.14f, 0.09f};
  t.lightIntensity = 1.15f;
  t.panelW = 0.3f; t.panelL = 0.9f;
  t.deadChance = 0.05f; t.flickerChance = 0.35f;
  t.darkZones = 0;
  t.fogColor = {0.03f, 0.004f, 0.003f};
  t.fogLit = {0.12f, 0.015f, 0.01f};
  t.fogDensity = 0.045f;
  t.paint = {0.92f, 0.92f, 0.88f};
  t.paintGlow = 0.9f;
  t.tenants = 2; t.hounds = 2; t.grins = 0;
  t.firstSpawn = 6.0f;
  t.huntEvery = 24.0f;
  t.batteries = 4; t.waters = 8;
  t.chairs = 6; t.boxes = 10; t.coolers = 0;
  t.camp = false;
  t.lockers = 6; t.anomalies = 4;
  t.humGain = 0.6f;
  t.notes = kRunNotes;
  t.graffiti = {"RUN", "DONT STOP", "RUN FOR YOUR LIFE", "ITS BEHIND YOU", "FASTER"};
  return t;
}

}  // namespace

Theme themeFor(int level, uint32_t seed) {
  Theme t;
  switch (level) {
    case 0: t = lobby(); break;
    case 1: t = parking(); break;
    case 8: t = playplace(); break;
    case 9: t = countOnMe(); break;
    case 10: t = suburbs(); break;
    case 2: t = pipes(); break;
    case 3: t = pools(); break;
    case 4: t = lightsOut(); break;
    case 5: t = courtyard(); break;
    case 6: t = party(); break;
    case 7: t = runForYourLife(); break;
    case kParkLevel: {  // a Saturday afternoon at the trampoline park, before everything
      t.title = "SKY HIGH TRAMPOLINE PARK";
      t.label = "SATURDAY";
      t.special = Special::Park;
      t.layout = Layout::Warehouse;
      t.wallH = 6.0f;
      t.wall = Surf::PlayWall; t.floor = Surf::OfficeCarpet; t.ceiling = Surf::PlayCeiling;
      t.wall2 = Surf::PartyWall2; t.floor2 = Surf::OfficeCarpet; t.ceiling2 = Surf::PlayCeiling;
      t.lightColor = {1.0f, 0.97f, 0.92f};
      t.lightIntensity = 1.15f;
      t.lightSpacing = 2;
      t.panelW = 0.6f; t.panelL = 1.2f;
      t.deadChance = 0; t.flickerChance = 0; t.darkZones = 0;
      t.fogColor = {0.03f, 0.03f, 0.035f};
      t.fogLit = {0.07f, 0.07f, 0.075f};
      t.fogDensity = 0.012f;
      t.grime = 0.1f;
      t.tenants = 0; t.hounds = 0; t.grins = 0; t.stilts = 0; t.partygoers = 0;
      t.lockers = 0; t.anomalies = 0; t.chairs = 0; t.boxes = 0; t.coolers = 0; t.camp = false;
      t.batteries = 0; t.waters = 0;
      t.firstSpawn = 1e9f; t.huntEvery = 0;
      t.humGain = 0.25f;
      t.paint = {0.95f, 0.95f, 0.92f};
      t.notes.clear();
      t.graffiti = {"SKY HIGH", "JUMP ZONE", "SOCKS ONLY", "ONE JUMPER PER BED", "NO FLIPS", "BIRTHDAY PARTIES!"};
      break;
    }
    case kStoreLevel: {
      t.title = "QUIK-STOP, ROUTE 9";
      t.gradeGain = {0.97f, 1.0f, 1.03f}; t.gradeLift = {0.004f, 0.006f, 0.01f};
      t.layout = Layout::Store;
      t.wallH = 3.2f;
      t.wall = Surf::Painted; t.floor = Surf::Vinyl; t.ceiling = Surf::CeilingTiles;
      t.lightColor = {0.92f, 0.97f, 1.0f};
      t.lightIntensity = 1.25f;
      t.panelW = 0.6f; t.panelL = 1.2f;
      t.deadChance = 0; t.flickerChance = 0; t.darkZones = 0;
      t.fogColor = {0.02f, 0.022f, 0.025f};
      t.fogLit = {0.05f, 0.055f, 0.06f};
      t.fogDensity = 0.015f;
      t.paint = {0.06f, 0.06f, 0.07f};
      t.grime = 0.3f;
      t.tenants = t.hounds = t.grins = 0;
      t.huntEvery = 0;
      t.batteries = t.waters = 0;
      t.chairs = t.boxes = t.coolers = 0;
      t.camp = false;
      t.lockers = 0; t.anomalies = 0;
      t.humGain = 0.5f;
      t.notes.clear();
      t.graffiti = {"EMPLOYEES ONLY", "BASEMENT", "AISLE 1", "AISLE 2", "FROZEN FOODS", "QUIK-STOP", "MISSING: THEO KERR", "LAST SEEN 10/24/96"};
      break;
    }
    case kChoiceLevel: {
      t = lobby();
      t.title = "YOU CAN ONLY PICK ONE";
      t.label = "LEVEL ?";
      t.layout = Layout::Choice;
      t.deadChance = 0; t.flickerChance = 0.25f; t.darkZones = 0;
      t.tenants = t.hounds = t.grins = 0;
      t.huntEvery = 0;
      t.batteries = t.waters = 0;
      t.chairs = t.boxes = t.coolers = 0;
      t.lockers = 0; t.anomalies = 3;
      t.camp = false;
      t.notes.clear();
      t.graffiti = {"THIS WAY", "?", "EXIT :)"};
      break;
    }
    case kAptLevel: case kAptWrongLevel: {
      bool wrong = level == kAptWrongLevel;
      t.title = "HOME";
      if (!wrong) { t.gradeGain = {1.06f, 0.98f, 0.9f}; t.gradeLift = {0.01f, 0.005f, 0.0f}; } else { t.gradeGain = {1.05f, 1.0f, 0.8f}; t.gradeLift = {0.015f, 0.012f, 0.0f}; }
      t.layout = Layout::Apartment;
      t.wallH = 2.6f;
      t.wall = wrong ? Surf::Wallpaper : Surf::Plaster;
      t.floor = wrong ? Surf::Carpet : Surf::Wood;
      t.ceiling = wrong ? Surf::CeilingTiles : Surf::Plaster;
      t.wall2 = Surf::Tile; t.floor2 = Surf::Vinyl; t.ceiling2 = t.ceiling;
      t.lightColor = wrong ? vec3{1.0f, 0.97f, 0.82f} : vec3{1.0f, 0.78f, 0.55f};
      t.lightIntensity = wrong ? 1.15f : 0.75f;
      t.panelW = wrong ? 0.6f : 0.35f; t.panelL = wrong ? 1.2f : 0.35f;
      t.deadChance = 0; t.flickerChance = wrong ? 0.4f : 0.0f; t.darkZones = 0;
      t.fogColor = {0.015f, 0.014f, 0.016f};
      t.fogLit = {0.04f, 0.035f, 0.03f};
      t.fogDensity = 0.01f;
      t.paint = {0.06f, 0.06f, 0.07f};
      t.grime = wrong ? 0.55f : 0.12f;
      t.tenants = t.hounds = t.grins = 0;
      t.huntEvery = 0;
      t.batteries = t.waters = 0;
      t.chairs = t.boxes = t.coolers = 0;
      t.camp = false;
      t.lockers = 0; t.anomalies = 0;
      t.humGain = wrong ? 0.8f : 0.0f;
      t.notes.clear();
      t.graffiti.clear();
      break;
    }
    default: t = lightsOut(); break;
  }
  t.index = level;
  char buf[32];
  std::snprintf(buf, sizeof buf, "LEVEL %d", level);
  t.name = !t.label.empty() ? t.label : (level == kStoreLevel ? std::string("NIGHT SHIFT") : (level < 0 ? std::string("HOME") : std::string(buf)));
  return t;
}
