#include "gl.h"
#include <SDL.h>
#include <cstring>

#define X(ret, name, args) PFN_##name name = nullptr;
NOCLIP_GL_FUNCS
#undef X

namespace gl {

bool load(const char** missing) {
#define X(ret, name, args)                                              \
  name = reinterpret_cast<PFN_##name>(SDL_GL_GetProcAddress(#name));    \
  if (!name) { if (missing) *missing = #name; return false; }
  NOCLIP_GL_FUNCS
#undef X
  return true;
}

bool hasExtension(const char* ext) {
  GLint n = 0;
  glGetIntegerv(GL_NUM_EXTENSIONS, &n);
  for (GLint i = 0; i < n; ++i) {
    const char* e = reinterpret_cast<const char*>(glGetStringi(GL_EXTENSIONS, (GLuint)i));
    if (e && std::strcmp(e, ext) == 0) return true;
  }
  return false;
}

}  // namespace gl
