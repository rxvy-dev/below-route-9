// Level Fun =) and the Stilt.
// The Partygoers are slow and they don't look under tables. Every so often it's somebody's
// birthday: the lights go strange, the song starts, and a whole party comes looking for the
// guest of honour. Get under a table and stay there until the singing stops.
#include <cmath>

#include "audio.h"
#include "game.h"
#include "texgen.h"

StalkerParams stiltParams() {
  StalkerParams p;
  p.wanderSpeed = 0.8f;      // it mostly stands still and then moves a long way at once
  p.investigateSpeed = 2.6f;
  p.searchSpeed = 1.4f;
  p.chaseBase = 4.0f;
  p.chaseMax = 5.0f;
  p.chaseAccel = 0.35f;
  p.sight = 1.25f;
  p.hearing = 0.8f;
  p.catchDist = 1.05f;
  p.stride = 2.3f;
  return p;
}

StalkerParams partyParams() {
  StalkerParams p;
  p.wanderSpeed = 0.55f;
  p.investigateSpeed = 1.0f;
  p.searchSpeed = 0.8f;
  p.chaseBase = 1.45f;  // slow. You can always walk away. You can't always find a way out.
  p.chaseMax = 1.9f;
  p.chaseAccel = 0.05f;
  p.sight = 1.0f;
  p.hearing = 0.7f;
  p.catchDist = 1.0f;
  p.giveUp = 9.0f;
  p.stride = 0.9f;
  return p;
}

void Game::partyReset() {
  partyT_ = rng_.range(45.0f, 70.0f);
  partySong_ = 0;
  partyTalk_ = 6.0f;
}

void Game::partyUpdate(float dt) {
  if (!level_.theme.party || screen_ != Screen::Playing) return;
  // the guests, chattering when they get close
  partyTalk_ -= dt;
  for (Stalker& s : stalkers_) {
    if (s.kind != CR_PARTYGOER || !s.active()) continue;
    vec3 d = level_.delta(pos_, s.pos);
    float dist = std::sqrt(d.x * d.x + d.z * d.z);
    if (dist < 9.0f && partyTalk_ <= 0) {
      partyTalk_ = rng_.range(5.0f, 9.0f);
      bool hiding = hiding_ >= 0;
      static const char* kNear[] = {"Hello friend! =)", "It's your birthday!", "Come to the party!", "We made a cake for you.",
                                    "Don't you want to play?", "Everyone's waiting!"};
      static const char* kHide[] = {"Where did you go? =)", "Are you playing hide and seek?", "We can wait.", "It's rude to leave a party.",
                                    "Come out, come out!"};
      say("???", hiding ? kHide[rng_.next() % 5] : kNear[rng_.next() % 6], 2.4f);
      if (A_) A_->play(Sfx::Giggle, 0.5f, 0, 1.3f);
    }
  }
  // birthdays
  partyT_ -= dt;
  if (partySong_ <= 0 && partyT_ <= 0) {
    partySong_ = 24.0f;
    partyT_ = rng_.range(60.0f, 85.0f);
    toast_ = "IT'S SOMEBODY'S BIRTHDAY";
    toastTime_ = 3.5f;
    if (A_) { A_->play(Sfx::Birthday, 0.85f); A_->play(Sfx::Brownout, 0.4f); }
    // a whole party, from somewhere close enough to hear them coming
    for (int k = 0; k < 4; ++k) {
      Stalker s;
      s.kind = CR_PARTYGOER;
      s.P = partyParams();
      s.placeFar(level_, pos_, rng_, 7, 13);
      s.startHunt(20.0f, 1.75f);
      s.variant = 9;  // a guest, not a resident: goes home when the song's over
      stalkers_.push_back(s);
      spawnAt_.push_back(0);
    }
  }
  if (partySong_ > 0) {
    partySong_ -= dt;
    if (A_ && std::fmod(partySong_, 8.0f) < dt && partySong_ > 4.0f) A_->play(Sfx::Birthday, 0.7f);
    if (partySong_ <= 0) {
      // the guests leave the way they came
      for (size_t i = 0; i < stalkers_.size();) {
        if (stalkers_[i].variant == 9) { stalkers_.erase(stalkers_.begin() + i); spawnAt_.erase(spawnAt_.begin() + i); }
        else ++i;
      }
      if (screen_ == Screen::Playing) unlockBadge(10);
      if (hiding_ >= 0) say("DANA", "(...It stopped. Is it over?)", 2.6f);
      else toast_ = "THE PARTY MOVED ON", toastTime_ = 2.5f;
    }
  }
}

void Game::partyDraw(Shader& S, vec3 cam) {
  if (level_.bunting.empty()) return;
  if (!texBunting_) texBunting_ = makeTexture(texgen::bunting(512, 128, level_.seed), true, false);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDisable(GL_CULL_FACE);
  S.set("uMat", MAT_SCREEN);
  S.set("uSkinned", 0);
  S.set("uUVScale", 1.0f);
  S.set("uEmissive", 0.35f);
  glBindTexture(GL_TEXTURE_2D, texBunting_);
  for (size_t i = 0; i < level_.bunting.size(); ++i) {
    vec3 c = near(level_.bunting[i], cam), n = level_.buntingN[i];
    if (std::fabs(c.x - cam.x) > 40 || std::fabs(c.z - cam.z) > 40) continue;
    vec3 r = cross(vec3{0, 1, 0}, n);
    mat4 m = mat4::identity();
    m.m[0] = r.x * 1.8f; m.m[2] = r.z * 1.8f;
    m.m[5] = 0.45f;
    m.m[8] = n.x; m.m[10] = n.z;
    m.m[12] = c.x + n.x * 0.02f; m.m[13] = c.y; m.m[14] = c.z + n.z * 0.02f;
    S.set("uModel", m);
    quad_.draw();
  }
  glEnable(GL_CULL_FACE);
  glDisable(GL_BLEND);
  S.set("uEmissive", 0.0f);
  S.set("uModel", mat4::identity());
  S.set("uMat", MAT_MODEL);
}
