// Sculpted creature and prop models: SDF sculpts meshed at startup, skinned to
// simple skeletons, animated procedurally and drawn with GPU skinning.
#pragma once
#include "mathx.h"
#include "render.h"
#include <vector>

struct Bone {
  int parent;
  vec3 head, tail;  // bind pose, model space (metres, +Y up, facing -Z)
};

struct Model {
  std::vector<Bone> bones;
  GpuMesh mesh;
  bool skinned = false;
  vec4 region[8];  // rgb albedo, a = emissive strength
  float spec[8] = {0.15f, 0.15f, 0.15f, 0.15f, 0.15f, 0.15f, 0.15f, 0.15f};
  int triangles = 0;
};

enum CreatureId { CR_TENANT = 0, CR_HOUND, CR_GRIN, CR_HUMAN, CR_SUIT, CR_WORKER, CR_HAZMAT, CR_STILT, CR_PARTYGOER, CR_COUNT };
enum PropId { PR_CHAIR = 0, PR_BOX, PR_BAG, PR_LANTERN, PR_CAN, PR_COOLER, PR_SHELF, PR_COUNTER, PR_FREEZER, PR_PANEL, PR_BOILER, PR_LOCKER, PR_CART, PR_COUCH, PR_TVSET, PR_TABLE, PR_LAMP, PR_TUBE,
             PR_REGISTER, PR_DRAWER, PR_SNACK, PR_BOTTLE, PR_PACK, PR_FPARM, PR_FPHAND, PR_DESK, PR_ARCH, PR_REACH,
             PR_HOURGLASS, PR_SPIRAL, PR_HOUSE, PR_DOORSIDE, PR_DOORLEAF, PR_CAR, PR_COUNT };

struct AnimInput {
  float time = 0;
  float phase = 0;   // locomotion cycle (radians)
  float speed = 0;   // 0 idle .. 1 walk .. 2 run
  float twitch = 0;  // 0..1
  float alert = 0;   // 0 calm .. 1 hunting
  float carry = 0;   // humans: arms out carrying something
  float look = 0;    // humans: head turn (radians)
  int sit = 0;       // humans: 1 on the floor, legs out; 2 kneeling; 3 on a seat
  float hug = 0;     // humans: arms around someone in front
  float hold = 0;    // humans: right hand holding something at the waist
  float offer = 0;   // humans: right arm held out (handing over cash)
  float cross = 0;   // humans: arms folded, waiting and annoyed
};

namespace creatures {
bool build(float quality);
void setProgress(void (*fn)(float, void*), void* user);  // called after each model while build() runs  // quality scales mesh resolution (0.6 .. 1.0)
Model& creature(CreatureId id);
Model& prop(PropId id);
// Fills `out` with skinning matrices (world space) for the creature at `world`.
void pose(CreatureId id, const AnimInput& in, const mat4& world, std::vector<mat4>& out);
}  // namespace creatures
