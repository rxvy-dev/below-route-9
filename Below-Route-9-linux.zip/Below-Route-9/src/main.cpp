// BELOW ROUTE 9 — a Backrooms horror game for Linux.
#include "audio.h"
#include "game.h"
#include "gl.h"
#include "render.h"
#include <SDL.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>
#ifndef BR9_VERSION
#define BR9_VERSION "dev"
#endif
#ifndef BR9_COMMIT
#define BR9_COMMIT "source"
#endif

static void usage() {
  std::printf(
      "BELOW ROUTE 9 - a Backrooms horror game\n\n"
      "usage: below-route-9 [options]\n"
      "  --seed N            generate Level 0 from seed N\n"
      "  --windowed          start windowed regardless of settings\n"
      "  --size WxH          window size (default 1280x720)\n"
      "  --no-audio          disable sound\n"
      "  --screenshot FILE   render, save a PPM screenshot and exit (testing)\n"
      "  --frames N          frames to simulate before the screenshot (default 90)\n"
      "  --scene NAME        title | play | tenant | hound | grin | hunt | camp | clue | pool | dark | exit | exitwalk | note | pause | transition\n"
      "  --quality N         graphics preset 0 (low) .. 2 (high)\n"
      "  --level N           start at level N (0 Lobby, 1 Habitable Zone, 2 Pipe Dreams, 3 Poolrooms, 4 Lights Out, 5+ endless)\n"
      "  --version           print version\n\n"
      "Wayland: SDL_VIDEODRIVER=wayland below-route-9\n"
      "Saves:   $XDG_DATA_HOME/below-route-9   Settings: $XDG_CONFIG_HOME/below-route-9\n");
}

static bool writePPM(const std::string& path, const std::vector<uint8_t>& rgb, int w, int h) {
  std::ofstream f(path, std::ios::binary);
  if (!f) return false;
  f << "P6\n" << w << " " << h << "\n255\n";
  for (int y = h - 1; y >= 0; --y) f.write(reinterpret_cast<const char*>(&rgb[(size_t)y * w * 3]), (std::streamsize)w * 3);
  return (bool)f;
}

static void fatal(const std::string& msg) {
  std::fprintf(stderr, "[br9] %s\n", msg.c_str());
  SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "BELOW ROUTE 9", msg.c_str(), nullptr);
}

int main(int argc, char** argv) {
  Options opt;
  std::string recordDir;  // capture: raw RGB frames + float audio at a fixed 30 fps
  for (int i = 1; i < argc; ++i) {
    std::string a = argv[i];
    auto next = [&]() -> std::string { return i + 1 < argc ? argv[++i] : std::string(); };
    if (a == "--seed") opt.seed = (uint32_t)std::strtoul(next().c_str(), nullptr, 10);
    else if (a == "--windowed") opt.forceWindowed = true;
    else if (a == "--size") { std::string s = next(); std::sscanf(s.c_str(), "%dx%d", &opt.width, &opt.height); }
    else if (a == "--no-audio") opt.noAudio = true;
    else if (a == "--screenshot") opt.screenshot = next();
    else if (a == "--frames") opt.frames = std::atoi(next().c_str());
    else if (a == "--scene") opt.scene = next();
    else if (a == "--quality") opt.quality = std::atoi(next().c_str());
    else if (a == "--level") opt.level = std::atoi(next().c_str());
    else if (a == "--record") recordDir = next();
    else if (a == "--version") { std::printf("below-route-9 %s (%s)\n", BR9_VERSION, BR9_COMMIT); return 0; }
    else if (a == "--help" || a == "-h") { usage(); return 0; }
    else { std::fprintf(stderr, "unknown option: %s\n", a.c_str()); usage(); return 1; }
  }
  if (!recordDir.empty()) { opt.screenshot = recordDir + "/last.ppm"; opt.noAudio = true; }
  if (!opt.screenshot.empty()) { opt.forceWindowed = true; if (opt.frames <= 0) opt.frames = 90; }

  SDL_SetHint(SDL_HINT_VIDEO_X11_NET_WM_BYPASS_COMPOSITOR, "0");
  SDL_SetHint(SDL_HINT_APP_NAME, "BELOW ROUTE 9");
  Uint32 flags = SDL_INIT_VIDEO | SDL_INIT_EVENTS | SDL_INIT_GAMECONTROLLER;
  if (!opt.noAudio) flags |= SDL_INIT_AUDIO;
  if (SDL_Init(flags) != 0) {
    // Audio or controllers failing shouldn't stop the game.
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS) != 0) { fatal(std::string("SDL_Init failed: ") + SDL_GetError()); return 1; }
    opt.noAudio = true;
  }

  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
  SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);

  SDL_Window* win = SDL_CreateWindow("BELOW ROUTE 9", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, opt.width, opt.height,
                                     SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);
  if (!win) { fatal(std::string("Could not create window: ") + SDL_GetError()); SDL_Quit(); return 1; }
  SDL_GLContext ctx = SDL_GL_CreateContext(win);
  if (!ctx) {
    fatal(std::string("OpenGL 3.3 is required but could not be initialised.\n") + SDL_GetError() +
          "\n\nUpdate your graphics drivers (Mesa 10+, or the Nvidia/AMD proprietary driver).");
    SDL_DestroyWindow(win); SDL_Quit(); return 1;
  }
  if (SDL_GL_SetSwapInterval(-1) != 0) SDL_GL_SetSwapInterval(1);

  const char* missing = nullptr;
  if (!gl::load(&missing)) { fatal(std::string("Missing OpenGL function: ") + (missing ? missing : "?")); return 1; }
  std::fprintf(stderr, "[br9] GL %s | %s | %s\n", (const char*)glGetString(GL_VERSION), (const char*)glGetString(GL_RENDERER),
               SDL_GetCurrentVideoDriver());

  Renderer renderer;
  std::string err;
  if (!renderer.init(err)) { fatal("Renderer init failed:\n" + err); return 1; }

  Audio audio;
  Audio* audioPtr = nullptr;
  if (!opt.noAudio && audio.init()) audioPtr = &audio;
  if (!recordDir.empty() && audio.initOffline()) audioPtr = &audio;

  Game game;
  if (!game.init(win, &renderer, audioPtr, opt, err)) { fatal("Game init failed:\n" + err); return 1; }
  if (game.settings.fullscreen) SDL_SetWindowFullscreen(win, SDL_WINDOW_FULLSCREEN_DESKTOP);
  {
    int w, h;
    SDL_GL_GetDrawableSize(win, &w, &h);
    game.onResize(w, h);
  }

  Uint64 freq = SDL_GetPerformanceFrequency(), last = SDL_GetPerformanceCounter();
  int frame = 0;
  int rc = 0;
  while (!game.wantsQuit()) {
    SDL_Event e;
    while (SDL_PollEvent(&e)) game.event(e);
    Uint64 now = SDL_GetPerformanceCounter();
    float dt = (float)((double)(now - last) / (double)freq);
    last = now;
    if (!opt.screenshot.empty()) dt = 1.0f / 60.0f;  // deterministic testing
    static const int recFps = std::getenv("BR9_FPS") ? std::atoi(std::getenv("BR9_FPS")) : 30;
    if (!recordDir.empty()) dt = 1.0f / (float)recFps;
    if (dt > 0.1f) dt = 0.1f;
    game.update(dt);
    game.render();
    ++frame;
    if (!recordDir.empty()) {
      static std::ofstream vf(recordDir + "/frames.rgb", std::ios::binary), af(recordDir + "/audio.f32", std::ios::binary);
      std::vector<uint8_t> rgb;
      int w, h;
      renderer.readPixels(rgb, w, h);
      for (int y = h - 1; y >= 0; --y) vf.write(reinterpret_cast<const char*>(&rgb[(size_t)y * w * 3]), (std::streamsize)w * 3);
      static const int spf = 48000 / recFps;
      static std::vector<float> pcm((size_t)spf * 2);
      audio.renderOffline(pcm.data(), spf);
      af.write(reinterpret_cast<const char*>(pcm.data()), (std::streamsize)(pcm.size() * sizeof(float)));
      if (frame == 1) std::fprintf(stderr, "[br9] recording %dx%d to %s\n", w, h, recordDir.c_str());
    }
    if (!opt.screenshot.empty() && frame >= opt.frames) {
      std::vector<uint8_t> rgb;
      int w, h;
      renderer.readPixels(rgb, w, h);
      game.debugReport();
      if (writePPM(opt.screenshot, rgb, w, h)) std::fprintf(stderr, "[br9] wrote %s (%dx%d)\n", opt.screenshot.c_str(), w, h);
      else { std::fprintf(stderr, "[br9] could not write %s\n", opt.screenshot.c_str()); rc = 1; }
      break;
    }
    SDL_GL_SwapWindow(win);
  }

  game.shutdown();
  if (audioPtr) audio.shutdown();
  renderer.shutdown();
  SDL_GL_DeleteContext(ctx);
  SDL_DestroyWindow(win);
  SDL_Quit();
  return rc;
}
