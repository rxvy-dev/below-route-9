// The till, what people carry, and Dana's own hands.
#include <cmath>
#include <cstdio>
#include <cstdlib>

#include "audio.h"
#include "game.h"
#include "texgen.h"

namespace {
mat4 frame(vec3 r, vec3 u, vec3 n, vec3 p) {
  mat4 m = mat4::identity();
  m.m[0] = r.x; m.m[1] = r.y; m.m[2] = r.z;
  m.m[4] = u.x; m.m[5] = u.y; m.m[6] = u.z;
  m.m[8] = n.x; m.m[9] = n.y; m.m[10] = n.z;
  m.m[12] = p.x; m.m[13] = p.y; m.m[14] = p.z;
  return m;
}
vec3 xform(const mat4& m, vec3 p) {
  return {m.m[0] * p.x + m.m[4] * p.y + m.m[8] * p.z + m.m[12], m.m[1] * p.x + m.m[5] * p.y + m.m[9] * p.z + m.m[13],
          m.m[2] * p.x + m.m[6] * p.y + m.m[10] * p.z + m.m[14]};
}
const PropId kItems[4] = {PR_CAN, PR_SNACK, PR_BOTTLE, PR_PACK};
// a few liveries per item (region 0 / region 1)
const vec4 kItemCols[4][4][2] = {
    {{{0.55f, 0.06f, 0.05f, 0}, {0.8f, 0.78f, 0.75f, 0}}, {{0.1f, 0.25f, 0.6f, 0}, {0.8f, 0.8f, 0.82f, 0}},
     {{0.15f, 0.45f, 0.12f, 0}, {0.85f, 0.8f, 0.2f, 0}}, {{0.6f, 0.6f, 0.62f, 0}, {0.1f, 0.1f, 0.12f, 0}}},
    {{{0.85f, 0.12f, 0.08f, 0}, {0.9f, 0.75f, 0.3f, 0}}, {{0.9f, 0.7f, 0.1f, 0}, {0.6f, 0.1f, 0.05f, 0}},
     {{0.15f, 0.3f, 0.7f, 0}, {0.85f, 0.85f, 0.8f, 0}}, {{0.2f, 0.55f, 0.2f, 0}, {0.9f, 0.85f, 0.4f, 0}}},
    {{{0.1f, 0.04f, 0.02f, 0}, {0.75f, 0.08f, 0.06f, 0}}, {{0.35f, 0.6f, 0.15f, 0}, {0.1f, 0.4f, 0.1f, 0}},
     {{0.75f, 0.35f, 0.05f, 0}, {0.1f, 0.1f, 0.35f, 0}}, {{0.6f, 0.75f, 0.8f, 0}, {0.15f, 0.25f, 0.6f, 0}}},
    {{{0.9f, 0.7f, 0.1f, 0}, {0.85f, 0.2f, 0.12f, 0}}, {{0.35f, 0.15f, 0.08f, 0}, {0.9f, 0.85f, 0.75f, 0}},
     {{0.9f, 0.9f, 0.88f, 0}, {0.2f, 0.4f, 0.75f, 0}}, {{0.5f, 0.1f, 0.4f, 0}, {0.95f, 0.8f, 0.2f, 0}}},
};
}  // namespace

void Game::setRegisterText(const std::string& t) {
  if (t == regText_ && texRegDisp_) return;
  regText_ = t;
  if (texRegDisp_) glDeleteTextures(1, &texRegDisp_);
  texRegDisp_ = makeTexture(texgen::signText(t.empty() ? " " : t.c_str(), 384, 96, 0.35f, 1.0f, 0.75f, 0.01f, 0.03f, 0.025f), true, false);
}

void Game::drawItemModel(Shader& S, int item, int color, const mat4& m) {
  if (item < 0 || item > 3) return;
  Model& md = creatures::prop(kItems[item]);
  vec4 keep0 = md.region[0], keep1 = md.region[1];
  md.region[0] = kItemCols[item][color & 3][0];
  md.region[1] = kItemCols[item][color & 3][1];
  drawModel(S, md, m);
  md.region[0] = keep0;
  md.region[1] = keep1;
}

void Game::drawRegister(Shader& S) {
  const StoreSpots& st = level_.store;
  if (!texBill_) texBill_ = makeTexture(texgen::bill(256, 108, 20), true, false);
  if (!texRegDisp_) setRegisterText(storePowered() ? "QUIK-STOP" : "");
  vec3 base{st.registerPos.x, 0.965f, st.registerPos.z};
  mat4 W = translate(base) * rotY(kPi * 0.5f);
  S.set("uMat", MAT_MODEL);
  S.set("uSkinned", 0);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  drawModel(S, creatures::prop(PR_REGISTER), W);
  drawModel(S, creatures::prop(PR_DRAWER), W * translate({0, 0.012f, 0.07f + drawer_ * 0.28f}));
  // items waiting on the counter
  for (const Npc& n : customers_)
    if (n.active && n.itemDown && n.item >= 0)
      drawItemModel(S, n.item, n.itemColor, translate(base + vec3{-0.2f, 0, -0.42f}) * rotY(0.6f + n.itemColor));
  // displays (clerk side and the pole facing the customer)
  if (storePowered() || saleStage_ > 0) {
    S.set("uMat", MAT_SCREEN);
    S.set("uUVScale", 1.0f);
    glBindTexture(GL_TEXTURE_2D, texRegDisp_);
    S.set("uEmissive", 1.4f);
    S.set("uModel", W * frame({0.165f, 0, 0}, {0, 0.042f, 0}, {0, 0, 1}, {0, 0.262f, -0.0585f}));
    quad_.draw();
    S.set("uModel", W * frame({-0.104f, 0, 0}, {0, 0.028f, 0}, {0, 0, -1}, {0.145f, 0.44f, -0.1745f}));
    quad_.draw();
  }
  // a bill on top of the drawer's stack while it's open
  if (drawer_ > 0.3f) {
    S.set("uMat", MAT_SCREEN);
    glBindTexture(GL_TEXTURE_2D, texBill_);
    S.set("uEmissive", 0.25f);
    S.set("uModel", W * translate({-0.04f, 0.045f, 0.035f + drawer_ * 0.28f}) * frame({0, 0, 0.13f}, {0.058f, 0, 0}, {0, 1, 0}, {0, 0, 0}));
    quad_.draw();
  }
  S.set("uMat", MAT_MODEL);
  S.set("uEmissive", 0.0f);
}

// Called right after drawCreatureAt for an NPC: what's in their right hand.
void Game::drawHeldItem(Shader& S, const Npc& n, CreatureId id) {
  bool item = n.item >= 0 && !n.itemDown;
  bool cash = n.offer > 0.25f;
  if (!item && !cash) return;
  const Model& m = creatures::creature(id);
  if (boneScratch_.size() < 9 || m.bones.size() < 9) return;
  vec3 mid = (m.bones[8].head + m.bones[8].tail) * 0.5f;
  vec3 hand = xform(boneScratch_[8], mid);
  float c = std::cos(n.yaw), s = std::sin(n.yaw);
  vec3 fw{-s, 0, -c}, rt{c, 0, -s};
  if (item) {
    S.set("uMat", MAT_MODEL);
    drawItemModel(S, n.item, n.itemColor, translate(hand + fw * 0.03f - vec3{0, 0.09f, 0}) * rotY(n.yaw + 0.4f));
  }
  if (cash) {
    S.set("uMat", MAT_SCREEN);
    S.set("uUVScale", 1.0f);
    S.set("uSkinned", 0);
    glDisable(GL_CULL_FACE);
    glBindTexture(GL_TEXTURE_2D, texBill_ ? texBill_ : texWhite_);
    S.set("uEmissive", 0.25f);
    S.set("uModel", frame(fw * 0.155f, rt * 0.066f + vec3{0, 0.02f, 0}, {0, 1, 0}, hand + fw * 0.07f));
    quad_.draw();
    glEnable(GL_CULL_FACE);
    S.set("uMat", MAT_MODEL);
  }
}

// Dana's hands: the flashlight, cash from the till, the stock box. In the suit: yellow sleeves, black gloves.
void Game::drawFirstPerson(Shader& S) {
  if (screen_ != Screen::Playing && screen_ != Screen::Paused && screen_ != Screen::Reading && screen_ != Screen::Plunge) return;
  if (dropping_) return;  // the camera's on the floor; you're over there
  static const bool cine = std::getenv("BR9_CINE") != nullptr;
  if (cine) return;
  vec3 cam = eye();
  vec3 D = flashOn_ ? normalize(flashDir_) : forward();
  vec3 F = forward();
  vec3 R = normalize(cross(F, vec3{0, 1, 0}));
  vec3 U = cross(R, F);
  vec4 suitCols[4] = {{0.36f, 0.06f, 0.07f, 0}, {0.62f, 0.45f, 0.36f, 0}, {0.28f, 0.04f, 0.05f, 0}, {0.1f, 0.1f, 0.11f, 0}};
  if (hazmat_) {
    suitCols[0] = {0.86f, 0.74f, 0.14f, 0};
    suitCols[1] = {0.012f, 0.012f, 0.012f, 0};
    suitCols[2] = {0.015f, 0.015f, 0.015f, 0};
  }
  float bobX = std::sin(stepPhase_) * 0.006f, bobY = std::fabs(std::cos(stepPhase_)) * 0.006f;
  glDisable(GL_CULL_FACE);
  S.set("uMat", MAT_MODEL);
  S.set("uSkinned", 0);
  glBindTexture(GL_TEXTURE_2D, texWhite_);
  auto arm = [&](PropId id, vec3 at, vec3 dir, float side) {
    vec3 r = normalize(cross(dir, vec3{0, 1, 0}));
    vec3 u = cross(r, dir);
    // Everything at half size and half distance: looks the same, clips walls half as much.
    mat4 m = frame(r * (0.5f * side), u * 0.5f, dir * -0.5f, at);
    Model& md = creatures::prop(id);
    vec4 keep[4];
    for (int k = 0; k < 4; ++k) { keep[k] = md.region[k]; md.region[k] = suitCols[k]; }
    drawModel(S, md, m);
    for (int k = 0; k < 4; ++k) md.region[k] = keep[k];
  };
  if (flashOn_ && hasFlashlight_ && battery_ > 0 && !nightShot()) {
    vec3 at = cam + (R * 0.17f - U * 0.165f + F * 0.24f) * 0.5f + R * bobX - U * bobY;
    arm(PR_FPARM, at, D, 1.0f);
    // the lens, lit
    vec3 r = normalize(cross(D, vec3{0, 1, 0}));
    vec3 u = cross(r, D);
    S.set("uMat", MAT_PROP);
    drawPart(frame(r * 0.019f, u * 0.019f, D * 0.002f, at + D * 0.0895f), {1.0f, 0.97f, 0.9f}, 6.0f);
    S.set("uMat", MAT_MODEL);
  }
  if (cashHeld_) {  // left hand, holding the twenty
    vec3 dir = normalize(F + R * 0.25f - U * 0.25f);
    vec3 at = cam + (-R * 0.13f - U * 0.14f + F * 0.24f) * 0.5f + R * bobX - U * bobY;
    arm(PR_FPHAND, at, dir, -1.0f);
    S.set("uMat", MAT_SCREEN);
    S.set("uUVScale", 1.0f);
    glBindTexture(GL_TEXTURE_2D, texBill_ ? texBill_ : texWhite_);
    S.set("uEmissive", 0.35f);
    vec3 bc = at + dir * 0.03f + U * 0.02f;
    S.set("uModel", frame(normalize(R + F * 0.3f) * 0.078f, normalize(U * 0.8f - F * 0.4f) * 0.033f, normalize(-F), bc));
    quad_.draw();
    S.set("uMat", MAT_MODEL);
    glBindTexture(GL_TEXTURE_2D, texWhite_);
  }
  if (carrying_) {  // both hands under the stock box
    for (int sd = -1; sd <= 1; sd += 2) {
      vec3 at = cam + (R * (0.17f * sd) - U * 0.3f + F * 0.42f) * 0.5f - U * bobY;
      arm(PR_FPHAND, at, normalize(F - U * 0.2f + R * (-0.35f * sd)), (float)sd);
    }
  }
  glEnable(GL_CULL_FACE);
  S.set("uModel", mat4::identity());
}

// The Grin sheds soot: dark puffs that peel off its edges and drift up.
void Game::drawSoot(Shader& S, vec3 at, float t, vec3 cam) {
  if (!texSoot_) {
    Image im;
    im.w = im.h = 64;
    im.px.resize(64 * 64 * 4);
    for (int y = 0; y < 64; ++y)
      for (int x = 0; x < 64; ++x) {
        float dx = (x + 0.5f) / 32 - 1, dy = (y + 0.5f) / 32 - 1;
        float d = std::sqrt(dx * dx + dy * dy) + (hashf(x / 4, y / 4, 9) - 0.5f) * 0.35f;
        float a = clampf(1.0f - d, 0, 1);
        size_t i = ((size_t)y * 64 + x) * 4;
        im.px[i] = im.px[i + 1] = im.px[i + 2] = 255;
        im.px[i + 3] = (uint8_t)(a * a * 255);
      }
    texSoot_ = makeTexture(im, true, false);
  }
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDepthMask(GL_FALSE);
  S.set("uMat", MAT_DECAL);
  S.set("uSkinned", 0);
  S.set("uFlipU", 0);
  S.set("uTint", vec3{0.004f, 0.004f, 0.005f});
  S.set("uEmissive", 0.0f);
  glBindTexture(GL_TEXTURE_2D, texSoot_);
  for (int i = 0; i < 14; ++i) {
    float life = std::fmod(t * 0.35f + hashf(i, 3), 1.0f);
    float ang = hashf(i, 5) * 6.2832f + t * 0.2f;
    float rad = 0.25f + 0.35f * life;
    vec3 p = at + vec3{std::cos(ang) * rad, 0.6f + hashf(i, 7) * 1.6f + life * 0.9f, std::sin(ang) * rad};
    vec3 n = cam - p;
    float dl = length(n);
    if (dl < 0.3f) continue;
    n = n * (1.0f / dl);
    vec3 r = normalize(cross(vec3{0, 1, 0}, n));
    vec3 u = cross(n, r);
    float sz = 0.25f + 0.45f * life;
    S.set("uModel", frame(r * sz, u * sz, n, p));
    // fade in, fade out; the decal shader takes alpha from the texture, so fake fade with size
    if (life < 0.1f || life > 0.85f) continue;
    quad_.draw();
  }
  glDepthMask(GL_TRUE);
  glDisable(GL_BLEND);
  S.set("uTint", vec3{1, 1, 1});
  S.set("uMat", MAT_MODEL);
  S.set("uModel", mat4::identity());
}
