// Sculpting with signed distance fields, meshed with Surface Nets.
// Produces smooth, organic, watertight meshes with per-vertex region tags
// (skin, eyes, teeth, glow...) and baked ambient occlusion.
#pragma once
#include "mathx.h"
#include <algorithm>
#include <cstdint>
#include <functional>
#include <vector>

struct SdfSample {
  float d;
  int region;
};
using SdfFn = std::function<SdfSample(vec3)>;

struct SdfMesh {
  std::vector<vec3> pos, nrm;
  std::vector<int> region;
  std::vector<float> ao;
  std::vector<uint32_t> idx;
};

SdfMesh surfaceNets(const SdfFn& f, vec3 bmin, vec3 bmax, float cell);

// ---- primitives and operators (all distances in metres)
namespace sdf {
inline float smin(float a, float b, float k) {
  float h = clampf(0.5f + 0.5f * (b - a) / k, 0.0f, 1.0f);
  return lerpf(b, a, h) - k * h * (1.0f - h);
}
inline float smax(float a, float b, float k) { return -smin(-a, -b, k); }

// Capsule between a and b with radius tapering from ra to rb.
inline float cone(vec3 p, vec3 a, vec3 b, float ra, float rb) {
  vec3 pa = p - a, ba = b - a;
  float h = clampf(dot(pa, ba) / std::max(dot(ba, ba), 1e-8f), 0.0f, 1.0f);
  return length(pa - ba * h) - lerpf(ra, rb, h);
}
inline float ellipsoid(vec3 p, vec3 c, vec3 r) {
  vec3 q = p - c;
  vec3 a{q.x / r.x, q.y / r.y, q.z / r.z};
  vec3 b{q.x / (r.x * r.x), q.y / (r.y * r.y), q.z / (r.z * r.z)};
  float k0 = length(a), k1 = length(b);
  return k1 > 1e-8f ? k0 * (k0 - 1.0f) / k1 : -std::min(r.x, std::min(r.y, r.z));
}
inline float sphere(vec3 p, vec3 c, float r) { return length(p - c) - r; }
// Vertical cylinder centred at c with radius r and half-height h, rounded edges.
inline float cylinder(vec3 p, vec3 c, float r, float h, float round = 0.0f) {
  float dx = std::sqrt((p.x - c.x) * (p.x - c.x) + (p.z - c.z) * (p.z - c.z)) - r + round;
  float dy = std::fabs(p.y - c.y) - h + round;
  return std::min(std::max(dx, dy), 0.0f) + std::sqrt(std::max(dx, 0.0f) * std::max(dx, 0.0f) + std::max(dy, 0.0f) * std::max(dy, 0.0f)) - round;
}
inline float box(vec3 p, vec3 c, vec3 h, float round) {
  vec3 q{std::fabs(p.x - c.x) - h.x + round, std::fabs(p.y - c.y) - h.y + round, std::fabs(p.z - c.z) - h.z + round};
  vec3 m{std::max(q.x, 0.0f), std::max(q.y, 0.0f), std::max(q.z, 0.0f)};
  return length(m) + std::min(std::max(q.x, std::max(q.y, q.z)), 0.0f) - round;
}
// Value noise in 3D, roughly [-1,1].
float noise(vec3 p);
float fbm(vec3 p, int oct);
}  // namespace sdf

// Accumulates a union of shapes while remembering which region is closest.
struct SdfBuilder {
  float d = 1e9f;
  int region = 0;
  float bestRaw = 1e9f;
  void add(float dd, int reg, float k) {
    if (dd < bestRaw) { bestRaw = dd; region = reg; }
    d = k > 0 ? sdf::smin(d, dd, k) : std::min(d, dd);
  }
  void cut(float dd, float k, int reg = -1) {
    float nd = k > 0 ? sdf::smax(d, -dd, k) : std::max(d, -dd);
    if (reg >= 0 && -dd > d - 0.01f) region = reg;
    d = nd;
  }
};
