#!/usr/bin/env python3
"""Bake the 'Count On Me!' office mural to an RLE RGBA header: src/mural_data.h.
Title: Courgette (SIL OFL 1.1, assets/fonts). Lines: Liberation Sans (SIL OFL).
Usage: python3 tools/make_mural.py"""
import math
from PIL import Image, ImageDraw, ImageFont
W, H = 1024, 384
img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
title = ImageFont.truetype("assets/fonts/Courgette-Regular.ttf", 132)
body = ImageFont.truetype("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf", 30)
blue, navy = (30, 58, 168, 255), (20, 30, 80, 255)
# the title, slightly rising left to right like the painted one
t = Image.new("RGBA", (W, 220), (0, 0, 0, 0))
ImageDraw.Draw(t).text((W // 2, 112), "Count On Me!", font=title, fill=blue, anchor="mm", stroke_width=3, stroke_fill=blue)
t = t.rotate(4, resample=Image.BICUBIC, center=(W // 2, 110))
img.alpha_composite(t, (0, 0))
# the swoosh underneath: thin at the ends, thick in the middle
for i in range(240):
    k = i / 239
    x = 150 + k * 700
    y = 205 - k * 40 + 10 * math.sin(k * math.pi)
    w = 2 + 5 * math.sin(k * math.pi)
    d.ellipse((x - w, y - w * 0.6, x + w, y + w * 0.6), fill=blue)
# three lines, centred under it
lines = ["Be Responsive", "Be Respectful", "Deliver Great Customer Experiences"]
cx = 560
for i, s in enumerate(lines):
    d.text((cx, 248 + i * 36), s, font=body, fill=navy, anchor="mm")
# beach-ball badges: one right of the first line, one left of the second
def ball(x, y, r):
    cols = [(220, 40, 40), (250, 200, 30), (40, 90, 210), (245, 245, 240), (220, 40, 40), (40, 160, 90)]
    for j, c in enumerate(cols):
        d.pieslice((x - r, y - r, x + r, y + r), j * 60 - 20, j * 60 + 40, fill=c + (255,))
    d.ellipse((x - r, y - r, x + r, y + r), outline=navy, width=3)
ball(cx + 150, 240, 21)
ball(cx - 150, 284, 21)
px = img.tobytes()
rle, i = [], 0
while i < len(px):
    v = px[i:i + 4]; n = 1
    while i + 4 * n < len(px) and px[i + 4 * n:i + 4 * n + 4] == v and n < 255: n += 1
    rle += [n] + list(v); i += 4 * n
L = ["// The 'Count On Me!' office mural, baked by tools/make_mural.py (Courgette + Liberation Sans, SIL OFL 1.1).",
     "#pragma once", "#include <cstdint>", f"constexpr int kMuralW = {W}, kMuralH = {H};", "static const uint8_t kMuralRLE[] = {"]
L += ["  " + ",".join(str(b) for b in rle[k:k + 40]) + "," for k in range(0, len(rle), 40)]
L.append("};")
open("src/mural_data.h", "w").write("\n".join(L) + "\n")
bg = Image.new("RGBA", (W, H), (214, 196, 160, 255)); bg.alpha_composite(img)
bg.save("/tmp/claude-0/-home-claude/494d124a-6b31-56bf-ad3b-9e432e54486f/scratchpad/mural.png")
