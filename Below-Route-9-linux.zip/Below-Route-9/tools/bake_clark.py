# Bakes Captain Clark's walk (FBX, Mixamo rig) into a small vertex-animation file the game plays back.
#   blender -b --python tools/bake_clark.py -- "Drunk Walk.fbx" assets/models/clark.vam
# Format (little endian):
#   char[4] 'VAM1'; u32 nVerts, nIdx, nFrames, nMats; f32 loopSeconds, strideMetres, height
#   nMats x { char[32] texture name; u32 firstIdx, count }
#   nVerts x f32[2] uv
#   nIdx x u32 index
#   f32[3] posScale, f32[3] posOffset
#   nFrames x nVerts x { u16[3] pos (quantised), i8[3] normal, u8 pad }
import bpy, sys, struct, math
import numpy as np

src, dst = sys.argv[-2], sys.argv[-1]
FRAMES = 24
HEIGHT = 2.05  # metres: a head taller than an adult

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath=src)
scene = bpy.context.scene
meshes = [o for o in bpy.data.objects if o.type == 'MESH' and len(o.data.polygons) > 0]
texfor = {'Clarkclothes1Mtl2': 'clark_clothes', 'Clarkface1Mtl3': 'clark_face', 'Clarkfacedetails1Mtl0': 'clark_details', 'Clarkpants1Mtl1': 'clark_pants'}
for o in meshes:  # halve the polygons on the rest pose (before the armature, so it's the same mesh every frame)
    m = o.modifiers.new('dec', 'DECIMATE')
    m.ratio = 0.5
    while o.modifiers[0] != m:
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = o
        bpy.ops.object.modifier_move_up(modifier='dec')

act = bpy.data.actions[0]
f0, f1 = act.frame_range
loop_frames = f1 - f0
arm = next(o for o in bpy.data.objects if o.type == 'ARMATURE')
hips = next((b for b in arm.pose.bones if 'Hips' in b.name), arm.pose.bones[0])

def hips_world():
    return (arm.matrix_world @ hips.matrix).translation.copy()

samples = [f0 + loop_frames * k / FRAMES for k in range(FRAMES)]
dg = bpy.context.evaluated_depsgraph_get()
key = {}       # (mesh, vertex, uv) -> output vertex
uvs, idx, mats, frames = [], [], [], []
root0 = None
for fi, fr in enumerate(samples + [f1]):
    scene.frame_set(int(math.floor(fr)), subframe=fr - math.floor(fr))
    dg = bpy.context.evaluated_depsgraph_get()
    hp = hips_world()
    if fi == 0: root0 = hp
    if fi == FRAMES:  # one past the end: how far the walk carried it
        end_root = hp
        break
    pos = {}
    nrm = {}
    for mi, o in enumerate(meshes):
        ev = o.evaluated_get(dg)
        me = ev.to_mesh()
        me.calc_loop_triangles()
        uvl = me.uv_layers.active.data
        M = o.matrix_world
        Mn = M.to_3x3().inverted().transposed()
        if fi == 0: start = len(idx)
        for tri in me.loop_triangles:
            for li in tri.loops:
                v = me.loops[li].vertex_index
                uv = tuple(round(c, 5) for c in uvl[li].uv)
                k = (mi, v, uv)
                if fi == 0:
                    if k not in key:
                        key[k] = len(key)
                        uvs.append(uv)
                    idx.append(key[k])
                o_i = key.get(k)
                if o_i is None: continue
                if o_i not in pos:
                    p = M @ me.vertices[v].co
                    n = (Mn @ me.vertices[v].normal).normalized()
                    pos[o_i] = (p.x - hp.x, p.y - hp.y, p.z)
                    nrm[o_i] = (n.x, n.y, n.z)
        if fi == 0: mats.append((texfor.get(o.data.materials[0].name if o.data.materials else '', 'clark_clothes'), start, len(idx) - start))
        ev.to_mesh_clear()
    P = np.array([pos[i] for i in range(len(key))], np.float32)
    N = np.array([nrm[i] for i in range(len(key))], np.float32)
    frames.append((P, N))

# Blender is Z up; the game is Y up and faces -Z. Turn it so the way it walks is -Z.
walk = np.array([end_root.x - root0.x, end_root.y - root0.y])
stride_bu = float(np.linalg.norm(walk))
ang = math.atan2(walk[0], walk[1]) if stride_bu > 1e-6 else 0.0  # heading of the walk in Blender XY
ca, sa = math.cos(ang), math.sin(ang)
def to_game(P):
    x, y, z = P[:, 0], P[:, 1], P[:, 2]
    fx = ca * x - sa * y          # rotate so the walk points along Blender +Y
    fy = sa * x + ca * y
    return np.stack([fx, z, -fy], 1)  # +Y forward -> game -Z
allP = [to_game(P) for P, _ in frames]
allN = [to_game(N) for _, N in frames]
lo = np.min([p.min(0) for p in allP], 0); hi = np.max([p.max(0) for p in allP], 0)
s = HEIGHT / (hi[1] - lo[1])
allP = [(p - np.array([0, lo[1], 0])) * s for p in allP]   # feet on the ground, centred on the hips
lo = np.min([p.min(0) for p in allP], 0); hi = np.max([p.max(0) for p in allP], 0)
scale = (hi - lo) / 65535.0
stride = stride_bu * s
loop_seconds = loop_frames / scene.render.fps

with open(dst, 'wb') as f:
    f.write(b'VAM1')
    f.write(struct.pack('<4I3f', len(key), len(idx), FRAMES, len(mats), loop_seconds, stride, HEIGHT))
    for name, first, count in mats:
        f.write(struct.pack('<32s2I', name.encode(), first, count))
    f.write(np.array(uvs, np.float32).tobytes())
    f.write(np.array(idx, np.uint32).tobytes())
    f.write(struct.pack('<6f', *scale, *lo))
    for P, N in zip(allP, allN):
        q = np.clip(np.round((P - lo) / scale), 0, 65535).astype(np.uint16)
        n = np.clip(np.round(N / np.maximum(np.linalg.norm(N, axis=1, keepdims=True), 1e-6) * 127), -127, 127).astype(np.int8)
        rec = np.zeros(len(P), dtype=[('p', '<u2', 3), ('n', 'i1', 3), ('pad', 'u1')])
        rec['p'] = q; rec['n'] = n
        f.write(rec.tobytes())
print('BAKED', dst, 'verts', len(key), 'tris', len(idx) // 3, 'frames', FRAMES, 'loop', loop_seconds, 's stride', round(stride, 2), 'm mats', mats)
