#!/usr/bin/env python3
"""Bake the closing-down store signs to RLE RGBA: src/signs_data.h.
  - THE END IS NEAR: mismatched stick-on letters, the way somebody rearranged a store sign
  - FOR SALE: a yellow poster taped to the pillars
Fonts: Liberation Sans / Serif (SIL OFL 1.1), DejaVu Sans (free licence).
Usage: python3 tools/make_signs.py"""
import random
from PIL import Image, ImageDraw, ImageFont, ImageFilter
LIB = "/usr/share/fonts/truetype/liberation/"
DJV = "/usr/share/fonts/truetype/dejavu/"
random.seed(7)

def rle(img):
    px = img.tobytes(); out = []; i = 0
    while i < len(px):
        v = px[i:i + 4]; n = 1
        while i + 4 * n < len(px) and px[i + 4 * n:i + 4 * n + 4] == v and n < 255: n += 1
        out += [n] + list(v); i += 4 * n
    return out

# ---- THE END IS NEAR
W, H = 1024, 160
end = Image.new("RGBA", (W, H), (0, 0, 0, 0))
pieces = [("T", LIB + "LiberationSerif-Bold.ttf", 118, 0), ("H", LIB + "LiberationSerif-Bold.ttf", 118, 0), ("E", LIB + "LiberationSans-Bold.ttf", 112, 0),
          (" ", None, 60, 0),
          ("E", LIB + "LiberationSerif-Bold.ttf", 120, 0), ("N", LIB + "LiberationSans-Bold.ttf", 116, 0), ("D", LIB + "LiberationSerif-Bold.ttf", 120, 0),
          (" ", None, 34, 0), ("i", DJV + "DejaVuSans-Bold.ttf", 80, 22), ("s", LIB + "LiberationSerif-Bold.ttf", 80, 22), (" ", None, 34, 0),
          ("N", LIB + "LiberationSerif-Bold.ttf", 120, 0), ("E", LIB + "LiberationSans-Bold.ttf", 114, 0), ("a", DJV + "DejaVuSans-Bold.ttf", 84, 18),
          ("R", LIB + "LiberationSerif-Bold.ttf", 124, 0)]
x = 70
SC = 0.8
ink, shade = (26, 24, 22, 255), (0, 0, 0, 120)
for ch, font, size, drop in pieces:
    size = int(size * SC); drop = int(drop * SC)
    if font is None: x += size; continue
    f = ImageFont.truetype(font, size)
    w = int(f.getlength(ch)) + 12
    g = Image.new("RGBA", (w + 20, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(g)
    base = 122 + drop + random.randint(-4, 4)
    gd.text((8 + 5, base + 5), ch, font=f, fill=shade, anchor="ls")       # the letters stand off the wall a little
    g = g.filter(ImageFilter.GaussianBlur(3))
    ImageDraw.Draw(g).text((8, base), ch, font=f, fill=ink, anchor="ls")
    g = g.rotate(random.uniform(-4, 4), resample=Image.BICUBIC, center=(w // 2, base - size // 3))
    end.alpha_composite(g, (x - 8, 0))
    x += w - 4
print("END width", x)

# ---- FOR SALE poster
SW, SH = 256, 336
sale = Image.new("RGBA", (SW, SH), (236, 226, 70, 255))
sd = ImageDraw.Draw(sale)
big = ImageFont.truetype(LIB + "LiberationSans-Bold.ttf", 46)
mid = ImageFont.truetype(LIB + "LiberationSans-Bold.ttf", 30)
sd.text((SW // 2, 52), "FOR SALE", font=big, fill=(20, 20, 20, 255), anchor="mm")
sd.line((24, 92, SW - 24, 92), fill=(20, 20, 20, 255), width=4)
for i, line in enumerate(["ALL FIXTURES,", "FURNITURE &", "EQUIPMENT"]):
    sd.text((SW // 2, 130 + i * 38), line, font=mid, fill=(20, 20, 20, 255), anchor="mm")
small = ImageFont.truetype(LIB + "LiberationSans-Bold.ttf", 17)
sd.text((SW // 2, 262), "INQUIRE AT THE FRONT", font=small, fill=(30, 30, 30, 255), anchor="mm")
sd.text((SW // 2, 290), "www.bkm-liquidation.com", font=small, fill=(30, 30, 30, 255), anchor="mm")
# tape at the corners, a little dirt
for cx, cy in [(10, 8), (SW - 10, 8), (10, SH - 8), (SW - 10, SH - 8)]:
    sd.rectangle((cx - 16, cy - 7, cx + 16, cy + 7), fill=(225, 222, 205, 210))
grime = Image.effect_noise((SW, SH), 22).convert("L").filter(ImageFilter.GaussianBlur(2))
sale = Image.composite(sale, Image.new("RGBA", (SW, SH), (200, 190, 50, 255)), grime.point(lambda v: 255 if v > 96 else 225))

L = ["// The closing-down store signs, baked by tools/make_signs.py (Liberation Sans/Serif, SIL OFL 1.1; DejaVu Sans).",
     "#pragma once", "#include <cstdint>", f"constexpr int kEndW = {W}, kEndH = {H}, kSaleW = {SW}, kSaleH = {SH};"]
for name, im in (("kEndRLE", end), ("kSaleRLE", sale)):
    r = rle(im)
    L.append(f"static const uint8_t {name}[] = {{")
    L += ["  " + ",".join(str(b) for b in r[k:k + 40]) + "," for k in range(0, len(r), 40)]
    L.append("};")
open("src/signs_data.h", "w").write("\n".join(L) + "\n")
prev = Image.new("RGBA", (W, H + SH), (214, 200, 160, 255)); prev.alpha_composite(end); prev.alpha_composite(sale, (40, H))
prev.save("/tmp/claude-0/-home-claude/494d124a-6b31-56bf-ad3b-9e432e54486f/scratchpad/signs.png")
