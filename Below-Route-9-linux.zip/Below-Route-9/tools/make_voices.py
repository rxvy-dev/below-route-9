#!/usr/bin/env python3
"""Voices for every spoken line in BELOW ROUTE 9.

  python3 tools/make_voices.py list    # every line the game speaks -> assets/voices/lines.tsv
  python3 tools/make_voices.py synth   # speak them with Piper TTS -> assets/voices/<key>.wav
  python3 tools/make_voices.py build   # pack the .wav files into src/voices_data.h (IMA ADPCM)

`list` reads the source: every say("WHO", "text") and the random-line arrays, plus the crowd at
Route 9 Park. `synth` needs the Piper TTS LibriTTS multi-speaker voice (en_US libritts high, CC BY 4.0)
under $PIPER_VOICES (default ~/tts) and the `piper` Python package or binary. `build` needs nothing
but the .wav files; with none it writes an empty table and the game stays silent as before.
Keys are FNV-1a hashes of the exact text, so the game finds a line's clip by what it says.
"""
import os, re, struct, subprocess, sys, wave

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'assets', 'voices')

def fnv(s):
    h = 2166136261
    for b in s.encode('utf-8'):
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return h

# Arrays of random lines and who says them.
ARRAYS = {'kRayCarried': 'RAY', 'kRayCalling': 'RAY', 'kRayBegging': 'RAY', 'kHide': '???', 'kNear': '???', 'kRayThingLines': 'RAY?'}

# The crowd at Route 9 Park, played now and then from the kids on the court and the parents round it.
CROWD = [('KID', t) for t in [
    "Mom! Mom, look!", "Watch this!", "Again! Again!", "Do a flip!", "No fair!", "You're it!",
    "I can go higher than you!", "Look how high!", "Wait for me!", "Can we stay longer?",
    "Ow! You bumped me!", "My turn!", "Whoa!", "Ha! Got you!", "Dad! Watch!", "One more time!"]] + \
    [('ADULT', t) for t in [
    "Careful, buddy!", "Five more minutes!", "Only one on a trampoline!", "Where are your socks?",
    "Jessica, slow down!", "Good job!", "Not so high, okay?", "Who wants pizza after?"]]

def collect():
    lines = {}
    src = os.path.join(ROOT, 'src')
    for fn in sorted(os.listdir(src)):
        if not fn.endswith('.cpp'):
            continue
        txt = open(os.path.join(src, fn), encoding='utf-8').read()
        for m in re.finditer(r'\b(?:say|addv)\(\s*(?:SH_\w+\s*,\s*)?"([^"]*)"\s*,\s*"((?:[^"\\]|\\.)*)"', txt):
            who, line = m.group(1), m.group(2).replace('\\"', '"')
            if who == 'PHONE':  # a description of the static, not speech
                continue
            lines.setdefault(line, who)
        for name, who in ARRAYS.items():
            m = re.search(name + r'\[\]\s*=\s*\{(.*?)\};', txt, re.S)
            if m:
                for s in re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(1)):
                    lines.setdefault(s.replace('\\"', '"'), who)
    out = [(fnv(t), w, t) for t, w in lines.items()]
    out += [(fnv('@crowd:' + t), w, t) for w, t in CROWD]
    return out

# Everyone is a LibriTTS speaker (CC BY 4.0: free to ship with credit), picked by measured pitch.
KID_SPK = [539, 378, 707, 525, 840, 448, 693, 819, 56, 315]
ADULT_SPK = [49, 35, 105, 42, 217, 518, 91, 237, 805]
L = 'voice-en-us-libritts-high'

def speaker(who, text):
    """(voice model, libritts speaker id, pitch factor, speed) for a speaker."""
    w = who.upper()
    if w.startswith('MOM'):
        return (L, 140, 1.0, 1.05)
    if w.startswith('DAD'):
        return (L, 427, 1.0, 1.3)
    if w.startswith('RAY?'):
        return (L, 413, 0.9, 1.15)   # Ray's voice, but not quite
    if w.startswith('RAY'):
        return (L, 413, 1.0, 1.0)
    if w == 'OFFICER':
        return (L, 49, 1.0, 1.05)
    if w == 'PA':
        return (L, 518, 1.0, 1.0)    # the teenager on the front desk mic
    if w == 'NEWS':
        return (L, 237, 1.0, 1.0)
    if w.startswith('THEO'):
        return (L, 182, 1.0, 1.1)
    if w.startswith('???'):
        return (L, 301, 0.9, 1.9)    # a child's voice, slowed: wrong
    if w == 'ADULT':
        return (L, ADULT_SPK[fnv(text) % len(ADULT_SPK)], 1.0, 1.0)
    if w == 'KID':
        return (L, KID_SPK[fnv(text) % len(KID_SPK)], 1.2, 0.95)
    # YOU (and DANA, the kid's old name): a nine-year-old
    return (L, 560, 1.3, 1.2)

def clean(text):
    t = text.strip()
    if t.startswith('(') and t.endswith(')'):
        t = t[1:-1]
    t = t.replace('=)', '').replace('...', ', ').replace('-', ', ')
    return t.strip(' ,') or text

def cmd_list():
    os.makedirs(OUT, exist_ok=True)
    rows = collect()
    with open(os.path.join(OUT, 'lines.tsv'), 'w', encoding='utf-8') as f:
        for k, w, t in rows:
            f.write('%08x\t%s\t%s\n' % (k, w, t))
    print('%d lines -> assets/voices/lines.tsv' % len(rows))

def cmd_synth():
    voices = os.environ.get('PIPER_VOICES', os.path.expanduser('~/tts'))
    piper = os.environ.get('PIPER', 'piper')
    os.makedirs(OUT, exist_ok=True)
    for k, w, t in collect():
        dst = os.path.join(OUT, '%08x.wav' % k)
        if os.path.exists(dst):
            continue
        model, spk, pitch, speed = speaker(w, t)
        onnx = [os.path.join(voices, model, f) for f in os.listdir(os.path.join(voices, model)) if f.endswith('.onnx')][0]
        raw = dst + '.raw.wav'
        args = [piper, '--model', onnx, '--output_file', raw, '--length_scale', str(speed)]
        if spk is not None:
            args += ['--speaker', str(spk)]
        subprocess.run(args, input=clean(t).encode(), check=True, capture_output=True)
        # pitch: resample up/down then fix the tempo; trim silence; mono 22050 Hz
        af = 'silenceremove=start_periods=1:start_threshold=-45dB,areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse'
        if abs(pitch - 1.0) > 0.01:
            af = 'asetrate=22050*%g,aresample=22050,atempo=%g,' % (pitch, 1.0 / pitch) + af
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', raw, '-af', af, '-ac', '1', '-ar', '22050', dst], check=True)
        os.remove(raw)
        print(w, t)

# ---- IMA ADPCM (4 bits a sample)
STEPS = [7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118,
         130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166,
         1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845,
         8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767]
IDX = [-1, -1, -1, -1, 2, 4, 6, 8]

def adpcm(samples):
    pred, idx, out, nib = 0, 0, bytearray(), []
    for s in samples:
        step = STEPS[idx]
        diff = s - pred
        code = 0
        if diff < 0:
            code = 8; diff = -diff
        d = step >> 3
        if diff >= step: code |= 4; diff -= step; d += step
        step >>= 1
        if diff >= step: code |= 2; diff -= step; d += step
        step >>= 1
        if diff >= step: code |= 1; d += step
        pred = max(-32768, min(32767, pred - d if code & 8 else pred + d))
        idx = max(0, min(88, idx + IDX[code & 7]))
        nib.append(code)
    if len(nib) % 2:
        nib.append(0)
    for i in range(0, len(nib), 2):
        out.append(nib[i] | (nib[i + 1] << 4))
    return bytes(out)

def cmd_build():
    clips = []
    if os.path.isdir(OUT):
        for fn in sorted(os.listdir(OUT)):
            if not re.fullmatch(r'[0-9a-f]{8}\.wav', fn):
                continue
            with wave.open(os.path.join(OUT, fn)) as w:
                assert w.getnchannels() == 1 and w.getsampwidth() == 2, fn
                rate, n = w.getframerate(), w.getnframes()
                pcm = struct.unpack('<%dh' % n, w.readframes(n))
            # every line at the same loudness (-18 dBFS RMS), peaks kept under -1.5 dBFS
            rms = (sum(v * v for v in pcm) / max(1, n)) ** 0.5
            peak = max(1, max(abs(v) for v in pcm))
            g = min(32768 * 10 ** (-18 / 20) / max(rms, 1.0), 32768 * 0.84 / peak)
            pcm = [max(-32768, min(32767, int(v * g))) for v in pcm]
            clips.append((int(fn[:8], 16), rate, n, adpcm(pcm)))
    with open(os.path.join(ROOT, 'src', 'voices_data.h'), 'w') as f:
        f.write('// Generated by tools/make_voices.py build: every spoken line, IMA ADPCM, keyed by FNV-1a of its text.\n')
        f.write('#pragma once\n#include <cstdint>\n\nstruct VoiceClipData { uint32_t key; uint32_t rate, samples; const uint8_t* adpcm; };\n\n')
        for i, (k, rate, n, data) in enumerate(clips):
            f.write('static const uint8_t kVoice%d[] = {' % i)
            f.write(','.join(str(b) for b in data))
            f.write('};\n')
        f.write('static const VoiceClipData kVoiceClips[] = {\n')
        for i, (k, rate, n, data) in enumerate(clips):
            f.write('    {0x%08xu, %d, %d, kVoice%d},\n' % (k, rate, n, i))
        if not clips:
            f.write('    {0u, 0, 0, nullptr},\n')
        f.write('};\nstatic const int kVoiceClipCount = %d;\n' % len(clips))
    print('%d clips -> src/voices_data.h' % len(clips))

if __name__ == '__main__':
    {'list': cmd_list, 'synth': cmd_synth, 'build': cmd_build}[sys.argv[1] if len(sys.argv) > 1 else 'list']()
