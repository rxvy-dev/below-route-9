# NOCLIP — Design Document

A first-person Backrooms horror exploration game for Linux. No combat: you survive by
moving carefully, hiding, listening and reading the spaces. This document is the source of
truth for architecture, scope and build order.

## Pillars

1. **Liminal realism.** Fluorescent light, damp carpet, endless repetition. The horror comes
   from light, sound and space, not gore.
2. **Readable stealth.** Every entity telegraphs itself (lights flicker, sound changes).
   A careful player is never killed by something they had no way to notice.
3. **Lore you find, not lore you're told.** Notes, tapes, camps and the architecture itself.
4. **Runs on every Linux distro.** One dependency (SDL2), no data files to lose, XDG paths.

## Tech stack

| Area      | Choice | Why |
|-----------|--------|-----|
| Language  | C++17 | Fast, portable, no runtime |
| Platform  | SDL2 (video, input, audio, gamepad) | X11 + Wayland, PipeWire/Pulse/ALSA through one API |
| Graphics  | OpenGL 3.3 core, own loader (`src/gl.*`) | No GLEW/glad dependency, works on Mesa, Nvidia, AMD, Intel |
| Assets    | Procedural (textures, meshes, audio) | Single self-contained binary; glTF loader planned for drop-in art |
| Build     | CMake ≥ 3.16 | Available on every distro |

## Module layout

```
src/
  main.cpp       entry point, CLI flags, main loop
  gl.h/.cpp      OpenGL function loader (via SDL_GL_GetProcAddress)
  mathx.h        vec/mat math
  platform.*     XDG paths, settings + save files
  texgen.*       procedural textures (wallpaper, carpet, ceiling tiles, paper, noise)
  level.*        maze generation, lights, lightmap baking, collision, line of sight, pathfinding, meshes
  render.*       shaders, HDR framebuffer, post-processing (bloom, ACES, grain, VHS), text
  audio.*        real-time synthesizer: hum, footsteps, reverb, entity voices, stingers
  entity.*       entity AI: Stalker state machine (Tenant, Hound) and the Grin
  sdfmesh.*      SDF sculpting primitives + Surface Nets mesher (smooth, watertight meshes)
  creatures.*    sculpted creatures and props, skeletons, bone weights, procedural animation
  game.*         game state machine, player controller, items, notes, HUD, menus
third_party/
  font8x8_basic.h  public-domain 8x8 bitmap font
```

## Rendering

- Forward renderer into an RGBA16F HDR target (falls back to RGBA8).
- **Ceiling lights**: hundreds of lights handled by a baked *indexed lightmap*. Each texel
  (4 per metre) stores the two strongest visible lights and their weights; visibility is
  computed by grid ray-marching through the wall edges, so light never leaks through walls.
  A 64×64 "light state" texture is updated every frame, so every light can flicker, die,
  or react to an entity while staying baked-cheap.
- **Flashlight**: dynamic spotlight with a 2048² shadow map (3x3 PCF), GGX specular and smoothed lag.
- **Creatures and props**: SDF sculpts (capsules, ellipsoids, smooth unions, carved sockets,
  displacement for wrinkles and ribs) meshed at startup with Surface Nets; vertex AO is baked
  from the field. Creatures get two-bone weights and are skinned on the GPU (24 bones max).
  Region tags (skin, eyes, bone, glow) drive per-region albedo, gloss and emission.
- **Post chain**: SSAO (half res) → volumetric flashlight beam + ceiling haze (half res,
  28 jittered steps, shadow-mapped) → composite → 6-level bloom (13-tap down / tent up) →
  ACES + grade + camcorder lens → FXAA + grain.
- **Surface detail**: procedural albedo + height maps, bump via screen-space surface
  gradients, per-vertex ambient occlusion along wall/floor seams.
- **Post**: mip-chain bloom, ACES tonemap, vignette, chromatic aberration, film grain,
  optional camcorder/VHS filter (scanlines, tape jitter, chroma bleed, timestamp HUD).
- Quality presets scale render resolution and toggle bloom.

## Audio

All sound is synthesized in the SDL audio callback: 60/120 Hz ballast hum tied to how lit
you are, footsteps per gait, an entity drone with distance + stereo pan, a radio-static
beacon at the exit, heartbeat during chases, distant ambient events, and a Schroeder reverb
for the room tail.

## Gameplay systems (Phase 1)

- Walk / sprint (stamina) / crouch (quiet). Head bob, FOV kick.
- Flashlight with battery drain; batteries as pickups.
- Almond water: restores stamina and gives a short regen boost.
- Notes: lore pickups, read in a full-screen overlay, and they act as checkpoints.
- **The Tenant**: hears noise (radius depends on gait), sees you (range depends on your
  flashlight and the light you stand in), chases, loses you, searches. Nearby lights flicker
  and dim as it approaches. Spawns after 60 s or soon after the first note.
- **The Hound**: blind, hearing x1.6, lunges at loud nearby noise (sprinting), fast but gives
  up after ~2 s without sound. Spawns after the second note or 4 minutes.
- **The Grin**: two per level, each deep in a dark zone. Drawn to a lit flashlight when you're
  in the dark; creeps when unobserved; freezes when watched; can never enter lit space.
- **Set dressing**: baseboards, troffer frames, outlets, ceiling vents, office chairs (some
  knocked over), cardboard boxes, water coolers, and an abandoned Survey camp. Furniture
  collides with the player and entities.
- Exit: a section of wall that isn't quite solid. Static on the radio tells you roughly where.
- Pause menu, settings persisted to `$XDG_CONFIG_HOME/noclip/settings.ini`,
  progress to `$XDG_DATA_HOME/noclip/save.ini`.

## Phases

| Phase | Content | Status |
|-------|---------|--------|
| 1 | Engine slice + Level 0 playable start to finish | **Done** |
| 2 | Shadow maps, volumetrics, SSAO, bloom chain, FXAA, sculpted skinned creatures | **Done** (v0.2) |
| 3 | Hiding spots, inventory UI, tapes (audio logs), glTF loader for artist models | Next |
| 4 | Themed levels 1–4 + endless remixes, wraparound worlds, painted clues, hunts and exit chases | **Done** (v0.3) |
| 4b | More hand-designed levels from the list below | Next |
| 5 | Endings, polish, AppImage + Flatpak, container test matrix | |

## Level list

| # | Name | Rule / hazard |
|---|------|---------------|
| 0 | The Lobby | Endless yellow offices. The Tenant. |
| 1 | Habitable Zone | Concrete warehouse, supply crates, the first Survey camp |
| 2 | Pipe Dreams | Narrow maintenance tunnels, steam vents that hide sound |
| 3 | Electrical Station | Arcing machinery; noise attracts things |
| 4 | Abandoned Office | Daylight-white offices, printers that print your name |
| 5 | Terror Hotel | Infinite hotel corridor, rooms that rearrange when unseen |
| 6 | Lights Out | Total darkness; flashlight only, batteries are scarce |
| 7 | The Poolrooms | Tiled pools, echo-based navigation, water drags you down |
| 8 | Cave System | Natural caves under the levels, crawlers |
| 9 | Suburbs | A neighbourhood at permanent night, every door locked but one |
| 10 | The Field | Fog, wheat, an endless sky with no sun |
| 11 | The Mall | Dead mall, music from nowhere, mannequins |
| 12 | Subway | Flooded platforms, a train that never stops |
| 13 | The School | Classrooms, a bell that resets the floor |
| 14 | Paradise | Something that looks like an exit and isn't |
| 15 | The Archive | Every tape ever recorded. The ending. |

## Portability notes

- No system GL headers needed: `src/gl.h` defines everything. SDL loads libGL/libEGL at runtime.
- Wayland: `SDL_VIDEODRIVER=wayland ./noclip` (SDL2 defaults to X11/XWayland).
- Audio goes through SDL, so PipeWire, PulseAudio and ALSA all work.
- `install.sh` knows apt, dnf, yum, pacman, zypper, xbps, apk, emerge, eopkg and Nix.
- CI (`.github/workflows/build.yml`) builds through `install.sh` on Ubuntu 22.04/24.04, Debian,
  Fedora, Arch, openSUSE Tumbleweed, Alpine and Void.
- Verified locally: clean `-Wall -Wextra` build, AddressSanitizer + UBSan clean across all
  test scenes, headless rendering under Xvfb/Mesa llvmpipe.

## Testing

`noclip --scene NAME --frames N --screenshot out.ppm` renders a deterministic scene and exits.
Scenes: title, play, tenant, hound, grin, grinlit, chase, camp, dark, exit, exitwalk, note, pause.
`exitwalk` walks into the exit and should end on the Level Complete screen.
`NOCLIP_BINDPOSE=1` renders creatures in their bind pose for checking skin weights.

## v0.3 systems

- **Themes** (`src/theme.*`): layout style, surfaces, light colour/spacing/fixtures, fog,
  pools, pipes, inhabitants, hunt frequency, supplies, notes and graffiti per level.
  Levels 5+ are seeded remixes of 0–4 with more entities and fewer lights.
- **Endless spaces**: the tile grid is a torus. Walls, BFS, line of sight, collision and the
  lightmap all wrap. Geometry is built in 8x8-tile chunks and each chunk is drawn at the
  copy nearest the camera, so the seam is never visible. World size is 48x48 tiles (96 m);
  every procedural texture period divides 96 m so nothing pops at the seam.
- **Clues**: the shortest path from spawn to exit is walked and arrows are painted on walls
  parallel to the direction of travel (preferring the wall you face at a turn), or on the
  floor in open space. EXIT is painted over the thin place; three-walled dead ends get
  NOT THIS WAY / X. Spray-paint textures are generated (soft edges, overspray, drips).
- **Hunts**: on a timer, an active stalker that is at least 6 tiles away gets perfect
  knowledge of the player for 18 s (speed below a sprint, so it's escapable with stamina).
- **Exit chase**: the first time the player gets within 11 tiles of the exit, a stalker is
  placed 7–12 tiles behind (further from the exit, out of sight) and hunts for 60 s.
  Dying resets it so the run has to be made again.
- **Feedback**: klaxon, red-pulsing lights (`uLightColor` tint), red screen edge, 150 bpm
  chase music, heartbeat.
- **Water**: sunken pool tiles, animated-normal water with fresnel reflections of the
  ceiling, caustics on the pool floor, wading slows everyone, splashes are 2.5x as loud.

Testing additions: `--level N`, scenes `clue`, `pool`, `hunt`, `wrap`, `transition`, and
`autorun` (an autopilot that follows the exit route at a run; it logs hunts, the exit
chase, catches and escapes).
